"""What a host admits against, and the terms it seals for one connection.

The records, apart from the state machine that uses them (`handshake.py`), so
that the host, the spawner and their laws can name what is being admitted
without importing the exchange.

`sealed_terms` belongs here rather than beside the exchange for one reason:
its size check is a property of the RUN, not of a connection. A recorded start
too large for a frame would refuse every worker identically, so the host
learns it once -- before it spawns or listens -- instead of one handshake at a
time.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from meta_evolve.domain import RunId
from meta_evolve.domain.components import ComponentManifest
from meta_evolve.domain.context import ContextSpec
from meta_evolve.domain.events import RunStarted
from meta_evolve.domain.values import FrozenMap
from meta_evolve.domain.work import Lease
from meta_evolve.domain.workers import WorkerRegistration
from meta_evolve.errors import CapabilityError
from meta_evolve.ports.worker_registry import TrustLookup

from .frames import DEFAULT_MAX_FRAME_BYTES
from .handshake_codec import encode_body
from .handshake_envelope import NONCE_BYTES, seal


@dataclass(frozen=True, slots=True)
class HostAdmission:
    """Admission terms and connection ownership for one host.

    Exactly one identity policy is required: minted ids for spawned workers,
    or a live enrolment lookup for operator-named workers. Requirements apply
    to the latter. Reservations cover handshakes awaiting the listener's poll;
    live tracks admitted incarnations so reconnects can reclaim their connection.
    """

    run_id: RunId
    started: RunStarted
    context: ContextSpec | None
    manifests: tuple[ComponentManifest, ...]
    fingerprint: str
    key: bytes
    heartbeat_seconds: int
    max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES
    minted: tuple[str, ...] | None = None
    lookup: TrustLookup | None = None
    requirements: FrozenMap = field(default_factory=FrozenMap)
    live: Mapping[str, str] = field(default_factory=dict)
    admitted_ids: set[str] = field(default_factory=set)
    reservations: dict[object, tuple[str, str]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.minted is not None and self.lookup is not None:
            raise ValueError(
                "a host that minted its own worker ids needs no allow-list: it "
                "carries minted= or lookup=, never both"
            )
        if self.minted is None and self.lookup is None:
            raise ValueError(
                "a host whose workers name themselves admits them by its "
                "store's allow-list: pass lookup=, since a host with neither "
                "admits everyone holding the key"
            )


@dataclass(frozen=True, slots=True)
class Admitted:
    """One worker, admitted: what it may claim under, and what it still holds."""

    registration: WorkerRegistration
    incarnation: str
    held: tuple[Lease, ...]
    supersedes: bool


@dataclass(frozen=True, slots=True)
class Refused:
    """This connection is not admitted, and whether the reason was proved.

    `error` is the exception behind a refusal nothing expected: the wire names
    only its type, so the host keeps the rest. Not compared.
    """

    reason: str
    authenticated: bool
    error: BaseException | None = field(default=None, compare=False)


#: Both sides mint hex nonces of this length; admission checks the same format
#: so JSON escaping cannot exceed the size used to preflight `Terms`.
NONCE_CHARS = 2 * NONCE_BYTES


def sealed_terms(
    admission: HostAdmission, *, host_nonce: str, worker_nonce: str
) -> bytes:
    """The `Terms` frame body, refused here if no frame could carry it.

    Sealed once per connection but sized once per run: a `RunStarted` whose
    encoding exceeds the frame bound would refuse every worker identically, so
    the host learns it before it spawns or listens rather than one handshake
    at a time.
    """

    body = encode_body(
        {
            "host_nonce": host_nonce,
            "worker_nonce": worker_nonce,
            "run_id": admission.run_id.value,
            "started": admission.started,
            "context": admission.context,
            "heartbeat_seconds": admission.heartbeat_seconds,
            "max_frame_bytes": admission.max_frame_bytes,
        }
    )
    sealed = seal("terms", admission.key, body)
    if len(sealed) > admission.max_frame_bytes:
        raise CapabilityError(
            f"this run's recorded start seals to {len(sealed)} bytes, over the "
            f"{admission.max_frame_bytes}-byte frame bound: no worker could be "
            "told what to run. Raise the bound, or declare a smaller policy "
            "configuration"
        )
    return sealed


__all__ = ["Admitted", "HostAdmission", "NONCE_CHARS", "Refused", "sealed_terms"]
