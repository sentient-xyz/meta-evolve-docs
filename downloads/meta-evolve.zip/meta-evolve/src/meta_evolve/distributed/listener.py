"""One listening socket and the handshakes it has in flight.

Shared by the two backends, which differ only in their id policy and in who
starts the workers: `WorkerHost` listens for an operator's, `WorkerProcesses`
listens for the children it spawned.

Nothing here blocks. The dispatcher's thread is the one that renews every
lease in flight, so a handshake gets a poll at a time and a deadline of its
own (`HANDSHAKE_DEADLINE_SECONDS`), and a peer that stalls costs the run
nothing but the slot it occupies among `MAX_PENDING`.
"""

from __future__ import annotations

import errno
import socket
from collections import deque

from meta_evolve.application.dispatch_admission import Joining
from meta_evolve.errors import CapabilityError

from .admission import Admitted, HostAdmission, Refused
from .handshake import HostHandshake
from .wire import WireEndpoint

#: How many peers may be mid-handshake at once. Past this a new connection is
#: closed without a frame: an unauthenticated peer must not be able to make
#: the host hold sockets by opening them.
MAX_PENDING = 16

#: Keep recent diagnostics, including host tracebacks, without retaining every
#: failed connection and its input buffers for the lifetime of the listener.
MAX_REFUSALS = 16


def bind_listener(address: tuple[str, int]) -> socket.socket:
    """A non-blocking listener on `address`, or a refusal naming it.

    `SO_REUSEADDR` before the bind, so a resumed dispatcher takes its own
    address back while the connections of the one that died are still in
    TIME_WAIT. Without it a restart would refuse for a minute, and the worker
    holding an unacknowledged result could not reconnect to tell anyone.
    """

    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        listener.bind(address)
    except OSError as error:
        listener.close()
        raise CapabilityError(
            f"cannot listen for workers on {address[0]}:{address[1]}: "
            f"{error.strerror or errno.errorcode.get(error.errno, error)}"
        ) from None
    listener.listen(MAX_PENDING)
    listener.setblocking(False)
    return listener


def parse_address(address: str) -> tuple[str, int]:
    """`host:port`, or a refusal. IPv4 only in M11.3."""

    host, _, port = address.rpartition(":")
    if not host or not port.isdigit() or not 0 <= int(port) <= 65535:
        raise CapabilityError(
            f"a worker address is host:port, with a port from 0 to 65535, not "
            f"{address!r}"
        )
    return host, int(port)


class PendingHandshakes:
    """Every connection that has not yet been admitted or refused."""

    def __init__(self, listener: socket.socket, admission: HostAdmission) -> None:
        self._listener = listener
        self._admission = admission
        self._pending: list[HostHandshake] = []
        self.refusals: deque[Refused] = deque(maxlen=MAX_REFUSALS)

    def accept(self) -> None:
        """Take whatever is waiting, up to the pending bound."""

        while len(self._pending) < MAX_PENDING:
            try:
                connection, _address = self._listener.accept()
            except (BlockingIOError, InterruptedError):
                return
            except OSError:
                return  # the listener is closed; `finish` owns that
            self._pending.append(
                HostHandshake(connection, admission=self._admission)
            )

    def advance(self) -> tuple[tuple[socket.socket, Admitted], ...]:
        """Step every handshake once. Refusals are recorded, never raised.

        Each admission is returned WITH its socket, which is what becomes the
        connection: the handshake owns it until then, and a refusal closes it
        here rather than leaving it to a caller that has nothing else to do
        with it.
        """

        admitted: list[tuple[socket.socket, Admitted]] = []
        pending = tuple(self._pending)
        try:
            for handshake in pending:
                outcome = handshake.advance()
                if outcome is None:
                    continue
                self._pending.remove(handshake)
                if isinstance(outcome, Admitted):
                    admitted.append((handshake.socket, outcome))
                else:
                    self.refusals.append(outcome)
                    handshake.socket.close()
            return tuple(admitted)
        except BaseException:
            for connection, _ in admitted:
                connection.close()
            raise
        finally:
            # Keep successful ownership visible through the WHOLE batch. The
            # host publishes live endpoints synchronously before the next poll.
            for handshake in pending:
                handshake.release_identity()

    def joined(self, clock, *, max_frame_bytes: int) -> tuple[Joining, ...]:
        """This poll's admissions, as connections the loop can take."""

        self.accept()
        admitted = self.advance()
        try:
            return tuple(
                Joining(
                    endpoint=WireEndpoint(
                        connection,
                        registration=outcome.registration,
                        clock=clock,
                        max_frame_bytes=max_frame_bytes,
                    ),
                    held=outcome.held,
                    incarnation=outcome.incarnation,
                )
                for connection, outcome in admitted
            )
        except BaseException:
            for connection, _ in admitted:
                connection.close()
            raise

    def close(self) -> None:
        for handshake in self._pending:
            handshake.release_identity()
            handshake.socket.close()
        self._pending.clear()


__all__ = ["MAX_PENDING", "MAX_REFUSALS", "PendingHandshakes", "bind_listener", "parse_address"]
