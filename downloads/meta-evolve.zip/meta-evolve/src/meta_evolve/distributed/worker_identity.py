"""Check worker identity, live incarnation, enrolment, and capabilities."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, cast

from meta_evolve.domain.workers import (
    MALFORMED_WORKER_ID,
    RESERVED_WORKER_ID,
    TrustedWorker,
    WorkerId,
    honoured_generation,
    in_reserved_namespace,
    is_valid_worker_id,
)
from meta_evolve.ports.worker_registry import TrustLookup
from meta_evolve.worker_capabilities import unmet_requirement

from .handshake_codec import HandshakeRefused

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .admission import HostAdmission


def refuse_identity(hello: Mapping[str, object], admission: HostAdmission) -> str | None:
    """The id rules, in one place (design PD7)."""

    worker_id = hello.get("worker_id")
    incarnation = hello.get("incarnation")
    if not is_valid_worker_id(worker_id):
        return MALFORMED_WORKER_ID
    if not isinstance(incarnation, str) or not incarnation:
        return "this worker declared no incarnation"
    reserved = next(
        (
            owner
            for claimed_id, owner in admission.reservations.values()
            if claimed_id == worker_id
        ),
        None,
    )
    minted = admission.minted
    if minted is None:
        if in_reserved_namespace(worker_id):
            return RESERVED_WORKER_ID
    elif worker_id not in minted:
        return f"this host expects one of the worker ids it minted, not {worker_id!r}"
    elif worker_id in admission.admitted_ids or reserved is not None:
        return f"the worker id {worker_id!r} was already admitted"
    live = admission.live.get(worker_id)
    if (live is not None and live != incarnation) or (
        reserved is not None and reserved != incarnation
    ):
        return (
            f"the worker id {worker_id!r} is in use by another live process: "
            "two workers sharing one id would take the slot from each other"
        )
    return None


def admitted_generation(admission: HostAdmission, worker: WorkerId) -> int:
    """Return the generation this worker may claim under, or refuse admission.

    Spawned workers use generation 1. Operator-named workers need a trusted row
    whose capabilities satisfy the run; both answers come from the same read.
    """

    if admission.minted is not None:
        return 1
    # `HostAdmission` refuses to exist with neither `minted` nor `lookup`.
    row = cast(TrustLookup, admission.lookup)(worker)
    generation = honoured_generation(worker, row)
    if generation is None:
        raise HandshakeRefused(_untrusted(worker, row), True)
    assert row is not None  # honoured, and not minted: the store has its row
    unmet = unmet_requirement(admission.requirements, row.capabilities)
    if unmet is not None:
        raise HandshakeRefused(unmet, True)
    return generation


def _untrusted(worker: WorkerId, row: TrustedWorker | None) -> str:
    """Not enrolled or revoked, in words an operator can act on.

    The only place a worker is told which: a broker sees `None` for both.
    """

    if row is None:
        return (
            f"this worker is not enrolled in the dispatcher's store: enrol it "
            f"with `meta-evolve workers add {worker.value} --storage <path>`"
        )
    return (
        f"this worker's enrolment was revoked by the store's operator, at "
        f"generation {row.generation}"
    )


__all__ = ["admitted_generation", "refuse_identity"]
