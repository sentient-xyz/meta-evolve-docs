"""The sealed envelope every handshake frame is, and nothing about admission.

One frame body is `{"kind": ..., "body": <text>, "mac": <hex or null>}`. The
MAC covers `meta-evolve/<kind>/v1\0` and the body TEXT, so it carries the
direction and the protocol version: an `Admitted` relabelled as a `Terms`
fails the MAC rather than being read, and a peer speaking another version
fails it too instead of being parsed.

**Verify, then parse.** `unseal` decodes only the outer envelope -- three
keys, bounded by the frame -- checks the MAC over exactly the bytes that
arrived, and hands the body to the decoder only afterwards. So an
unauthenticated peer never reaches the tagged decoder, and nothing is ever
re-canonicalised for comparison: what was signed is what arrived.

Its own module because both ends and their laws need the envelope, while each
end needs only its own half of the exchange.
"""

from __future__ import annotations

import hmac
import json
from hashlib import sha256

from .handshake_codec import HandshakeRefused, decode_body

#: What the host reads under until a `Hello` has proved the key. A `Hello`
#: carries two nonces, an id, an incarnation and a fingerprint.
HELLO_MAX_FRAME_BYTES = 64 * 1024

#: How long, in REAL seconds, one handshake may take from its first frame.
#: Real time, never the injected clock: a handshake is not the run's business,
#: and a manual clock would never expire it.
HANDSHAKE_DEADLINE_SECONDS = 10.0

NONCE_BYTES = 32


def label(kind: str) -> bytes:
    return f"meta-evolve/{kind}/v1".encode("utf-8") + b"\0"


def seal(kind: str, key: bytes | None, body: str) -> bytes:
    """One frame body: the kind, the body TEXT, and a MAC over exactly it."""

    mac = None if key is None else hmac.new(key, label(kind) + body.encode("utf-8"), sha256).hexdigest()
    return json.dumps(
        {"kind": kind, "body": body, "mac": mac}, separators=(",", ":")
    ).encode("utf-8")


def envelope_of(body: bytes) -> dict:
    try:
        envelope = json.loads(body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise HandshakeRefused("this is not a handshake frame", False) from None
    if (
        not isinstance(envelope, dict)
        or not isinstance(envelope.get("kind"), str)
        or not isinstance(envelope.get("body"), str)
        or not isinstance(envelope.get("mac"), (str, type(None)))
    ):
        raise HandshakeRefused("this is not a handshake frame", False)
    return envelope


def kind_of(body: bytes) -> str:
    return envelope_of(body)["kind"]


def unseal(kind: str, key: bytes | None, body: bytes) -> dict:
    """The body of one sealed frame, AFTER its MAC is verified."""

    envelope = envelope_of(body)
    if envelope["kind"] != kind:
        raise HandshakeRefused(
            f"the handshake expected {kind}, not {envelope['kind']!r}", False
        )
    if key is not None:
        presented = envelope["mac"]
        if (
            not isinstance(presented, str)
            or len(presented) != 64
            or not presented.isascii()
            or any(character not in "0123456789abcdefABCDEF" for character in presented)
        ):
            raise HandshakeRefused("authentication failed", False)
        try:
            body_bytes = envelope["body"].encode("utf-8")
        except UnicodeEncodeError:
            raise HandshakeRefused("authentication failed", False) from None
        expected = hmac.new(key, label(kind) + body_bytes, sha256).hexdigest()
        if not hmac.compare_digest(presented, expected):
            raise HandshakeRefused("authentication failed", False)
    return decode_body(envelope["body"])


__all__ = [
    "HANDSHAKE_DEADLINE_SECONDS",
    "HELLO_MAX_FRAME_BYTES",
    "NONCE_BYTES",
    "kind_of",
    "label",
    "seal",
    "unseal",
]
