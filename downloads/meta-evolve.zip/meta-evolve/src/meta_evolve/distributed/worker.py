"""The worker side of one wire connection.

`serve` pulls one item at a time, runs its executor on the calling thread, and
sends the outcome -- split by the same `outcome_of` the inline backend uses, so
one raise is one outcome whichever backend ran it. The executors are the
run's `LocalEvaluationExecutor` / `LocalProposalExecutor`, so a candidate is
encoded here, on the worker, by `encode_candidate` (D14), and a value the codec
rejects travels as the same `InvalidOutput` inline produces.

A heartbeat thread, when asked for, sends `Heartbeat` every
`heartbeat_seconds` of `time.monotonic` (D9): liveness is the worker's to
report and the host's to judge, by the host's clock. A `Stale` answer that
arrives while a call runs does not stop the call -- Python cannot -- and the
result is still sent, to be answered `Stale` again from the store; nothing
about it is written.

A `BaseException` in the component ends `serve`, after sending `Goodbye` so
the host releases what this connection held as INTERRUPTED rather than waiting
out a silence whose answer it already has (D3, T21). The host says goodbye
too, when its run finished, which is how a worker tells that apart from a
dispatcher that died: both close the socket.
"""

from __future__ import annotations

import socket
import threading
from collections import deque
from dataclasses import dataclass

from meta_evolve.application.dispatch_messages import (
    Answer,
    AttemptFailed,
    Completed,
    CompletionFailed,
    Escaped,
    Goodbye,
    Heartbeat,
    Pull,
    TransportFailure,
    Work,
)
from meta_evolve.application.dispatch_outcomes import (
    call_for,
    outcome_of,
    reportable_cause,
)
from meta_evolve.application.executors import (
    CandidateEncodingError,
    EvaluationExecutor,
    ProposalExecutor,
)

from .messages import bounded_text, decode_message, encode_message
from .frames import DEFAULT_MAX_FRAME_BYTES, FrameReader, frame


class _ConnectionLost(Exception):
    """A socket operation failed, rather than encoding or running a call."""


@dataclass(frozen=True, slots=True)
class Finished:
    """The host said the run was over, so this worker is done."""


@dataclass(frozen=True, slots=True)
class Lost:
    """The connection ended without a goodbye, and what was still unanswered.

    `pending` is the one result this worker completed and nobody answered. An
    external worker reconnects and resends it, which is how an acknowledgment
    lost with its dispatcher is recovered (D13): the item is answered
    `Duplicate` when the commit landed, and `Stale` when it did not.
    """

    pending: tuple[object, Completed] | None
    #: The run that issued the pending result's lease. A `Lease` names no run,
    #: so without this a reconnecting worker could not tell whether what it
    #: holds belongs to the run it is reconnecting to.
    run_id: str | None = None


def serve(
    sock,
    *,
    evaluation: EvaluationExecutor,
    proposal: ProposalExecutor,
    heartbeat_seconds: float | None = None,
    max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES,
    resend: tuple[object, Completed] | None = None,
    run_id: str | None = None,
) -> Finished | Lost:
    """Pull, run and report until the host says goodbye or the socket ends.

    ONE result is held until its item is answered (design PD8), and nothing
    else is: the host releases an attempt failure without answering it, and a
    completion failure or an escaping error either aborts the drive -- which
    closes this connection -- or is answered `Stale` on a lease that expired
    while the call ran. So only a result is worth waiting for, and waiting for
    the others would hang.
    """

    sock.setblocking(True)
    sending = threading.Lock()
    reader = FrameReader(max_frame_bytes=max_frame_bytes)
    inbox: deque = deque()
    stop = threading.Event()

    def send(message, text_limit=None) -> None:
        options = {} if text_limit is None else {"text_limit": text_limit}
        body = frame(encode_message(message, **options), max_frame_bytes=max_frame_bytes)
        with sending:
            try:
                sock.sendall(body)
            except OSError as error:
                raise _ConnectionLost from error

    def receive():
        while not inbox:
            try:
                data = sock.recv(65536)
            except OSError as error:
                raise _ConnectionLost from error
            if not data:
                return None
            inbox.extend(decode_message(body) for body in reader.feed(data))
        return inbox.popleft()

    def beat() -> None:
        while not stop.wait(heartbeat_seconds):
            try:
                send(Heartbeat())
            except _ConnectionLost:
                # The connection is broken. Shut it, so the main loop's next
                # read ends `serve` too -- a worker that silently stopped
                # beating would run on until the host judged it silent.
                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass  # already shut: the main loop sees the same end
                return

    if heartbeat_seconds is not None:
        threading.Thread(target=beat, name="meta-evolve-heartbeat", daemon=True).start()
    holding: tuple[object, Completed] | None = resend
    current = None if resend is None else resend[0].item
    previous = None

    def report(lease, outcome):
        """Send one outcome, cut to fit if it must, and say what is held."""

        nonlocal holding
        # The first send can fail too; keep the result before attempting it.
        holding = (lease, outcome) if isinstance(outcome, Completed) else None
        try:
            send(outcome)
        except (TypeError, ValueError, TransportFailure) as error:
            # Text bounded well inside this connection's frame, in BYTES:
            # what is left of the frame is the lease and a few fields.
            budget = max(256, max_frame_bytes // 4)
            outcome = _sendable(outcome, error, budget)
            holding = None  # an unsendable result is now a completion failure
            send(outcome, text_limit=budget)

    try:
        if holding is not None:
            send(holding[1])
        else:
            send(Pull())
        while True:
            message = receive()
            if message is None:
                return Lost(holding, run_id)  # the host closed the connection
            if isinstance(message, Goodbye):
                return Finished()  # the run is over, so this worker is too
            if isinstance(message, Answer):
                if message.item == current and holding is not None:
                    # Answered, so the result is no longer this worker's to
                    # keep or to resend, and it may ask for the next item.
                    holding = None
                    send(Pull())
                elif message.item in (current, previous):
                    # A refused renewal answered before the result was sent,
                    # or the second answer to an item already answered once.
                    # Both are the host's normal behaviour under an expired
                    # lease, and neither is another item to ask for.
                    pass
                else:
                    raise TransportFailure(
                        "an answer for an item this worker was never given"
                    )
                continue
            if not isinstance(message, Work):
                raise TransportFailure(
                    f"the host sent a worker message ({type(message).__name__})"
                )
            previous, current = current, message.lease.item
            outcome = outcome_of(
                message.lease, call_for(message, evaluation, proposal)
            )
            if isinstance(outcome, Escaped) and not isinstance(outcome.error, Exception):
                # An interrupt is not an outcome to report: the host is told
                # WHY this worker is leaving, so it releases what this
                # connection held as interrupted rather than waiting out a
                # silence whose answer it already has (D3, T21).
                _farewell(send, outcome.error)
                raise outcome.error
            report(message.lease, outcome)
            if holding is None:
                send(Pull())
    except _ConnectionLost:
        return Lost(holding, run_id)
    finally:
        stop.set()


def _farewell(send, error: BaseException) -> None:
    """Best effort: this process is ending either way."""

    try:
        send(Goodbye(reason=f"the worker was interrupted ({type(error).__name__})"))
    except (_ConnectionLost, OSError, TypeError, ValueError, TransportFailure):
        pass


def _sendable(outcome, error: Exception, budget: int):
    """What to send instead of an outcome that could not cross the wire.

    Only a RESULT is turned into a completion failure: the component answered,
    and its answer is over the frame bound or holds a value the wire codec
    refuses -- a fault that recurs every time, so it must reach the host with
    its real cause rather than end the worker, which would read as a disconnect
    and be retried. An attempt failure keeps its kind, with its cause's message
    cut to fit. An escaping error is resent with its message cut to the same
    budget, which the caller passes as the frame's text limit.
    """

    if isinstance(outcome, Completed):
        unsendable = CandidateEncodingError("the worker's result could not be sent")
        unsendable.__cause__ = error
        return CompletionFailed(
            lease=outcome.lease, error=unsendable, cause=reportable_cause(unsendable)
        )
    if isinstance(outcome, AttemptFailed):
        kind, text = outcome.cause
        return AttemptFailed(lease=outcome.lease, cause=(kind, bounded_text(text, budget)))
    return outcome  # Escaped: its message is cut by the frame's text limit


__all__ = ["Finished", "Lost", "serve"]
