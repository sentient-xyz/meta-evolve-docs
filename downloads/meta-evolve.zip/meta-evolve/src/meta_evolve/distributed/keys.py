"""The shared secret one dispatcher and its workers authenticate with.

Two ways in, by how the worker was started (D5):

- `WorkerProcesses` mints an ephemeral key per run and hands it to each child
  on stdin, so nothing about it ever reaches argv, the environment or a log;
- `WorkerHost` keeps one in a file an operator names, created private when
  absent and REUSED when present -- which is what lets a host restart and have
  the workers that already hold it reconnect (T24).

Every refusal here is loud, because the quiet alternatives are worse: a key
another user can read is not a secret, and a key regenerated over an existing
one locks out every worker holding the old one, with an authentication failure
as the only symptom.

The key authenticates a connection; it encrypts nothing. Multi-host use needs
TLS, which this package does not provide.
"""

from __future__ import annotations

import os
import secrets
import stat
from pathlib import Path

from meta_evolve.errors import CapabilityError

#: The length of a worker key. Not configurable: a shorter one is weaker with
#: no benefit, and a longer one buys nothing against HMAC-SHA256.
KEY_BYTES = 32


def mint_key() -> bytes:
    """A fresh key for one run's spawned workers."""

    return secrets.token_bytes(KEY_BYTES)


def key_file(path: str | Path) -> bytes:
    """The key at `path`, created private if it is not there yet.

    Created with `O_EXCL`, so two hosts racing to create the same file cannot
    both believe they wrote it: the loser reads what the winner wrote.
    """

    path = Path(path)
    try:
        descriptor = os.open(
            path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600
        )
    except FileExistsError:
        return read_key_file(path)
    except OSError as error:
        raise CapabilityError(
            f"cannot create the worker key file {path}: {error.strerror}"
        ) from None
    key = mint_key()
    with os.fdopen(descriptor, "w") as handle:
        handle.write(key.hex() + "\n")
    return key


def read_key_file(path: str | Path) -> bytes:
    """The key at `path`, refusing anything that is not one private line."""

    path = Path(path)
    try:
        info = os.lstat(path)
    except FileNotFoundError:
        raise CapabilityError(
            f"no key file at {path}: a worker authenticates with the key its "
            "dispatcher's host wrote, and never mints its own"
        ) from None
    except OSError as error:
        raise CapabilityError(
            f"cannot read the worker key file {path}: {error.strerror}"
        ) from None
    if not stat.S_ISREG(info.st_mode):
        raise CapabilityError(
            f"the worker key file {path} is not a regular file: a symlink or "
            "a device is not a secret this process can vouch for"
        )
    if stat.S_IMODE(info.st_mode) & 0o077:
        raise CapabilityError(
            f"the worker key file {path} is readable by other users "
            f"(mode {stat.S_IMODE(info.st_mode):04o}): chmod 600 it, and mint "
            "a new key if anyone else could have read this one"
        )
    text = path.read_text().strip()
    try:
        key = bytes.fromhex(text)
    except ValueError:
        key = b""
    if len(key) != KEY_BYTES:
        raise CapabilityError(
            f"the worker key file {path} is not {KEY_BYTES * 2} hex characters: "
            "it was written by something other than this host"
        )
    return key


__all__ = ["KEY_BYTES", "key_file", "mint_key", "read_key_file"]
