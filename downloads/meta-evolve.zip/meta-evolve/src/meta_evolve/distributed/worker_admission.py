"""The worker's half of the handshake: prove the key, then prove the build.

Blocking, because a worker process has nothing else to do until it is
admitted -- the host's half is the non-blocking one, since it shares a thread
with every lease in flight.

The order is what matters here. The worker sends nothing about the run and no
lease secret until `Terms` has proved the host holds the key, and it builds
its executors from the RECORDED start that `Terms` carries rather than from
its own module's declaration (PD10). A refusal it can verify is terminal: a
mismatched build or an id already in use is not something reconnecting fixes.
One it cannot verify is advisory, and the caller reconnects.
"""

from __future__ import annotations

import secrets
from collections.abc import Callable
from dataclasses import dataclass

from meta_evolve.application.dispatch_messages import TransportFailure
from meta_evolve.domain.context import ContextSpec
from meta_evolve.domain.events import RunStarted
from meta_evolve.domain.work import Lease

from .frames import DEFAULT_MAX_FRAME_BYTES, FrameReader, frame
from .handshake_codec import HandshakeRefused, decode_body, encode_body
from .handshake_envelope import (
    HANDSHAKE_DEADLINE_SECONDS,
    NONCE_BYTES,
    envelope_of,
    kind_of,
    seal,
    unseal,
)


class WorkerRefused(Exception):
    """The host refused this worker, and proved it holds the key.

    Terminal: a mismatched build or a taken id is not something a retry fixes,
    so the worker exits with the reason rather than reconnecting forever.
    """


@dataclass(frozen=True, slots=True)
class WorkerAdmission:
    """What an admitted worker serves with, all of it authenticated."""

    run_id: str
    started: RunStarted
    context: ContextSpec | None
    heartbeat_seconds: int
    max_frame_bytes: int
    evaluation: object
    proposal: object


def refusal_from(key: bytes, body: bytes) -> BaseException:
    """A `Refused` frame, as the exception the worker should end with."""

    envelope = envelope_of(body)
    if envelope["mac"] is not None:
        try:
            message = unseal("refused", key, body)
        except HandshakeRefused:
            return TransportFailure("a refusal this host could not prove")
        return WorkerRefused(message.get("reason", "refused"))
    try:
        reason = decode_body(envelope["body"]).get("reason", "refused")
    except HandshakeRefused:
        reason = "refused"
    # Unproven, so it is advisory only: the caller retries rather than exits.
    return TransportFailure(f"the host refused this connection ({reason})")


def worker_handshake(
    sock,
    *,
    key: bytes,
    worker_id: str,
    incarnation: str,
    fingerprint: str,
    build: Callable[[RunStarted, ContextSpec | None], tuple],
    held: tuple[Lease, ...] = (),
    run_of: Callable[[Lease], str] | None = None,
    timeout: float = HANDSHAKE_DEADLINE_SECONDS,
    max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES,
) -> WorkerAdmission:
    """The worker's blocking half. Raises `WorkerRefused` on a proved refusal.

    `build` is what turns the run's recorded start into this worker's
    executors and manifests (`experiment_modules.worker_executors`), so what
    it declares is what it would run -- and it is called only after `Terms`
    has proved the host holds the key.
    """

    sock.setblocking(True)
    sock.settimeout(timeout)
    reader = FrameReader(max_frame_bytes=max_frame_bytes)
    inbox: list[bytes] = []

    def read() -> bytes:
        while not inbox:
            chunk = sock.recv(65536)
            if not chunk:
                raise TransportFailure("the host closed the connection")
            inbox.extend(reader.feed(chunk))
        return inbox.pop(0)

    def expect(kind: str, body: bytes) -> dict:
        if kind_of(body) == "refused":
            raise refusal_from(key, body)
        # The challenge is the one frame no key could sign: it is what the
        # host sends before either end has proved anything.
        return unseal(kind, None if kind == "challenge" else key, body)

    worker_nonce = secrets.token_hex(NONCE_BYTES)
    challenge = expect("challenge", read())
    host_nonce = challenge["host_nonce"]
    sock.sendall(
        frame(
            seal(
                "hello",
                key,
                encode_body(
                    {
                        "host_nonce": host_nonce,
                        "worker_nonce": worker_nonce,
                        "worker_id": worker_id,
                        "incarnation": incarnation,
                        "fingerprint": fingerprint,
                    }
                ),
            ),
            max_frame_bytes=max_frame_bytes,
        )
    )
    terms = expect("terms", read())
    if terms.get("worker_nonce") != worker_nonce or terms.get("host_nonce") != host_nonce:
        raise TransportFailure("the host answered another connection's hello")
    evaluation, proposal, manifests = build(terms["started"], terms["context"])
    mine = tuple(
        lease
        for lease in held
        if run_of is None or run_of(lease) == terms["run_id"]
    )
    sock.sendall(
        frame(
            seal(
                "manifests",
                key,
                encode_body(
                    {
                        "host_nonce": host_nonce,
                        "worker_nonce": worker_nonce,
                        "manifests": manifests,
                        "held": mine,
                    }
                ),
            ),
            max_frame_bytes=terms["max_frame_bytes"],
        )
    )
    admitted = expect("admitted", read())
    if admitted.get("worker_nonce") != worker_nonce:
        raise TransportFailure("the host admitted another connection")
    sock.settimeout(None)
    return WorkerAdmission(
        run_id=terms["run_id"],
        started=terms["started"],
        context=terms["context"],
        heartbeat_seconds=terms["heartbeat_seconds"],
        max_frame_bytes=terms["max_frame_bytes"],
        evaluation=evaluation,
        proposal=proposal,
    )


__all__ = ["WorkerAdmission", "WorkerRefused", "worker_handshake"]
