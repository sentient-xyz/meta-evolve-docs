"""Framing: a length-prefixed body, and a reader that reassembles them.

A frame is a 4-byte big-endian length followed by that many bytes of UTF-8
JSON (`messages.py`). The length is checked against `max_frame_bytes` from the
header alone, before a byte of body is read or buffered, so a peer cannot make
the host allocate what it declares. A reader that has refused a header stays
refused: past it the stream has no frame boundary left to trust.

Its own module because two connections that share nothing else share this: a
`WireEndpoint` (`wire.py`) and the admission handshake (`handshake.py`), which
frames the same way under a smaller bound while a peer is still unauthenticated.
"""

from __future__ import annotations

import struct

from meta_evolve.application.dispatch_messages import TransportFailure

_HEADER = struct.Struct(">I")

#: The default bound on one frame. Artifacts travel inside `Work` frames, so
#: this is sized for a large artifact rather than for a message.
DEFAULT_MAX_FRAME_BYTES = 64 * 1024 * 1024

def frame(body: bytes, *, max_frame_bytes: int) -> bytes:
    """`body` framed, refused if the peer's reader would refuse it."""

    if len(body) > max_frame_bytes:
        raise TransportFailure(
            f"a {len(body)} bytes frame exceeds the {max_frame_bytes}-byte bound"
        )
    return _HEADER.pack(len(body)) + body


class FrameReader:
    """Reassemble frames from whatever chunks a socket delivers."""

    def __init__(self, *, max_frame_bytes: int) -> None:
        self._max = max_frame_bytes
        self._buffer = bytearray()
        self._failed = False

    @property
    def pending(self) -> bool:
        """Whether a partial frame is buffered."""

        return bool(self._buffer)

    def feed(self, data: bytes) -> list[bytes]:
        """Every frame `data` completes, in order."""

        if self._failed:
            raise TransportFailure("this connection already sent an invalid frame")
        self._buffer += data
        bodies: list[bytes] = []
        while len(self._buffer) >= _HEADER.size:
            (length,) = _HEADER.unpack_from(self._buffer)
            if length > self._max:
                self._failed = True
                self._buffer.clear()
                raise TransportFailure(
                    f"a frame declared {length} bytes, over the "
                    f"{self._max}-byte bound"
                )
            end = _HEADER.size + length
            if len(self._buffer) < end:
                break
            bodies.append(bytes(self._buffer[_HEADER.size : end]))
            del self._buffer[:end]
        return bodies


#: How much one read takes off a socket before the frame reader sees it.


__all__ = ["DEFAULT_MAX_FRAME_BYTES", "FrameReader", "frame"]
