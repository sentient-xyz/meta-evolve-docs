"""The host side of one wire connection.

`WireEndpoint` is one worker connection as the dispatch loop sees it: a
non-blocking socket, the frames in each direction, the pulls it has made and
the last time it was heard. It claims under the `WorkerRegistration` its
connection was admitted with. Writes are buffered and flushed by the loop, and one that has
not drained within `write_deadline_seconds` of REAL time fails the connection:
a peer that stops reading must not stall the only thread the store has.
"""

from __future__ import annotations

import time
from collections.abc import Callable

from meta_evolve.application.dispatch_messages import (
    WORKER_INTERRUPTED,
    AttemptFailed,
    Completed,
    CompletionFailed,
    Escaped,
    Goodbye,
    Heartbeat,
    Message,
    Pull,
    TransportFailure,
    Work,
)
from meta_evolve.domain.workers import WorkerRegistration

from .frames import DEFAULT_MAX_FRAME_BYTES, FrameReader, frame
from .messages import decode_message, encode_message


_CHUNK = 65536

#: How long, in REAL seconds, buffered bytes may wait for a peer to read them.
DEFAULT_WRITE_DEADLINE_SECONDS = 5.0

#: The messages a worker may send; anything else from one breaks the protocol.
_FROM_WORKER = (
    Pull,
    Heartbeat,
    Goodbye,
    Completed,
    AttemptFailed,
    CompletionFailed,
    Escaped,
)


class WireEndpoint:
    """One worker connection, host side."""

    answers_submissions = True

    def __init__(
        self,
        sock,
        *,
        registration: WorkerRegistration,
        clock: Callable[[], int],
        max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES,
        write_deadline_seconds: float = DEFAULT_WRITE_DEADLINE_SECONDS,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        sock.setblocking(False)
        self._sock = sock
        self.registration = registration
        self._max = max_frame_bytes
        self._reader = FrameReader(max_frame_bytes=max_frame_bytes)
        self._outgoing = bytearray()
        self._waiting_since: float | None = None
        self._deadline = write_deadline_seconds
        self._monotonic = monotonic
        self._pulls = 0
        self._closed = False
        self._eof = False
        #: Set when a `Goodbye` was read: the next read fails the connection
        #: with the cause the worker gave, after its earlier outcomes settle.
        self._farewell: str | None = None
        self._pending_outcomes = False
        #: When the loop last READ a heartbeat, in broker seconds. Connecting
        #: counts: a connection is heard from when it is admitted.
        self.last_heartbeat = clock()

    # -- the loop's view ------------------------------------------------------

    @property
    def registrations(self) -> tuple[WorkerRegistration, ...]:
        """The one identity this connection's claims are made under."""

        return (self.registration,)

    def fileno(self) -> int:
        return self._sock.fileno()

    def wants_work(self, bound: int) -> bool:
        return (
            not self._closed
            and self._pulls > 0
            and bound < self.registration.max_concurrent_leases
        )

    def alive(self, clock: Callable[[], int], window: int) -> bool:
        return not self._closed and clock() - self.last_heartbeat <= window

    def silent_for(self, clock: Callable[[], int]) -> int:
        return clock() - self.last_heartbeat

    @property
    def closed(self) -> bool:
        """Whether this connection is over, by either end's doing."""

        return self._closed

    def departed(self) -> str | None:
        """The reason this worker gave for leaving, once its outcomes are in."""

        if self._farewell is None:
            return None
        return f"the worker said goodbye ({self._farewell})"

    def start(self, work: Work) -> None:
        self._pulls -= 1
        self.send(work)

    def receive(self, clock: Callable[[], int]) -> tuple[Message, ...]:
        """Every outcome buffered on the socket; pulls and heartbeats applied.

        A heartbeat is stamped with the clock read HERE, when the loop reads
        it, never a worker's clock: that is what lets a frame buffered while
        the loop was blocked count (D10 rule 2).
        """

        if self._farewell is not None and not self._pending_outcomes:
            raise TransportFailure(
                f"the worker said goodbye ({self._farewell})", cause=WORKER_INTERRUPTED
            )
        bodies, closed = self._read_available()
        outcomes: list[Message] = []
        for body in bodies:
            message = decode_message(body)
            if not isinstance(message, _FROM_WORKER):
                raise TransportFailure(
                    f"a worker sent a host message ({type(message).__name__})"
                )
            if isinstance(message, Pull):
                self._pulls += 1
            elif isinstance(message, Heartbeat):
                self.last_heartbeat = clock()
            elif isinstance(message, Goodbye):
                # Settle what it sent BEFORE it left, exactly as an EOF does:
                # the outcome of a call that finished is not lost to the
                # farewell that followed it.
                self._farewell = message.reason
                self._pending_outcomes = bool(outcomes)
                if outcomes:
                    return tuple(outcomes)
                raise TransportFailure(
                    f"the worker said goodbye ({message.reason})",
                    cause=WORKER_INTERRUPTED,
                )
            else:
                outcomes.append(message)
        if self._farewell is not None:
            self._pending_outcomes = bool(outcomes)
            if outcomes:
                return tuple(outcomes)
            raise TransportFailure(
                f"the worker said goodbye ({self._farewell})", cause=WORKER_INTERRUPTED
            )
        if closed:
            if outcomes:
                # Settle what arrived before the close; the next read fails it.
                self._eof = True
                return tuple(outcomes)
            raise TransportFailure("the worker closed its connection")
        return tuple(outcomes)

    def send(self, message: Message) -> None:
        self._outgoing += frame(encode_message(message), max_frame_bytes=self._max)
        if self._waiting_since is None:
            self._waiting_since = self._monotonic()
        self.flush()

    def wants_write(self) -> bool:
        return bool(self._outgoing)

    def flush(self) -> None:
        if not self._outgoing:
            return
        try:
            sent = self._sock.send(self._outgoing)
        except (BlockingIOError, InterruptedError):
            sent = 0
        except OSError as error:
            raise TransportFailure(f"the connection failed ({type(error).__name__})") from None
        del self._outgoing[:sent]
        if not self._outgoing:
            self._waiting_since = None
        elif self._monotonic() - self._waiting_since > self._deadline:
            raise TransportFailure(
                f"a write did not drain within {self._deadline} seconds"
            )

    def farewell(self, reason: str) -> None:
        """Send `Goodbye`, flush it within the write deadline, then close.

        A buffered frame the loop never flushed would leave a worker unable to
        tell a finished run from a dispatcher that died, so this waits for the
        bytes rather than dropping them on close.
        """

        if self._closed:
            return
        try:
            self.send(Goodbye(reason=reason))
            while self._outgoing:
                self.flush()
        except (TransportFailure, OSError):
            pass  # it is already gone; closing is all that is left
        finally:
            self.close()

    def retire(self) -> None:
        """Nothing to retire host side: the worker's result is answered when it
        arrives, from the store, since this lease is no longer bound here."""

    def close(self) -> None:
        """Idempotent: the loop may have closed what `finish` closes again."""

        self._closed = True
        self._sock.close()

    # -- internals ------------------------------------------------------------

    def _read_available(self) -> tuple[list[bytes], bool]:
        """Every complete frame body available now, and whether the peer closed.

        Each chunk goes to the frame reader AS IT IS READ, so a header over the
        bound is refused before the next chunk is taken off the socket: what is
        ever buffered past a header is at most one chunk, never whatever the
        peer managed to queue.
        """

        if self._closed:
            raise TransportFailure("this connection is closed")
        if self._eof:
            return [], True
        bodies: list[bytes] = []
        while True:
            try:
                chunk = self._sock.recv(_CHUNK)
            except (BlockingIOError, InterruptedError):
                return bodies, False
            except OSError as error:
                raise TransportFailure(
                    f"the connection failed ({type(error).__name__})"
                ) from None
            if not chunk:
                return bodies, True
            bodies.extend(self._reader.feed(chunk))


__all__ = ["DEFAULT_WRITE_DEADLINE_SECONDS", "WireEndpoint"]
