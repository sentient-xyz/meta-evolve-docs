"""The transport between a dispatcher and the processes that run its work.

M11.3. The dispatcher's loop (`application/dispatch_loop.py`) speaks one message
protocol (`application/dispatch_messages.py`); this package is how those
messages cross a socket: the codec (`messages.py`), the frames and the host
side of a connection (`wire.py`), and the worker side (`worker.py`).

Two ways to run that work (D5), and they are what this package exports:
`WorkerProcesses`, the children a dispatcher spawns for its own run, and
`WorkerHost`, a port an operator's `meta-evolve worker` processes connect to.
Both are admitted by the same handshake (`handshake.py`), which proves the
shared key and then the build.

Stdlib only, trusted peers only. Multi-host use is documented and untested:
it needs TLS, which this package does not provide.
"""

from .host import WorkerHost
from .spawn import WorkerProcesses

__all__ = ["WorkerHost", "WorkerProcesses"]
