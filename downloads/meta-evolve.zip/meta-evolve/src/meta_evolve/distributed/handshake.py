"""The host's half of admission: proving the key, then proving the build.

Five messages; the peer proves the key before receiving run details:

    host   -> Challenge    unauthenticated, one fresh nonce
    worker -> Hello        identity, incarnation, fingerprint
    host   -> Terms        the RECORDED start, and this connection's limits
    worker -> Manifests    what its registry builds, and any lease it holds
    host   -> Admitted | Refused

`handshake_envelope.py` verifies a MAC over the received body before decoding
it. Its label binds the message kind and protocol version; the connection's
nonces prevent replay. `worker_admission.py` implements the other half.

Before Hello proves the key, reads use `HELLO_MAX_FRAME_BYTES`. Afterwards,
the connection's `max_frame_bytes` accommodates the recorded start in Terms.

The key authenticates a connection; it encrypts nothing. Multi-host use is
documented and untested: it needs TLS, which this package does not provide.
"""

from __future__ import annotations

import secrets
import time
from collections.abc import Callable
from dataclasses import replace

from meta_evolve.application.dispatch_messages import TransportFailure
from meta_evolve.domain.work import Lease
from meta_evolve.domain.workers import WorkerId, WorkerRegistration
from meta_evolve.errors import CapabilityError
from meta_evolve.manifests import verify_manifests
from meta_evolve.ports.escapes import escapes_normalization

from .admission import NONCE_CHARS, Admitted, HostAdmission, Refused, sealed_terms
from .frames import FrameReader, frame
from .handshake_codec import HandshakeRefused, encode_body
from .handshake_envelope import (
    HANDSHAKE_DEADLINE_SECONDS,
    HELLO_MAX_FRAME_BYTES,
    NONCE_BYTES,
    seal,
    unseal,
)
from .worker_identity import admitted_generation, refuse_identity

#: What a peer is told when its refusal would not fit a frame. Some reasons
#: echo the peer's own bytes, so their length is the peer's to choose.
REFUSAL_OVER_THE_BOUND = "this worker was refused; the reason exceeded the frame bound"


class HostHandshake:
    """One pending connection, advanced without ever blocking the loop."""

    def __init__(
        self,
        sock,
        *,
        admission: HostAdmission,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        sock.setblocking(False)
        self._sock = sock
        self._admission = admission
        self._monotonic = monotonic
        self._started_at = monotonic()
        self._reader = FrameReader(max_frame_bytes=HELLO_MAX_FRAME_BYTES)
        self._outgoing = bytearray()
        self._host_nonce = secrets.token_hex(NONCE_BYTES)
        self._hello: dict | None = None
        self._sent_challenge = False
        self._reservation = object()

    @property
    def socket(self):
        return self._sock

    def release_identity(self) -> None:
        """Release this connection's reservation, never another owner's."""

        self._admission.reservations.pop(self._reservation, None)

    def advance(self) -> Admitted | Refused | None:
        """One non-blocking step: `None` while the handshake is still in flight.

        A raise nothing here expected, on bytes a peer chose, refuses THIS
        connection rather than aborting the run (AD7); what a run must stop for
        (`escapes_normalization`) still stops it. The refusal is
        unauthenticated, so a host bug that raises on every Hello leaves its
        worker reconnecting rather than exiting.
        """

        if self._monotonic() - self._started_at > HANDSHAKE_DEADLINE_SECONDS:
            return self._refuse(
                f"the handshake passed its {HANDSHAKE_DEADLINE_SECONDS:.0f}-second "
                "deadline",
                authenticated=False,
            )
        try:
            self._flush()
            if not self._sent_challenge:
                self._send(
                    seal(
                        "challenge",
                        None,
                        encode_body({"host_nonce": self._host_nonce}),
                    )
                )
                self._sent_challenge = True
                return None
            body = self._read()
            if body is None:
                return None
            if self._hello is None:
                return self._on_hello(body)
            return self._on_manifests(body)
        except HandshakeRefused as refusal:
            return self._refuse(refusal.reason, authenticated=refusal.authenticated)
        except TransportFailure as failure:
            return self._refuse(str(failure), authenticated=False)
        except OSError as error:
            self.release_identity()
            return Refused(f"the connection failed ({type(error).__name__})", False)
        except Exception as error:
            # The type name only: the message can carry the peer's bytes.
            if escapes_normalization(error):
                raise
            refused = self._refuse(
                f"the handshake failed ({type(error).__name__})", authenticated=False
            )
            return replace(refused, error=error)

    # -- the two inbound messages -------------------------------------------

    def _on_hello(self, body: bytes) -> Admitted | Refused | None:
        hello = unseal("hello", self._admission.key, body)
        if hello.get("host_nonce") != self._host_nonce:
            raise HandshakeRefused(
                "the hello answered another connection's challenge", True
            )
        refusal = refuse_identity(hello, self._admission)
        if refusal is not None:
            raise HandshakeRefused(refusal, True)
        # The allow-list, and the capabilities its row declares, BEFORE the
        # build comparison and before `Terms`: a key-holder its operator never
        # enrolled learns nothing of this run -- not the recorded start, not the
        # manifests, not even whether its build matched. Read for the refusal
        # only; what decides the admission is the read at the reservation (AD2).
        admitted_generation(self._admission, WorkerId(hello["worker_id"]))
        if hello.get("fingerprint") != self._admission.fingerprint:
            raise HandshakeRefused(
                "this worker runs a different build from the dispatcher: its "
                "environment fingerprint does not match",
                True,
            )
        nonce = hello.get("worker_nonce")
        if (
            not isinstance(nonce, str)
            or len(nonce) != NONCE_CHARS
            or any(character not in "0123456789abcdefABCDEF" for character in nonce)
        ):
            # Hex cannot expand when echoed through JSON in the pre-sized Terms.
            raise HandshakeRefused(
                f"this worker's nonce must be {NONCE_CHARS} hexadecimal characters",
                True,
            )
        self._hello = hello
        # Proven: from here the connection may carry the run's record and, in
        # the other direction, the lease secrets a held result was issued under.
        self._reader = FrameReader(max_frame_bytes=self._admission.max_frame_bytes)
        self._send(
            sealed_terms(
                self._admission,
                host_nonce=self._host_nonce,
                worker_nonce=nonce,
            )
        )
        return None

    def _on_manifests(self, body: bytes) -> Admitted | Refused:
        assert self._hello is not None
        message = unseal("manifests", self._admission.key, body)
        if (
            message.get("host_nonce") != self._host_nonce
            or message.get("worker_nonce") != self._hello["worker_nonce"]
        ):
            raise HandshakeRefused("the manifests answered another connection", True)
        try:
            verify_manifests(self._admission.manifests, message["manifests"])
        except CapabilityError as mismatch:
            raise HandshakeRefused(str(mismatch), True) from None
        worker = WorkerId(self._hello["worker_id"])
        held = tuple(message.get("held") or ())
        for lease in held:
            if not isinstance(lease, Lease) or lease.worker_id != worker.value:
                raise HandshakeRefused(
                    "this worker listed a lease issued to another worker", True
                )
        # Several Hellos can precede any final admission. Recheck and reserve
        # in this same non-blocking step, before another handshake advances.
        refusal = refuse_identity(self._hello, self._admission)
        if refusal is not None:
            raise HandshakeRefused(refusal, True)
        # Read again, and this time for the number. An operator can revoke, or
        # revoke and re-trust with a narrower declaration (the
        # worker-administration plan's PD4), between the Hello and this frame
        # -- the worker spends that gap building its executors -- so a
        # generation or a declaration carried over from the first read would
        # be an authority the store has already withdrawn (AD2).
        generation = admitted_generation(self._admission, worker)
        self._admission.reservations[self._reservation] = (
            worker.value, self._hello["incarnation"]
        )
        self._send(
            seal(
                "admitted",
                self._admission.key,
                encode_body(
                    {
                        "host_nonce": self._host_nonce,
                        "worker_nonce": self._hello["worker_nonce"],
                        "worker_id": worker.value,
                    }
                ),
            )
        )
        self._flush()
        self._admission.admitted_ids.add(worker.value)
        return Admitted(
            registration=WorkerRegistration(
                worker=worker,
                generation=generation,
                max_concurrent_leases=1,
                environment_fingerprint=self._admission.fingerprint,
            ),
            incarnation=self._hello["incarnation"],
            held=held,
            supersedes=self._hello["worker_id"] in self._admission.live,
        )

    # -- framing -------------------------------------------------------------

    def _read(self) -> bytes | None:
        try:
            chunk = self._sock.recv(65536)
        except (BlockingIOError, InterruptedError):
            return None
        if not chunk:
            raise TransportFailure("the peer closed the connection")
        bodies = self._reader.feed(chunk)
        return bodies[0] if bodies else None

    def _send(self, body: bytes) -> None:
        self._outgoing += frame(body, max_frame_bytes=self._admission.max_frame_bytes)
        self._flush()

    def _flush(self) -> None:
        while self._outgoing:
            try:
                sent = self._sock.send(self._outgoing)
            except (BlockingIOError, InterruptedError):
                return
            del self._outgoing[:sent]

    def _refuse(self, reason: str, *, authenticated: bool) -> Refused:
        """Answer the refusal, sealed only when the key was already proved.

        A reason too large to frame goes out as the fallback, under the same
        key. Nothing may raise: `advance()` calls this from its handlers.
        """

        self.release_identity()
        key = self._admission.key if authenticated else None
        try:
            self._outgoing.clear()
            try:
                self._send(self._refusal(key, reason))
            except TransportFailure:
                self._send(self._refusal(key, REFUSAL_OVER_THE_BOUND))
            self._flush()
        except (OSError, TransportFailure):
            pass
        return Refused(reason, authenticated)

    def _refusal(self, key: bytes | None, reason: str) -> bytes:
        body = encode_body({"host_nonce": self._host_nonce, "reason": reason})
        return seal("refused", key, body)


__all__ = ["HostHandshake"]
