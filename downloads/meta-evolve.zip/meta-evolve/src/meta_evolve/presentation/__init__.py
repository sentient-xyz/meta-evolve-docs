"""Safe, dependency-free presentation over immutable artifact payloads.

The functions in this package intentionally consume only frozen payload data.
They return inert records and never return markup, URLs, or executable data.
"""

from __future__ import annotations

from meta_evolve.domain.values import canonical_payload_bytes
from meta_evolve.views import ArtifactView

from ._diff import diff
from ._preview import present
from .models import (
    ArtifactDiff,
    ArtifactPresentation,
    DiffLine,
    FileDiff,
    PresentationDocument,
    PresentationField,
    PresentationSection,
)


def _artifact(item: object) -> ArtifactView:
    if type(item) is not ArtifactView:
        raise TypeError("an exact ArtifactView instance is required")
    return item


def present_artifact(artifact: ArtifactView) -> ArtifactPresentation:
    """Return a bounded inert presentation of one frozen artifact payload."""

    return present(_artifact(artifact))


def diff_artifacts(parent: ArtifactView, child: ArtifactView) -> ArtifactDiff:
    """Return a bounded direct-parent diff for a supported artifact family."""

    return diff(parent, child)


def artifact_payload_bytes(artifact: ArtifactView) -> bytes:
    """Return exact ``canonical-payload-v1`` bytes used for content digesting."""

    return canonical_payload_bytes(_artifact(artifact)._payload)


__all__ = [
    "ArtifactDiff",
    "ArtifactPresentation",
    "DiffLine",
    "FileDiff",
    "PresentationDocument",
    "PresentationField",
    "PresentationSection",
    "artifact_payload_bytes",
    "diff_artifacts",
    "present_artifact",
]
