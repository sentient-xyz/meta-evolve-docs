"""Canonical frozen-value formatting without decoded-object operations."""

from __future__ import annotations

import json

from meta_evolve.domain.values import FrozenMap, FrozenValue


def plain_value(item: FrozenValue) -> object:
    if type(item) is FrozenMap:
        return {key: plain_value(value) for key, value in item.items()}
    if type(item) is tuple:
        return [plain_value(value) for value in item]
    if item is None or type(item) in {bool, int, float, str}:
        return item
    raise TypeError("artifact payload contains a non-canonical value")


def readable(item: FrozenValue) -> str:
    return json.dumps(
        plain_value(item),
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        indent=2,
    )


def text(item: object, name: str) -> str:
    if type(item) is not str:
        raise TypeError(f"{name} must be canonical text")
    return item


def mapping(item: object, name: str) -> FrozenMap:
    if type(item) is not FrozenMap:
        raise TypeError(f"{name} must be a canonical mapping")
    return item


__all__ = ["mapping", "readable", "text"]
