"""Bounded semantic diffs over inert text payloads."""

from __future__ import annotations

from difflib import SequenceMatcher

from meta_evolve.views import ArtifactView

from ._format import mapping, text
from ._preview import AGGREGATE_BYTES, DOCUMENT_BYTES, ENTRY_LIMIT
from .models import ArtifactDiff, DiffLine, FileDiff


OUTPUT_LINES = 4_000
_SUPPORTED = {
    ("text", "utf8-text-v1"),
    ("source-tree", "utf8-tree-v1"),
    ("skill-set", "utf8-tree-v1"),
}


def _documents(artifact: ArtifactView) -> dict[str | None, str]:
    key = (artifact.kind, artifact.representation)
    if key == ("text", "utf8-text-v1"):
        return {None: text(artifact._payload, "text payload")}
    payload = mapping(artifact._payload, "tree payload")
    return {path: text(body, "document text") for path, body in payload.items()}


def _status(before: str | None, after: str | None) -> str:
    if before is None:
        return "added"
    if after is None:
        return "removed"
    if before == after:
        return "unchanged"
    return "modified"


def _lines(before: str, after: str) -> tuple[DiffLine, ...]:
    old = before.splitlines(keepends=True)
    new = after.splitlines(keepends=True)
    result: list[DiffLine] = []
    matcher = SequenceMatcher(None, old, new, autojunk=False)
    for operation, old_start, old_end, new_start, new_end in matcher.get_opcodes():
        if operation == "equal":
            result.extend(
                DiffLine("unchanged", old_start + offset + 1, new_start + offset + 1, line)
                for offset, line in enumerate(old[old_start:old_end])
            )
        if operation in {"delete", "replace"}:
            result.extend(
                DiffLine("removed", old_start + offset + 1, None, line)
                for offset, line in enumerate(old[old_start:old_end])
            )
        if operation in {"insert", "replace"}:
            result.extend(
                DiffLine("added", None, new_start + offset + 1, line)
                for offset, line in enumerate(new[new_start:new_end])
            )
    return tuple(result)


def _validate(parent: object, child: object) -> tuple[ArtifactView, ArtifactView]:
    if type(parent) is not ArtifactView or type(child) is not ArtifactView:
        raise TypeError("diff_artifacts() requires exact ArtifactView instances")
    if parent._run_token is not child._run_token:
        raise ValueError("artifacts must belong to the same inspected run")
    if parent.id not in child.parent_ids:
        raise ValueError("the requested parent is not a direct parent of the child")
    parent_key = (parent.kind, parent.representation)
    child_key = (child.kind, child.representation)
    if parent_key != child_key or parent_key not in _SUPPORTED:
        raise ValueError("artifacts do not share a supported diff family")
    return parent, child


def diff(parent: object, child: object) -> ArtifactDiff:
    parent, child = _validate(parent, child)
    before = _documents(parent)
    after = _documents(child)
    paths = sorted(set(before) | set(after), key=lambda item: item or "")
    omitted = max(0, len(paths) - ENTRY_LIMIT)
    paths = paths[:ENTRY_LIMIT]
    files: list[FileDiff] = []
    aggregate = 0
    output = 0
    exhausted = False
    for path in paths:
        old = before.get(path)
        new = after.get(path)
        status = _status(old, new)
        # Identical content needs no line output; spending the shared line and
        # byte budgets on it could truncate real changes in later paths.
        if status == "unchanged":
            files.append(FileDiff(path, status))
            continue
        if exhausted:
            files.append(FileDiff(path, status, notice="Diff output omitted after the 4,000-line limit."))
            continue
        old_text = old or ""
        new_text = new or ""
        old_size = len(old_text.encode("utf-8"))
        new_size = len(new_text.encode("utf-8"))
        if old_size > DOCUMENT_BYTES or new_size > DOCUMENT_BYTES:
            files.append(FileDiff(path, status, notice="Diff skipped because one side exceeds 64 KiB."))
            continue
        if aggregate + old_size + new_size > AGGREGATE_BYTES:
            files.append(FileDiff(path, status, notice="Diff skipped because the aggregate input budget would exceed 256 KiB."))
            continue
        aggregate += old_size + new_size
        lines = _lines(old_text, new_text)
        remaining = OUTPUT_LINES - output
        if len(lines) > remaining:
            files.append(FileDiff(path, status, lines[:remaining], "Diff truncated at the 4,000-line output limit."))
            output += remaining
            exhausted = True
        else:
            files.append(FileDiff(path, status, lines))
            output += len(lines)
    return ArtifactDiff(
        parent_id=str(parent.id), child_id=str(child.id),
        parent_digest=parent.digest, child_digest=child.digest,
        kind=child.kind, representation=child.representation,
        files=tuple(files), omitted_files=omitted, output_truncated=exhausted,
    )


__all__ = ["OUTPUT_LINES", "diff"]
