"""Which one reason a stale submission is stale for, when several hold.

`Lease.credential_mismatch` and `Lease.proves_latest_attempt` each state one
rule; this states the ORDER they are asked in, alongside the row-state and
epoch checks around them, so acceptance and both brokers report the same reason
for the same row. The design record's "Stale reason" term is the vocabulary;
the order is D8's, revised after review:

1. Terminal rows first, and the epoch deliberately unchecked there -- the
   record's terminal exemption, which is what lets a duplicate be answered
   across a restart. A `COMPLETED` row checks attempt, then token; a
   `CANCELLED` row is `ENDED`.
2. `PRIOR_EPOCH`. Before the row, because a genuine cross-restart submission
   otherwise never reports it: `rollover` returns the row to `READY`, and a
   later `acquire` mints a new attempt, so an attempt-first order calls it
   `NOT_LEASED` or `SUPERSEDED_ATTEMPT`. An expired lease from before a restart
   reports the restart, which is the truer cause.
3. `STALE_GENERATION`, against the generation the store honours for this
   worker RIGHT NOW (PD2). Before the row for the same kind of reason as the
   epoch: a revoked lease loses its row -- the revocation sweep returns it to
   `READY` at the next broker write, and expiry gets there first meanwhile --
   so a row-first order would report `NOT_LEASED` or `EXPIRED` for a worker an
   operator had revoked, and the operator's command would be invisible in the
   answer. After the epoch, because a dispatcher another has taken over from is
   nobody's business but the fence's, however trustworthy its worker.
4. A `READY` row is `EXPIRED` when expiry is recognised from the verifier the
   row kept, and `NOT_LEASED` otherwise. Recognising it here is what lets a
   broker that swept expiry before classifying -- as every write does -- still
   say `EXPIRED` rather than the vaguer answer.
5. A `LEASED` row: the credential, then the held deadline, half-open. The
   credential's own generation rule stays: that one compares the presented
   lease against the STORED one, which catches a lease forged at a generation
   its row never held, and is a different question from whether the authority
   behind it still stands.

`None` means not stale: a live lease, or the accepted lease at a completed row
(a duplicate). The caller knows which by the state it passed in.

Pure: no storage, no clock of its own, and no registry -- `current_generation`
is the answer a caller read inside its own transaction. It is keyword-only with
NO DEFAULT, because no default could be honest: `None` would call every lease
stale, and a number would honour an authority nobody consulted. Decoding a
damaged row is the adapter's job, so a `LEASED` row without its held lease is
refused rather than classified.
"""

from __future__ import annotations

from .work import Lease, LeaseToken, StaleReason, WorkState


def stale_reason_for(
    presented: Lease,
    *,
    state: WorkState,
    held: Lease | None,
    attempts: int,
    verifier: LeaseToken | None,
    accepted_attempt: int | None,
    accepted_token: LeaseToken | None,
    current_epoch: int,
    current_generation: int | None,
    clock: int,
) -> StaleReason | None:
    """The reason `presented` is stale at this row, or `None` if it is not.

    `current_generation` is what the store's allow-list honours for the
    worker this lease names, read by the caller inside the transaction it is
    classifying in. `None` is the revoked-or-absent answer and equals no
    generation at all, so it never matches a presented one.
    """

    if state is WorkState.COMPLETED:
        if presented.attempt.ordinal != accepted_attempt:
            return StaleReason.SUPERSEDED_ATTEMPT
        if accepted_token is None or not presented.token.presents(accepted_token):
            return StaleReason.UNPROVEN_TOKEN
        return None
    if state is WorkState.CANCELLED:
        return StaleReason.ENDED
    if presented.epoch != current_epoch:
        return StaleReason.PRIOR_EPOCH
    if presented.generation != current_generation:
        return StaleReason.STALE_GENERATION
    if state in (WorkState.READY, WorkState.PREPARING):
        if presented.proves_latest_attempt(attempts, verifier):
            return StaleReason.EXPIRED
        return StaleReason.NOT_LEASED
    if held is None:
        raise ValueError(
            f"a LEASED row for {presented.item.value} must be classified with its "
            "held lease; a leased row without one is damage for the adapter to "
            "report, not a stale submission"
        )
    mismatch = presented.credential_mismatch(held)
    if mismatch is not None:
        return mismatch
    if held.expired_at(clock):
        return StaleReason.EXPIRED
    return None


__all__ = ["stale_reason_for"]
