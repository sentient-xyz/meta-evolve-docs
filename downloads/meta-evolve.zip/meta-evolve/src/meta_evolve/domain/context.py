"""Durable declarations and exact policy-pushed context observations."""

from __future__ import annotations

from dataclasses import dataclass

from .components import PolicyRef
from .experience import ExperienceRef, NON_CANDIDATE_EXPERIENCE_KINDS
from .values import _require_count, _require_text


@dataclass(frozen=True, slots=True, kw_only=True)
class ContextSpec:
    """One run-level context policy and its independent access bounds."""

    policy: PolicyRef
    max_records: int = 20
    max_chars: int = 8_000

    def __post_init__(self) -> None:
        if not isinstance(self.policy, PolicyRef):
            raise TypeError("context policy must be a PolicyRef")
        _require_count(self.max_records, "context max records")
        _require_count(self.max_chars, "context max chars")


@dataclass(frozen=True, slots=True, kw_only=True)
class ContextRecord:
    """An exact snapshot of one committed experience occurrence."""

    ref: ExperienceRef
    logical_step: int
    event_sequence: int
    value: object

    @property
    def kind(self) -> str:
        return self.ref.kind

    def __post_init__(self) -> None:
        if not isinstance(self.ref, ExperienceRef):
            raise TypeError("context record ref must be an ExperienceRef")
        _require_count(self.logical_step, "context record logical step")
        _require_count(self.event_sequence, "context record event sequence")
        if self.event_sequence < 1:
            raise ValueError("context record event sequence must be positive")


@dataclass(frozen=True, slots=True, kw_only=True)
class ContextUsage:
    """Selection usage, deliberately separate from task execution usage."""

    records: int = 0
    chars: int = 0

    def __post_init__(self) -> None:
        _require_count(self.records, "context usage records")
        _require_count(self.chars, "context usage chars")

    @property
    def record_count(self) -> int:
        return self.records

    @property
    def characters(self) -> int:
        return self.chars


@dataclass(frozen=True, slots=True, kw_only=True)
class ContextBundle:
    """The exact structured and rendered context observed by a proposer."""

    records: tuple[ContextRecord, ...] = ()
    rendered: str = ""
    reason: str = "no context policy declared"
    truncated: bool = False
    usage: ContextUsage = ContextUsage()

    def __post_init__(self) -> None:
        if not isinstance(self.records, tuple) or any(
            not isinstance(item, ContextRecord) for item in self.records
        ):
            raise TypeError("context bundle records must be ContextRecords")
        if len({item.ref for item in self.records}) != len(self.records):
            raise ValueError("context bundle records must be unique")
        if not isinstance(self.rendered, str):
            raise TypeError("context bundle rendered value must be text")
        _require_text(self.reason, "context bundle reason")
        if not isinstance(self.truncated, bool):
            raise TypeError("context bundle truncated value must be a boolean")
        if not isinstance(self.usage, ContextUsage):
            raise TypeError("context bundle usage must be ContextUsage")
        if self.usage.records != len(self.records):
            raise ValueError("context usage record count must match the bundle")
        if self.usage.chars != len(self.rendered):
            raise ValueError("context usage char count must match the rendering")

    @property
    def references(self) -> tuple[ExperienceRef, ...]:
        return tuple(item.ref for item in self.records)

    @property
    def rendering(self) -> str:
        return self.rendered

    @classmethod
    def empty(cls) -> ContextBundle:
        return cls()


def bundle_violation(
    bundle: ContextBundle,
    spec: ContextSpec,
    available: tuple[ContextRecord, ...],
    *,
    before_step: int,
) -> str | None:
    """Explain why a bundle is not an exact bounded selection of prior records.

    ``available`` is the committed experience in stream order. Eligible records
    are strictly prior to ``before_step`` and are not context facts themselves.
    Both live selection and replay validate through this single authority.
    """

    if bundle.usage.records > spec.max_records or bundle.usage.chars > spec.max_chars:
        return "selected context exceeds its declared bounds"
    eligible = tuple(
        item
        for item in available
        if item.logical_step < before_step and item.kind not in NON_CANDIDATE_EXPERIENCE_KINDS
    )
    source_by_ref = {item.ref: item for item in eligible}
    positions = {item.ref: index for index, item in enumerate(eligible)}
    selected_positions = []
    for record in bundle.records:
        if record.logical_step >= before_step:
            return "selected context must be strictly prior to its trial"
        source = source_by_ref.get(record.ref)
        if (
            source is None
            or record.logical_step != source.logical_step
            or record.event_sequence != source.event_sequence
            or record.value != source.value
        ):
            return "selected context contains inaccessible experience"
        selected_positions.append(positions[record.ref])
    if selected_positions != sorted(selected_positions):
        return "selected context records are not in canonical order"
    return None


__all__ = [
    "ContextBundle",
    "ContextRecord",
    "ContextSpec",
    "ContextUsage",
    "bundle_violation",
]
