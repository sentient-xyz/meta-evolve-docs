"""Durable declaration of the search authorized for one run."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from .components import ComponentRef, PolicyRef
from .values import FrozenMap, _freeze_map_field


@dataclass(frozen=True, slots=True, kw_only=True)
class SearchSpec:
    policy: PolicyRef
    configuration: Mapping[str, object] = field(default_factory=FrozenMap)
    proposer: ComponentRef

    def __post_init__(self) -> None:
        if not isinstance(self.policy, PolicyRef):
            raise TypeError("search policy must be a PolicyRef")
        _freeze_map_field(self, "configuration")
        if not isinstance(self.proposer, ComponentRef) or self.proposer.role != "proposer":
            raise TypeError("search proposer must be a proposer component reference")


__all__ = ["SearchSpec"]
