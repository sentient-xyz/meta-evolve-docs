"""Immutable, portable UTF-8 source trees."""

from __future__ import annotations

import os
import unicodedata
from bisect import bisect_left
from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import ClassVar

from .values import FrozenMap


_WINDOWS_RESERVED = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{index}" for index in range(1, 10)),
    *(f"LPT{index}" for index in range(1, 10)),
}
_WINDOWS_FORBIDDEN = frozenset('<>:"\\|?*')


def normalize_source_path(value: object) -> str:
    """Return one canonical portable relative POSIX path."""

    if not isinstance(value, str):
        raise TypeError("source path must be a string")
    normalized = unicodedata.normalize("NFC", value)
    try:
        normalized.encode("utf-8")
    except UnicodeEncodeError as error:
        raise ValueError("source path must be valid UTF-8 text") from error
    if not normalized or normalized.startswith("/") or "\x00" in normalized:
        raise ValueError("source path must be a non-empty relative path")
    if "\\" in normalized:
        raise ValueError("source path must use POSIX separators")
    parts = normalized.split("/")
    if any(not part or part in {".", ".."} for part in parts):
        raise ValueError("source path must be normalized without empty or dot segments")
    for part in parts:
        if part[-1] in {" ", "."} or any(char in _WINDOWS_FORBIDDEN for char in part):
            raise ValueError("source path contains a non-portable segment")
        if part.split(".", 1)[0].upper() in _WINDOWS_RESERVED:
            raise ValueError("source path contains a reserved segment")
    return "/".join(parts)


@dataclass(frozen=True, slots=True, init=False)
class SourceTree(Mapping[str, str]):
    """An immutable mapping from portable paths to exact UTF-8 text."""

    KIND: ClassVar[str] = "source-tree"
    REPRESENTATION: ClassVar[str] = "utf8-tree-v1"

    _files: tuple[tuple[str, str], ...]

    def __init__(
        self,
        files: Mapping[str, str] | Iterable[tuple[str, str]] = (),
    ) -> None:
        source = files.items() if isinstance(files, Mapping) else files
        canonical: list[tuple[str, str]] = []
        collision_keys: set[str] = set()
        for path, content in source:
            normalized = normalize_source_path(path)
            if not isinstance(content, str):
                raise TypeError(f"source content must be text: {normalized!r}")
            if "\x00" in content:
                raise ValueError(
                    f"source content must not contain NUL bytes: {normalized!r}"
                )
            try:
                content.encode("utf-8")
            except UnicodeEncodeError as error:
                raise ValueError(
                    f"source content must be valid UTF-8 text: {normalized!r}"
                ) from error
            collision_key = normalized.casefold()
            if collision_key in collision_keys:
                raise ValueError(
                    f"source paths must be unique across platforms: {normalized!r}"
                )
            collision_keys.add(collision_key)
            canonical.append((normalized, content))
        object.__setattr__(self, "_files", tuple(sorted(canonical)))

    def __getitem__(self, path: str) -> str:
        normalized = normalize_source_path(path)
        index = bisect_left(self._files, (normalized, ""))
        if index < len(self._files) and self._files[index][0] == normalized:
            return self._files[index][1]
        raise KeyError(path)

    def __iter__(self) -> Iterator[str]:
        return (path for path, _ in self._files)

    def __len__(self) -> int:
        return len(self._files)

    def __hash__(self) -> int:
        return hash(self._files)

    def __repr__(self) -> str:
        return f"SourceTree({dict(self._files)!r})"

    def to_payload(self) -> FrozenMap:
        return FrozenMap(self._files)

    @classmethod
    def from_payload(cls, value: object) -> SourceTree:
        if not isinstance(value, Mapping):
            raise TypeError("source-tree payload must be a mapping")
        files: list[tuple[str, str]] = []
        for path, content in value.items():
            if not isinstance(path, str) or not isinstance(content, str):
                raise TypeError("source-tree payload must map paths to text")
            files.append((path, content))
        return cls(files)


def load_source_tree(path: str | os.PathLike[str]) -> SourceTree:
    """Load a directory without following links or normalizing file content."""

    root = Path(path)
    if root.is_symlink():
        raise ValueError("source-tree root must not be a symlink")
    if not root.is_dir():
        raise ValueError("source-tree root must be a directory")

    files: list[tuple[str, str]] = []
    pending = [root]
    while pending:
        directory = pending.pop()
        with os.scandir(directory) as entries:
            for entry in entries:
                entry_path = Path(entry.path)
                relative = entry_path.relative_to(root).as_posix()
                if entry.is_symlink():
                    raise ValueError(
                        f"source trees cannot contain symlinks: {relative!r}"
                    )
                if entry.is_dir(follow_symlinks=False):
                    pending.append(entry_path)
                    continue
                if not entry.is_file(follow_symlinks=False):
                    raise ValueError(
                        f"source trees can contain only regular files: {relative!r}"
                    )
                data = entry_path.read_bytes()
                if b"\x00" in data:
                    raise ValueError(
                        f"source trees cannot contain binary files: {relative!r}"
                    )
                try:
                    content = data.decode("utf-8")
                except UnicodeDecodeError as error:
                    raise ValueError(
                        f"source trees can contain only UTF-8 files: {relative!r}"
                    ) from error
                files.append((relative, content))
    return SourceTree(files)


__all__ = ["SourceTree", "load_source_tree", "normalize_source_path"]
