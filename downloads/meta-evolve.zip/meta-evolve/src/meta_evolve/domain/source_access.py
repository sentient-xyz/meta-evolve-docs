"""Durable results for bounded access to prior source occurrences."""

from __future__ import annotations

from dataclasses import dataclass

from .experience import ExperienceRef
from .experience_access import ExperienceUsage
from .identity import ContentDigest
from .source_tree import normalize_source_path


SOURCE_DIFF_FORMAT = "meta-evolve-unified-diff/v1"
SOURCE_DIFF_STATUSES = ("added", "deleted", "modified")


def _artifact_ref(value: object, name: str) -> ExperienceRef:
    if not isinstance(value, ExperienceRef):
        raise TypeError(f"{name} must be an ExperienceRef")
    if value.kind != "artifact":
        raise ValueError(f"{name} must identify an artifact occurrence")
    return value


def _digest(value: object, name: str) -> None:
    if not isinstance(value, ContentDigest):
        raise TypeError(f"{name} must be a ContentDigest")


def _path(value: object) -> str:
    if not isinstance(value, str):
        raise TypeError("source path must be a string")
    if normalize_source_path(value) != value:
        raise ValueError("source path must already be normalized")
    return value


def _entries(value: object, kind: type, name: str) -> tuple:
    if not isinstance(value, tuple) or any(
        not isinstance(item, kind) for item in value
    ):
        raise TypeError(f"{name} must be a tuple of {kind.__name__} values")
    paths = tuple(item.path for item in value)
    if len(paths) != len(set(paths)):
        raise ValueError(f"{name} paths must be unique")
    return value


def _result_fields(
    rendered: object,
    truncated: object,
    usage: object,
    *,
    results: int,
    records: int,
) -> None:
    if not isinstance(rendered, str):
        raise TypeError("source rendering must be text")
    if not isinstance(truncated, bool):
        raise TypeError("source truncation must be a boolean")
    if not isinstance(usage, ExperienceUsage):
        raise TypeError("source usage must be ExperienceUsage")
    if (
        usage.results < results
        or usage.records < records
        or usage.chars < len(rendered)
    ):
        raise ValueError("source usage cannot undercount its result")


@dataclass(frozen=True, slots=True, kw_only=True)
class SourcePathListing:
    artifact_ref: ExperienceRef
    digest: ContentDigest
    usage: ExperienceUsage
    paths: tuple[str, ...] = ()
    rendered: str = ""
    truncated: bool = False

    def __post_init__(self) -> None:
        _artifact_ref(self.artifact_ref, "source listing artifact ref")
        _digest(self.digest, "source listing digest")
        if not isinstance(self.paths, tuple) or any(
            not isinstance(path, str) for path in self.paths
        ):
            raise TypeError("source listing paths must be a tuple of strings")
        if tuple(sorted(set(self.paths))) != self.paths:
            raise ValueError("source listing paths must be unique and ordered")
        for path in self.paths:
            _path(path)
        _result_fields(
            self.rendered, self.truncated, self.usage,
            results=1, records=len(self.paths),
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceFile:
    path: str
    source: str

    def __post_init__(self) -> None:
        _path(self.path)
        if not isinstance(self.source, str):
            raise TypeError("source file content must be text")


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceRead:
    artifact_ref: ExperienceRef
    digest: ContentDigest
    files: tuple[SourceFile, ...]
    usage: ExperienceUsage
    rendered: str = ""
    truncated: bool = False

    def __post_init__(self) -> None:
        _artifact_ref(self.artifact_ref, "source read artifact ref")
        _digest(self.digest, "source read digest")
        _entries(self.files, SourceFile, "source read files")
        _result_fields(
            self.rendered, self.truncated, self.usage,
            results=1, records=len(self.files),
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceDiffEntry:
    path: str
    status: str
    diff: str

    def __post_init__(self) -> None:
        _path(self.path)
        if self.status not in SOURCE_DIFF_STATUSES:
            raise ValueError(f"unsupported source diff status: {self.status!r}")
        if not isinstance(self.diff, str):
            raise TypeError("source diff entry must contain text")


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceDiff:
    older_artifact_ref: ExperienceRef
    newer_artifact_ref: ExperienceRef
    older_digest: ContentDigest
    newer_digest: ContentDigest
    usage: ExperienceUsage
    entries: tuple[SourceDiffEntry, ...] = ()
    format_version: str = SOURCE_DIFF_FORMAT
    rendered: str = ""
    truncated: bool = False

    def __post_init__(self) -> None:
        older = _artifact_ref(self.older_artifact_ref, "older source diff ref")
        newer = _artifact_ref(self.newer_artifact_ref, "newer source diff ref")
        if older.run_id != newer.run_id:
            raise ValueError("source diff refs must belong to one run")
        _digest(self.older_digest, "older source diff digest")
        _digest(self.newer_digest, "newer source diff digest")
        _entries(self.entries, SourceDiffEntry, "source diff entries")
        paths = tuple(entry.path for entry in self.entries)
        if paths != tuple(sorted(paths)):
            raise ValueError("source diff entry paths must be ordered")
        if self.format_version != SOURCE_DIFF_FORMAT:
            raise ValueError(f"source diff format must be {SOURCE_DIFF_FORMAT!r}")
        _result_fields(
            self.rendered, self.truncated, self.usage,
            results=2, records=len(self.entries),
        )


__all__ = [
    "SourceDiff",
    "SourceDiffEntry",
    "SourceFile",
    "SourcePathListing",
    "SourceRead",
]
