"""Opaque identities, schema versions, and content digests."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256

from .values import _require_text, canonical_payload_bytes


@dataclass(frozen=True, slots=True)
class SchemaVersion:
    value: int = 1

    def __post_init__(self) -> None:
        if (
            isinstance(self.value, bool)
            or not isinstance(self.value, int)
            or self.value < 1
        ):
            raise ValueError("schema version must be a positive integer")


CURRENT_SCHEMA_VERSION = SchemaVersion(3)


@dataclass(frozen=True, slots=True)
class _OpaqueId:
    value: str

    def __post_init__(self) -> None:
        _require_text(self.value, type(self).__name__)

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True, slots=True)
class RunId(_OpaqueId):
    pass


@dataclass(frozen=True, slots=True)
class EventId(_OpaqueId):
    pass


@dataclass(frozen=True, slots=True)
class CorrelationId(_OpaqueId):
    pass


@dataclass(frozen=True, slots=True)
class TaskId(_OpaqueId):
    pass


@dataclass(frozen=True, slots=True)
class ArtifactId(_OpaqueId):
    pass


@dataclass(frozen=True, slots=True)
class ProposalId(_OpaqueId):
    pass


@dataclass(frozen=True, slots=True)
class TrialId(_OpaqueId):
    pass


@dataclass(frozen=True, slots=True)
class EvaluationId(_OpaqueId):
    pass


@dataclass(frozen=True, slots=True)
class EvidenceId(_OpaqueId):
    pass


@dataclass(frozen=True, slots=True)
class DecisionId(_OpaqueId):
    pass


@dataclass(frozen=True, slots=True)
class ExperienceOperationId(_OpaqueId):
    pass


@dataclass(frozen=True, slots=True)
class ContentDigest:
    value: str
    algorithm: str = "sha256"

    def __post_init__(self) -> None:
        if self.algorithm != "sha256":
            raise ValueError("M1 supports only sha256 content digests")
        if len(self.value) != 64 or any(
            character not in "0123456789abcdef" for character in self.value
        ):
            raise ValueError(
                "sha256 digest must be 64 lowercase hexadecimal characters"
            )

    @classmethod
    def for_payload(cls, payload: object) -> ContentDigest:
        return cls(sha256(canonical_payload_bytes(payload)).hexdigest())
