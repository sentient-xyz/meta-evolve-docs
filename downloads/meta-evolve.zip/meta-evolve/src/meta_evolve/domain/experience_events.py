"""Auditable facts for declared and exercised pull-experience authority."""

from __future__ import annotations

from dataclasses import dataclass

from .experience_access import (
    ExperienceGrant,
    ExperienceComparison,
    ExperienceObservation,
    ExperienceRequest,
    ExperienceResult as LegacyExperienceResult,
    ExperienceSpec,
    ExperienceUsage,
)
from .identity import ExperienceOperationId, TrialId
from .source_access import SourceDiff, SourcePathListing, SourceRead


ExperienceResult = (
    LegacyExperienceResult | SourcePathListing | SourceRead | SourceDiff
)


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceAccessDeclared:
    spec: ExperienceSpec

    def __post_init__(self) -> None:
        if not isinstance(self.spec, ExperienceSpec):
            raise TypeError("declared experience access must be an ExperienceSpec")


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceGrantIssued:
    grant: ExperienceGrant

    def __post_init__(self) -> None:
        if not isinstance(self.grant, ExperienceGrant):
            raise TypeError("issued experience grant must be an ExperienceGrant")


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceOperationAttempted:
    operation_id: ExperienceOperationId
    trial_id: TrialId
    request: ExperienceRequest
    usage: ExperienceUsage

    def __post_init__(self) -> None:
        _validate_operation(self.operation_id, self.trial_id, self.usage)
        if not isinstance(self.request, ExperienceRequest):
            raise TypeError("experience attempt request must be ExperienceRequest")


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceOperationSucceeded:
    operation_id: ExperienceOperationId
    trial_id: TrialId
    result: ExperienceResult

    def __post_init__(self) -> None:
        if not isinstance(
            self.result,
            (
                ExperienceObservation,
                ExperienceComparison,
                SourcePathListing,
                SourceRead,
                SourceDiff,
            ),
        ):
            raise TypeError("experience success result must be an experience result")
        _validate_operation(self.operation_id, self.trial_id, self.result.usage)


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceOperationDenied:
    operation_id: ExperienceOperationId
    trial_id: TrialId
    usage: ExperienceUsage

    def __post_init__(self) -> None:
        _validate_operation(self.operation_id, self.trial_id, self.usage)


@dataclass(frozen=True, slots=True, kw_only=True)
class ExperienceOperationBudgetExhausted:
    operation_id: ExperienceOperationId
    trial_id: TrialId
    usage: ExperienceUsage

    def __post_init__(self) -> None:
        _validate_operation(self.operation_id, self.trial_id, self.usage)


def _validate_operation(
    operation_id: object, trial_id: object, usage: object
) -> None:
    if not isinstance(operation_id, ExperienceOperationId):
        raise TypeError("experience operation id must be an ExperienceOperationId")
    if not isinstance(trial_id, TrialId):
        raise TypeError("experience operation trial id must be a TrialId")
    if not isinstance(usage, ExperienceUsage):
        raise TypeError("experience operation usage must be ExperienceUsage")


ExperienceOperationResolution = (
    ExperienceOperationSucceeded
    | ExperienceOperationDenied
    | ExperienceOperationBudgetExhausted
)


__all__ = [
    "ExperienceAccessDeclared",
    "ExperienceGrantIssued",
    "ExperienceOperationAttempted",
    "ExperienceOperationBudgetExhausted",
    "ExperienceOperationDenied",
    "ExperienceOperationResolution",
    "ExperienceOperationSucceeded",
]
