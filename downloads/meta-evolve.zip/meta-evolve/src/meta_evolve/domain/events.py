"""Immutable facts used to replay the kernel search loop.

Slightly over the usual file-size guideline, and kept whole deliberately: this
is the durable event vocabulary, and every record here is validated against the
same serialization contract. Splitting it would scatter that vocabulary across
modules without making any part independently testable -- the records have no
behaviour beyond their own validation.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import TypeAlias

from .components import LEGACY_LOCAL_CAPABILITIES, PolicyRef, RunCapabilities
from .context import ContextBundle, ContextSpec
from .evaluation import Evaluation, Evidence, TrialOutcome
from .experience_events import (
    ExperienceAccessDeclared,
    ExperienceGrantIssued,
    ExperienceOperationAttempted,
    ExperienceOperationBudgetExhausted,
    ExperienceOperationDenied,
    ExperienceOperationSucceeded,
)
from .identity import (
    CURRENT_SCHEMA_VERSION,
    ArtifactId,
    CorrelationId,
    DecisionId,
    EventId,
    RunId,
    SchemaVersion,
    TaskId,
    TrialId,
)
from .task import Budget, Task
from .search_spec import SearchSpec
from .trial import ArchiveUpdate, Proposal, SearchDecision, Stop, Trial, TrialSpec
from .source_history import SourceHistoryMounted
from .values import FrozenMap, _freeze_map_field, _require_count, _require_text

@dataclass(frozen=True, slots=True, kw_only=True)
class RunStarted:
    task_id: TaskId
    task: Task
    seed_artifact_id: ArtifactId
    run_budget: Budget
    random_seed: int
    search: SearchSpec
    capabilities: RunCapabilities = LEGACY_LOCAL_CAPABILITIES

    def __post_init__(self) -> None:
        if not isinstance(self.task_id, TaskId):
            raise TypeError("started run task id must be a TaskId")
        if not isinstance(self.task, Task):
            raise TypeError("started run task must be a Task")
        if not isinstance(self.seed_artifact_id, ArtifactId):
            raise TypeError("started run seed artifact id must be an ArtifactId")
        if not isinstance(self.run_budget, Budget):
            raise TypeError("started run budget must be a Budget")
        if isinstance(self.random_seed, bool) or not isinstance(self.random_seed, int):
            raise TypeError("started run random seed must be an integer")
        if not isinstance(self.search, SearchSpec):
            raise TypeError("started run search must be a SearchSpec")
        if not isinstance(self.capabilities, RunCapabilities):
            raise TypeError("started run capabilities must be a RunCapabilities")


@dataclass(frozen=True, slots=True, kw_only=True)
class ArtifactCreated:
    artifact_id: ArtifactId

    def __post_init__(self) -> None:
        if not isinstance(self.artifact_id, ArtifactId):
            raise TypeError("created artifact id must be an ArtifactId")


@dataclass(frozen=True, slots=True, kw_only=True)
class BootstrapPrepared:
    trial: Trial
    proposal: Proposal

    def __post_init__(self) -> None:
        if not isinstance(self.trial, Trial):
            raise TypeError("bootstrap trial must be a Trial")
        if not isinstance(self.proposal, Proposal):
            raise TypeError("bootstrap proposal must be a Proposal")
        if self.trial.logical_step != 0:
            raise ValueError("bootstrap trial logical step must be zero")
        if self.proposal.trial_id != self.trial.id:
            raise ValueError("bootstrap proposal must belong to its trial")
        if self.proposal.parent_ids or self.trial.spec.parent_ids:
            raise ValueError("bootstrap trial and proposal cannot have parents")
        if self.proposal.operator.kind != "bootstrap":
            raise ValueError("bootstrap proposal must use the bootstrap operator")
        if self.trial.spec.operator != self.proposal.operator:
            raise ValueError("bootstrap trial and proposal operators must match")


@dataclass(frozen=True, slots=True, kw_only=True)
class ProposalSubmitted:
    proposal: Proposal

    def __post_init__(self) -> None:
        if not isinstance(self.proposal, Proposal):
            raise TypeError("submitted proposal must be a Proposal")


@dataclass(frozen=True, slots=True, kw_only=True)
class EvidenceRecorded:
    evidence: Evidence

    def __post_init__(self) -> None:
        if not isinstance(self.evidence, Evidence):
            raise TypeError("recorded evidence must be Evidence")


@dataclass(frozen=True, slots=True, kw_only=True)
class PolicyDecisionMade:
    decision_id: DecisionId
    logical_step: int
    observed_version: int
    policy: PolicyRef
    decision: SearchDecision
    trial_id: TrialId | None = None
    random_seeds: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    # What the policy actually observed, when that is not this decision's own
    # head: a cohort member after the first. Omitted at its default, so every
    # recorded stream keeps its bytes.
    cohort_base: int | None = field(
        default=None, metadata={"omit_if_default": True}
    )

    @property
    def policy_base(self) -> int:
        """The stream version the policy read to produce this decision.

        ``observed_version`` is always the head immediately before the decision,
        so no recorded field is ever false; for a cohort member after the first
        that head already contains its siblings, and the base is what replay
        must reconstruct the policy's input from. Branches on ``is None``, never
        on truthiness -- version zero is a legitimate base.
        """

        return self.observed_version if self.cohort_base is None else self.cohort_base

    def __post_init__(self) -> None:
        if not isinstance(self.decision_id, DecisionId):
            raise TypeError("policy decision id must be a DecisionId")
        _require_count(self.logical_step, "policy decision logical step")
        if self.logical_step < 1:
            raise ValueError("policy decision logical step must be positive")
        _require_count(self.observed_version, "policy decision observed version")
        if not isinstance(self.policy, PolicyRef):
            raise TypeError("policy decision policy must be a PolicyRef")
        if not isinstance(self.decision, (TrialSpec, ArchiveUpdate, Stop)):
            raise TypeError("policy decision must be a supported SearchDecision")
        if isinstance(self.decision, TrialSpec):
            if not isinstance(self.trial_id, TrialId):
                raise TypeError("trial decisions must commit a TrialId")
        elif self.trial_id is not None:
            raise ValueError("non-trial decisions cannot commit a trial id")
        if self.cohort_base is not None:
            _require_count(self.cohort_base, "policy decision cohort base")
            if not isinstance(self.decision, TrialSpec):
                raise ValueError("only trial decisions can record a cohort base")
            if self.cohort_base >= self.observed_version:
                raise ValueError(
                    "policy decision cohort base must precede its observed version"
                )
        seeds = _freeze_map_field(self, "random_seeds")
        for name, seed in seeds.items():
            if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
                raise ValueError(f"random seed {name!r} must be a non-negative integer")


@dataclass(frozen=True, slots=True, kw_only=True)
class PolicyDecisionExplained:
    decision_id: DecisionId
    rationale: str

    def __post_init__(self) -> None:
        if not isinstance(self.decision_id, DecisionId):
            raise TypeError("explained decision id must be a DecisionId")
        _require_text(self.rationale, "decision rationale")


@dataclass(frozen=True, slots=True, kw_only=True)
class ContextPolicyDeclared:
    spec: ContextSpec

    def __post_init__(self) -> None:
        if not isinstance(self.spec, ContextSpec):
            raise TypeError("declared context policy must be a ContextSpec")


@dataclass(frozen=True, slots=True, kw_only=True)
class ContextSelected:
    trial_id: TrialId
    policy: PolicyRef
    observed_version: int
    bundle: ContextBundle

    def __post_init__(self) -> None:
        if not isinstance(self.trial_id, TrialId):
            raise TypeError("context selection trial id must be a TrialId")
        if not isinstance(self.policy, PolicyRef):
            raise TypeError("context selection policy must be a PolicyRef")
        _require_count(self.observed_version, "context selection observed version")
        if not isinstance(self.bundle, ContextBundle):
            raise TypeError("selected context must be a ContextBundle")


@dataclass(frozen=True, slots=True, kw_only=True)
class TrialCompleted:
    trial: Trial
    outcome: TrialOutcome

    def __post_init__(self) -> None:
        if not isinstance(self.trial, Trial):
            raise TypeError("completed trial must be a Trial")
        if not isinstance(self.outcome, TrialOutcome):
            raise TypeError("completed trial outcome must be a TrialOutcome")
        if self.outcome.trial_id != self.trial.id:
            raise ValueError("completed trial and outcome ids must match")


@dataclass(frozen=True, slots=True, kw_only=True)
class EvaluationCompleted:
    evaluation: Evaluation

    def __post_init__(self) -> None:
        if not isinstance(self.evaluation, Evaluation):
            raise TypeError("completed evaluation must be an Evaluation")


EventBody: TypeAlias = (
    RunStarted
    | BootstrapPrepared
    | ArtifactCreated
    | ProposalSubmitted
    | EvidenceRecorded
    | PolicyDecisionMade
    | PolicyDecisionExplained
    | ContextPolicyDeclared
    | ContextSelected
    | ExperienceAccessDeclared
    | ExperienceGrantIssued
    | ExperienceOperationAttempted
    | ExperienceOperationSucceeded
    | ExperienceOperationDenied
    | ExperienceOperationBudgetExhausted
    | SourceHistoryMounted
    | TrialCompleted
    | EvaluationCompleted
)


@dataclass(frozen=True, slots=True, kw_only=True)
class EventEnvelope:
    id: EventId
    run_id: RunId
    sequence: int
    correlation_id: CorrelationId
    causation_id: EventId | None = None
    body: EventBody
    schema_version: SchemaVersion = CURRENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not isinstance(self.id, EventId):
            raise TypeError("event id must be an EventId")
        if not isinstance(self.run_id, RunId):
            raise TypeError("event run id must be a RunId")
        if (
            isinstance(self.sequence, bool)
            or not isinstance(self.sequence, int)
            or self.sequence < 1
        ):
            raise ValueError("event sequence must be a positive integer")
        if not isinstance(self.correlation_id, CorrelationId):
            raise TypeError("event correlation id must be a CorrelationId")
        if self.causation_id is not None and not isinstance(
            self.causation_id, EventId
        ):
            raise TypeError("event causation id must be an EventId or None")
        if not isinstance(
            self.body,
            (
                RunStarted,
                BootstrapPrepared,
                ArtifactCreated,
                ProposalSubmitted,
                EvidenceRecorded,
                PolicyDecisionMade,
                PolicyDecisionExplained,
                ContextPolicyDeclared,
                ContextSelected,
                ExperienceAccessDeclared,
                ExperienceGrantIssued,
                ExperienceOperationAttempted,
                ExperienceOperationSucceeded,
                ExperienceOperationDenied,
                ExperienceOperationBudgetExhausted,
                SourceHistoryMounted,
                TrialCompleted,
                EvaluationCompleted,
            ),
        ):
            raise TypeError("event body must be a supported event fact")
        if not isinstance(self.schema_version, SchemaVersion):
            raise TypeError("event schema version must be a SchemaVersion")
