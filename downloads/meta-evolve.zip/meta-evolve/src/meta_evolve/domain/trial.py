"""Artifacts, proposals, trials, and stop decisions."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, TypeAlias

if TYPE_CHECKING:
    from .events import PolicyDecisionMade

from .components import ComponentRef, PolicyRef
from .experience import ExperienceRef
from .identity import (
    CURRENT_SCHEMA_VERSION,
    ArtifactId,
    ContentDigest,
    DecisionId,
    EvaluationId,
    ProposalId,
    RunId,
    SchemaVersion,
    TaskId,
    TrialId,
)
from .task import Budget
from .values import (
    FrozenMap,
    FrozenValue,
    _freeze_map_field,
    _require_count,
    _require_ids,
    _require_text,
    freeze,
)


@dataclass(frozen=True, slots=True, kw_only=True)
class OperatorSpec:
    kind: str
    parameters: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)

    def __post_init__(self) -> None:
        _require_text(self.kind, "operator kind")
        _freeze_map_field(self, "parameters")


def normalize_operator(value: OperatorSpec | str) -> OperatorSpec:
    """Normalize the simple string shorthand before durable commitment."""

    if isinstance(value, OperatorSpec):
        return value
    if isinstance(value, str):
        return OperatorSpec(kind=value)
    raise TypeError("operator must be an OperatorSpec or string")


@dataclass(frozen=True, slots=True, kw_only=True)
class Artifact:
    """An immutable artifact occurrence with a validated content digest."""

    id: ArtifactId
    payload: FrozenValue
    digest: ContentDigest | None = None
    kind: str = "python-value"
    representation: str = "canonical-json"
    parent_ids: tuple[ArtifactId, ...] = ()
    provenance: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    schema_version: SchemaVersion = CURRENT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not isinstance(self.id, ArtifactId):
            raise TypeError("artifact id must be an ArtifactId")
        _require_text(self.kind, "artifact kind")
        _require_text(self.representation, "artifact representation")
        frozen_payload = freeze(self.payload)
        object.__setattr__(self, "payload", frozen_payload)
        expected_digest = ContentDigest.for_payload(frozen_payload)
        if self.digest is None:
            object.__setattr__(self, "digest", expected_digest)
        elif not isinstance(self.digest, ContentDigest):
            raise TypeError("artifact digest must be a ContentDigest")
        elif self.digest != expected_digest:
            raise ValueError("artifact digest does not match its payload")
        object.__setattr__(
            self,
            "parent_ids",
            _require_ids(self.parent_ids, ArtifactId, "artifact parent ids"),
        )
        _freeze_map_field(self, "provenance")
        if not isinstance(self.schema_version, SchemaVersion):
            raise TypeError("artifact schema version must be a SchemaVersion")


@dataclass(frozen=True, slots=True, kw_only=True)
class Proposal:
    """A trial's intended operation over explicit parent artifact ids."""

    id: ProposalId
    trial_id: TrialId
    parent_ids: tuple[ArtifactId, ...]
    operator: OperatorSpec
    hypothesis: str | None = None
    predicted_outcomes: FrozenMap | Mapping[str, object] = field(
        default_factory=FrozenMap
    )
    metadata: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    derived_from: tuple[ExperienceRef, ...] = field(
        default=(),
        metadata={"omit_if_default": True},
    )

    def __post_init__(self) -> None:
        if not isinstance(self.id, ProposalId):
            raise TypeError("proposal id must be a ProposalId")
        if not isinstance(self.trial_id, TrialId):
            raise TypeError("proposal trial id must be a TrialId")
        object.__setattr__(
            self,
            "parent_ids",
            _require_ids(self.parent_ids, ArtifactId, "proposal parent ids"),
        )
        if not isinstance(self.operator, OperatorSpec):
            raise TypeError("proposal operator must be an OperatorSpec")
        if self.hypothesis is not None:
            _require_text(self.hypothesis, "proposal hypothesis")
        _freeze_map_field(self, "predicted_outcomes")
        _freeze_map_field(self, "metadata")
        if not isinstance(self.derived_from, tuple) or any(
            not isinstance(item, ExperienceRef) for item in self.derived_from
        ):
            raise TypeError("proposal derivation must contain ExperienceRefs")
        if len(set(self.derived_from)) != len(self.derived_from):
            raise ValueError("proposal derivation references must be unique")


@dataclass(frozen=True, slots=True, kw_only=True)
class TrialSpec:
    """The requested task, parents, component, policy, and bounded work."""

    task_id: TaskId
    parent_ids: tuple[ArtifactId, ...]
    proposer: ComponentRef
    operator: OperatorSpec
    budget: Budget
    random_seed: int
    context_policy: PolicyRef | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.task_id, TaskId):
            raise TypeError("trial task id must be a TaskId")
        object.__setattr__(
            self,
            "parent_ids",
            _require_ids(self.parent_ids, ArtifactId, "trial parent ids"),
        )
        if (
            not isinstance(self.proposer, ComponentRef)
            or self.proposer.role != "proposer"
        ):
            raise TypeError("trial proposer must be a proposer component reference")
        if not isinstance(self.operator, OperatorSpec):
            raise TypeError("trial operator must be an OperatorSpec")
        if not isinstance(self.budget, Budget):
            raise TypeError("trial budget must be a Budget")
        if isinstance(self.random_seed, bool) or not isinstance(self.random_seed, int):
            raise TypeError("trial random seed must be an integer")
        if self.context_policy is not None and not isinstance(
            self.context_policy, PolicyRef
        ):
            raise TypeError("trial context policy must be a PolicyRef")


@dataclass(frozen=True, slots=True, kw_only=True)
class Trial:
    """An accepted trial tied to one run and search decision."""

    id: TrialId
    run_id: RunId
    decision_id: DecisionId
    logical_step: int
    spec: TrialSpec

    def __post_init__(self) -> None:
        if not isinstance(self.id, TrialId):
            raise TypeError("trial id must be a TrialId")
        if not isinstance(self.run_id, RunId):
            raise TypeError("trial run id must be a RunId")
        if not isinstance(self.decision_id, DecisionId):
            raise TypeError("trial decision id must be a DecisionId")
        _require_count(self.logical_step, "trial logical step")
        if not isinstance(self.spec, TrialSpec):
            raise TypeError("trial spec must be a TrialSpec")

    @classmethod
    def from_decision_record(
        cls, record: PolicyDecisionMade, run_id: RunId
    ) -> Trial:
        """Reconstruct the trial a committed trial decision authorized.

        The single place both ``commit_decision`` (recording a live decision)
        and ``resume``'s TRIAL_DECIDED recovery (re-driving a decided-but-
        unexecuted trial) build a ``Trial`` from a ``PolicyDecisionMade``, so
        the two stay byte-identical. The record's ``decision`` must be a
        ``TrialSpec`` and its ``trial_id`` must be present — guaranteed for a
        trial decision by ``PolicyDecisionMade``'s own validation.
        """

        return cls(
            id=record.trial_id,
            run_id=run_id,
            decision_id=record.decision_id,
            logical_step=record.logical_step,
            spec=record.decision,
        )


@dataclass(frozen=True, slots=True, kw_only=True)
class Stop:
    reason: str
    metadata: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)

    def __post_init__(self) -> None:
        _require_text(self.reason, "stop reason")
        _freeze_map_field(self, "metadata")


@dataclass(frozen=True, slots=True, kw_only=True)
class ArchiveUpdate:
    """A policy's record-only transition of explicit archive membership."""

    evaluation_id: EvaluationId
    candidate_id: ArtifactId
    admitted: bool
    evicted_artifact_id: ArtifactId | None = None
    member_ids: tuple[ArtifactId, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.evaluation_id, EvaluationId):
            raise TypeError("archive update evaluation id must be an EvaluationId")
        if not isinstance(self.candidate_id, ArtifactId):
            raise TypeError("archive update candidate id must be an ArtifactId")
        if not isinstance(self.admitted, bool):
            raise TypeError("archive update admitted status must be a boolean")
        if self.evicted_artifact_id is not None and not isinstance(
            self.evicted_artifact_id, ArtifactId
        ):
            raise TypeError("evicted artifact id must be an ArtifactId or None")
        object.__setattr__(
            self,
            "member_ids",
            _require_ids(self.member_ids, ArtifactId, "archive member ids"),
        )


SearchDecision: TypeAlias = TrialSpec | ArchiveUpdate | Stop
