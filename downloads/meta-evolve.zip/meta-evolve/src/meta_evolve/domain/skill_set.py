"""A set of named skill documents, laid out for a reader that renders them.

The kind is ``"skill-set"`` while the representation stays ``"utf8-tree-v1"``:
the same portable UTF-8 tree bytes carry a different schema, which is what the
kind/representation split is for. Every path, encoding, and collision rule is
``SourceTree``'s, applied by wrapping its construction rather than repeating
it; this type adds exactly one rule of its own, layout.

Layout is the whole schema. There is no manifest — no consumer in this
milestone needs one — and no content validation: what a skill *says* belongs to
whoever reads it, so an empty skill is a legal candidate and is scored like any
other.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass
from typing import ClassVar

from .source_tree import SourceTree
from .values import FrozenMap


_SKILL_PATH = re.compile(r"skills/[^/]+\.md")


@dataclass(frozen=True, slots=True, init=False)
class SkillSet(Mapping[str, str]):
    """An immutable mapping from ``skills/<name>.md`` to exact UTF-8 text.

    The application decides how documents become agent instructions. A skill
    library's content can evolve while its evaluator and task remain fixed.
    """

    KIND: ClassVar[str] = "skill-set"
    REPRESENTATION: ClassVar[str] = SourceTree.REPRESENTATION

    _tree: SourceTree

    def __init__(
        self,
        skills: Mapping[str, str] | Iterable[tuple[str, str]] = (),
    ) -> None:
        tree = SourceTree(skills)
        for path in tree:
            if not _SKILL_PATH.fullmatch(path):
                raise ValueError(f"skill paths must match skills/<name>.md: {path!r}")
        object.__setattr__(self, "_tree", tree)

    def __getitem__(self, path: str) -> str:
        return self._tree[path]

    def __iter__(self) -> Iterator[str]:
        return iter(self._tree)

    def __len__(self) -> int:
        return len(self._tree)

    def __hash__(self) -> int:
        return hash(self._tree)

    def __repr__(self) -> str:
        return f"SkillSet({dict(self._tree)!r})"

    def to_payload(self) -> FrozenMap:
        return self._tree.to_payload()

    @classmethod
    def from_payload(cls, value: object) -> SkillSet:
        return cls(SourceTree.from_payload(value))


__all__ = ["SkillSet"]
