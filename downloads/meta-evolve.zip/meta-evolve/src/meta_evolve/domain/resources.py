"""Component-reported costs, independent of engine-owned logical counts."""

from __future__ import annotations

from dataclasses import dataclass

from .values import _require_count, _require_measurement


@dataclass(frozen=True, slots=True, kw_only=True)
class Resources:
    """Immutable component costs, additive with ``+``.

    Use in [ProposalResult][meta_evolve.ProposalResult] and
    [EvaluationResult][meta_evolve.EvaluationResult]. Plain candidates, scalars,
    and metric mappings need no wrapper. The engine owns trial/evaluation
    counts; these are only available on returned [Usage][meta_evolve.Usage].

    Forward ``inner.usage().resources`` from a nested evaluator, adding its own
    costs exactly once. Failed work still costs resources. Unknown spend stays
    unknown when added; estimates belong in evidence.

    :param tokens: Non-negative integer token count, default zero.
    :param spend_micros: Billed micro-USD, default ``0`` for known free work;
        explicitly use ``None`` when unknown. Booleans are not counts.
    :param wall_seconds: Non-negative finite elapsed work, default ``0.0``.
        Aggregation sums reported work, not concurrent wall-clock duration.
    """

    tokens: int = 0
    spend_micros: int | None = 0
    wall_seconds: float = 0.0

    def __post_init__(self) -> None:
        _require_count(self.tokens, "tokens")
        if self.spend_micros is not None:
            _require_count(self.spend_micros, "spend_micros")
        object.__setattr__(
            self, "wall_seconds", _require_measurement(self.wall_seconds, "wall_seconds")
        )

    def __add__(self, other: object) -> Resources:
        if not isinstance(other, Resources):
            return NotImplemented
        return Resources(
            tokens=self.tokens + other.tokens,
            spend_micros=(None if self.spend_micros is None or other.spend_micros is None
                          else self.spend_micros + other.spend_micros),
            wall_seconds=self.wall_seconds + other.wall_seconds,
        )


__all__ = ["Resources"]
