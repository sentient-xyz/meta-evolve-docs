"""Trusted-worker identity, generation, declared capability and capacity.

Its own module because worker state has different writers from work rows: a
registration is held by the dispatcher that minted it, and a trust row is
written only by an operator, once per store. The id grammar and the reserved
`worker-` namespace live here because the door, the `worker` verb and the
registry all apply them. None of these values is in `DURABLE_TYPES`: the trust
table sits outside the run event stream.
"""

from __future__ import annotations

import enum
from collections.abc import Mapping
from dataclasses import dataclass, replace
from hashlib import sha256
from typing import TypeGuard

from .identity import RunId, _OpaqueId
from .values import (
    FrozenMap,
    _freeze_map_field,
    _require_count,
    _require_generation,
    _require_text,
)

#: The prefix a dispatcher mints slot ids with (D3), reserved from any worker
#: that names itself (AD3).
RESERVED_PREFIX = "worker-"

#: The two refusals an id can earn, written once for every place that applies them.
MALFORMED_WORKER_ID = (
    "this worker's id is not 1-128 characters of ASCII letters, digits, and ._:-"
)
RESERVED_WORKER_ID = (
    f"{RESERVED_PREFIX!r} is reserved for the ids a dispatcher "
    "mints for the workers it spawns"
)

#: The recorded cause on an attempt the sweep ends because its worker was
#: revoked. In the domain because adapters write it (PD3).
WORKER_REVOKED = "WorkerRevoked"


def revoked_attempt_cause(worker_id: str) -> tuple[str, str]:
    """The `(type, message)` pair both sweeps record against such an attempt.

    It names the worker, not the item: the row already says which item.
    """

    return (WORKER_REVOKED, f"worker {worker_id} was revoked while it held this attempt")


def is_valid_worker_id(value: object) -> TypeGuard[str]:
    """Whether `value` is text an id may be spelled with; any `Hello` value may be asked."""

    return (
        isinstance(value, str)
        and 1 <= len(value) <= 128
        and all(
            character.isascii() and (character.isalnum() or character in "._:-")
            for character in value
        )
    )


def in_reserved_namespace(value: str) -> bool:
    """Whether `value` names a worker a dispatcher minted an id for."""

    return value.startswith(RESERVED_PREFIX)


@dataclass(frozen=True, slots=True)
class WorkerId(_OpaqueId):
    """One worker's identity, and which of the two kinds it is.

    `for_slot` derives a dispatcher's own id from the run and the executor slot
    rather than from randomness, so a restart that rebuilds the same slots
    mints the same ids. `operator_supplied` takes the text an operator typed,
    the only kind an operator can enrol or revoke.
    """

    @classmethod
    def operator_supplied(cls, value: str) -> WorkerId:
        """The one constructor for an id an operator typed."""

        if not is_valid_worker_id(value):
            raise ValueError(MALFORMED_WORKER_ID)
        if in_reserved_namespace(value):
            raise ValueError(RESERVED_WORKER_ID)
        return cls(value)

    @classmethod
    def for_slot(cls, run_id: RunId, slot: int) -> WorkerId:
        if not isinstance(run_id, RunId):
            raise TypeError("worker run id must be a RunId")
        _require_count(slot, "worker slot")
        digest = sha256(
            f"meta-evolve/worker/v1|{run_id.value}|{slot}".encode("utf-8")
        ).hexdigest()
        return cls(f"{RESERVED_PREFIX}{digest}")

    @property
    def is_dispatcher_minted(self) -> bool:
        """Whether a dispatcher minted this id: then it needs no trust row and
        cannot be revoked (AD3)."""

        return in_reserved_namespace(self.value)


class TrustStatus(enum.Enum):
    """Whether an operator's registry currently honours a worker. A closed set;
    absence (never enrolled) is not a member."""

    TRUSTED = "trusted"
    REVOKED = "revoked"


@dataclass(frozen=True, slots=True, kw_only=True)
class TrustedWorker:
    """One row of the operator's allow-list: who may claim, and at which
    generation. A malformed or dispatcher-minted id is refused (AD3).
    """

    worker: WorkerId
    generation: int
    status: TrustStatus
    capabilities: FrozenMap | Mapping[str, object]

    def __post_init__(self) -> None:
        if not isinstance(self.worker, WorkerId):
            raise TypeError("trusted worker must be a WorkerId")
        if not is_valid_worker_id(self.worker.value):
            raise ValueError(MALFORMED_WORKER_ID)
        if self.worker.is_dispatcher_minted:
            raise ValueError(RESERVED_WORKER_ID)
        _require_generation(self.generation, "trusted worker")
        if not isinstance(self.status, TrustStatus):
            raise TypeError("trusted worker status must be a TrustStatus")
        _freeze_map_field(self, "capabilities")

    def revoked(self) -> TrustedWorker:
        """This worker, revoked: the generation bumped AND the row marked (AD2).

        Already revoked, it is returned unchanged, so a repeated revoke does not
        bump twice.
        """

        if self.status is TrustStatus.REVOKED:
            return self
        return replace(
            self, generation=self.generation + 1, status=TrustStatus.REVOKED
        )

    def retrusted(self, capabilities: Mapping[str, object]) -> TrustedWorker:
        """This worker trusted again, at the generation its revoke reached.

        The capabilities are REPLACED, not merged: this is the only path that
        narrows them (PD4). The generation is kept, since handing back the old
        number would validate the leases the revoke invalidated.
        """

        if self.status is not TrustStatus.REVOKED:
            raise ValueError(
                "only a revoked worker is re-trusted; a trusted worker's "
                "capabilities are widened, never replaced"
            )
        return replace(self, status=TrustStatus.TRUSTED, capabilities=capabilities)


def honoured_generation(worker: WorkerId, row: TrustedWorker | None) -> int | None:
    """Which generation a store honours for `worker` right now, if any.

    Shared by the door, the broker and the staleness classifier. `None` is the
    revoked-or-absent answer and matches no presented generation (PD2).
    """

    if not isinstance(worker, WorkerId):
        raise TypeError("honoured generation worker must be a WorkerId")
    if row is not None and row.worker != worker:
        raise ValueError("this trust row belongs to another worker")
    if worker.is_dispatcher_minted:
        return 1
    if row is None or row.status is not TrustStatus.TRUSTED:
        return None
    return row.generation


@dataclass(frozen=True, slots=True, kw_only=True)
class WorkerRegistration:
    """What the broker checks a claim against, read inside its transaction."""

    worker: WorkerId
    generation: int
    max_concurrent_leases: int
    environment_fingerprint: str

    # `generation` is what `honoured_generation` answered at admission. A claim
    # is weighed against what the REGISTRY honours at that moment, never against
    # the generation stored beside the lease, which a later revoke leaves intact.

    def __post_init__(self) -> None:
        if not isinstance(self.worker, WorkerId):
            raise TypeError("registration worker must be a WorkerId")
        _require_generation(self.generation, "registration")
        if (
            isinstance(self.max_concurrent_leases, bool)
            or not isinstance(self.max_concurrent_leases, int)
        ):
            raise TypeError("registration capacity must be an integer")
        if self.max_concurrent_leases < 1:
            raise ValueError("registration capacity must admit at least one lease")
        _require_text(self.environment_fingerprint, "registration fingerprint")

    def admits_one_more(self, *, currently_held: int) -> bool:
        """Whether a worker holding ``currently_held`` leases may take another.

        Named for the claim under consideration rather than `admits(held=)`: the
        `+ 1` is the claim being weighed, and a signature that hides it invites a
        caller to pass the post-claim count and get an off-by-one.
        """

        _require_count(currently_held, "held leases")
        return currently_held + 1 <= self.max_concurrent_leases


__all__ = [
    "MALFORMED_WORKER_ID",
    "RESERVED_PREFIX",
    "RESERVED_WORKER_ID",
    "TrustStatus",
    "TrustedWorker",
    "WORKER_REVOKED",
    "WorkerId",
    "WorkerRegistration",
    "honoured_generation",
    "in_reserved_namespace",
    "is_valid_worker_id",
    "revoked_attempt_cause",
]
