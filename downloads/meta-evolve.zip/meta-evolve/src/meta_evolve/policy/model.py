"""Trusted, declarative search-policy artifacts and mutation surfaces."""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import ClassVar, TypeAlias

from meta_evolve.domain import ComponentRef, ContentDigest, Failure, InvalidOutput
from meta_evolve.domain.values import FrozenValue, _require_count, _require_text, freeze
from meta_evolve.mutation import MutationApplication


_PARENT_COMPONENT = ComponentRef(
    role="policy-surface", name="parent-selection", version="1"
)
_LIMIT_COMPONENT = ComponentRef(role="policy-surface", name="trial-limit", version="1")


@dataclass(frozen=True, slots=True)
class PolicyMutation:
    """One request to change exactly one policy-artifact surface."""

    surface: str
    value: FrozenValue

    def __post_init__(self) -> None:
        _require_text(self.surface, "mutation surface")
        object.__setattr__(self, "value", freeze(self.value))


@dataclass(frozen=True, slots=True)
class ParentSelection:
    """Whether each trial expands the original seed or current incumbent."""

    mode: str
    name: str = field(default="parent_selection", init=False)
    component: ComponentRef = field(default=_PARENT_COMPONENT, init=False)
    interface: str = field(default="parent-selection/v1", init=False)

    def __post_init__(self) -> None:
        if self.mode not in {"seed", "incumbent"}:
            raise ValueError("parent selection mode must be 'seed' or 'incumbent'")

    def apply(
        self, mutation: PolicyMutation
    ) -> MutationApplication[ParentSelection]:
        failure = _target_failure(self.name, mutation)
        if failure is not None:
            return MutationApplication(failure=failure)
        if not isinstance(mutation.value, str) or mutation.value not in {
            "seed",
            "incumbent",
        }:
            return MutationApplication(
                failure=InvalidOutput(
                    message="parent selection must be 'seed' or 'incumbent'",
                    details={"surface": self.name},
                )
            )
        if mutation.value == self.mode:
            return _no_op(self.name)
        return MutationApplication(surface=replace(self, mode=mutation.value))


@dataclass(frozen=True, slots=True)
class TrialLimit:
    """A voluntary stopping limit, always subordinate to the run budget."""

    max_trials: int
    name: str = field(default="trial_limit", init=False)
    component: ComponentRef = field(default=_LIMIT_COMPONENT, init=False)
    interface: str = field(default="trial-limit/v1", init=False)

    def __post_init__(self) -> None:
        _require_count(self.max_trials, "trial limit max_trials")

    def apply(self, mutation: PolicyMutation) -> MutationApplication[TrialLimit]:
        failure = _target_failure(self.name, mutation)
        if failure is not None:
            return MutationApplication(failure=failure)
        try:
            max_trials = _require_count(mutation.value, "trial limit max_trials")
        except ValueError as error:
            return MutationApplication(
                failure=InvalidOutput(
                    message="trial limit must be a non-negative integer",
                    details={"surface": self.name, "error": str(error)},
                )
            )
        if max_trials == self.max_trials:
            return _no_op(self.name)
        return MutationApplication(surface=replace(self, max_trials=max_trials))


PolicySurface: TypeAlias = ParentSelection | TrialLimit


@dataclass(frozen=True, slots=True)
class PolicyArtifact:
    """Schema-v1 data interpreted only by the trusted candidate policy."""

    KIND: ClassVar[str] = "search-policy"
    REPRESENTATION: ClassVar[str] = "policy-manifest-v1"

    parent_selection: ParentSelection
    trial_limit: TrialLimit

    def __post_init__(self) -> None:
        if not isinstance(self.parent_selection, ParentSelection):
            raise TypeError("policy parent_selection must be ParentSelection")
        if not isinstance(self.trial_limit, TrialLimit):
            raise TypeError("policy trial_limit must be TrialLimit")

    def apply(self, mutation: PolicyMutation) -> PolicyArtifact | Failure:
        if not isinstance(mutation, PolicyMutation):
            raise TypeError("mutation must be a PolicyMutation")
        for field_name in ("parent_selection", "trial_limit"):
            current = getattr(self, field_name)
            if current.name != mutation.surface:
                continue
            application = current.apply(mutation)
            if application.failure is not None:
                return application.failure
            assert application.surface is not None
            return replace(self, **{field_name: application.surface})
        return InvalidOutput(
            message="mutation names an undeclared policy surface",
            details={"surface": mutation.surface},
        )

    @property
    def digest(self) -> str:
        from .codec import PolicyArtifactCodec

        return ContentDigest.for_payload(PolicyArtifactCodec().encode(self)).value


def _target_failure(name: str, mutation: object) -> InvalidOutput | None:
    if not isinstance(mutation, PolicyMutation):
        raise TypeError("mutation must be a PolicyMutation")
    if mutation.surface != name:
        return InvalidOutput(
            message="mutation targets a different policy surface",
            details={"declared": name, "requested": mutation.surface},
        )
    return None


def _no_op(name: str) -> MutationApplication[object]:
    return MutationApplication(
        failure=InvalidOutput(
            message="policy mutation is a no-op", details={"surface": name}
        )
    )


__all__ = [
    "ParentSelection",
    "PolicyArtifact",
    "PolicyMutation",
    "PolicySurface",
    "TrialLimit",
]
