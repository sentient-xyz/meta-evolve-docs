"""Strict held-out comparison for captured policy evaluations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from meta_evolve.errors import RunError, RunsNotComparable

from .evaluation import PolicyEvaluation
from .model import PolicyArtifact


Verdict = Literal["improvement", "tie", "regression", "unrankable"]


@dataclass(frozen=True, slots=True)
class PolicyComparison:
    """Evidence of eligibility; never promotion or deployment authority."""

    baseline: PolicyEvaluation
    candidate: PolicyEvaluation
    verdict: Verdict
    promotion_eligible: bool

    def __post_init__(self) -> None:
        if self.verdict not in {"improvement", "tie", "regression", "unrankable"}:
            raise ValueError("unknown policy comparison verdict")
        if self.promotion_eligible != (self.verdict == "improvement"):
            raise ValueError("promotion eligibility requires a strict improvement")


def compare_policies(baseline_run: object, candidate_run: object) -> PolicyComparison:
    """Compare held-out policy evidence under exactly equal external controls."""

    if isinstance(baseline_run, PolicyEvaluation) and isinstance(
        candidate_run, PolicyEvaluation
    ):
        baseline = baseline_run
        candidate = candidate_run
    else:
        baseline, candidate = _from_runs(baseline_run, candidate_run)
    if baseline.split != "held_out" or candidate.split != "held_out":
        raise RunsNotComparable("held-out policy evaluation split")
    _equal(
        baseline.comparison_controls,
        candidate.comparison_controls,
        "suite, evaluator, aggregation, budgets, and declarations",
    )
    if baseline.direction != candidate.direction:
        raise RunsNotComparable("objective direction")
    if baseline.quality is None or candidate.quality is None:
        verdict: Verdict = "unrankable"
    elif baseline.quality == candidate.quality:
        verdict = "tie"
    else:
        better = (
            candidate.quality > baseline.quality
            if baseline.direction == "maximize"
            else candidate.quality < baseline.quality
        )
        verdict = "improvement" if better else "regression"
    return PolicyComparison(
        baseline=baseline,
        candidate=candidate,
        verdict=verdict,
        promotion_eligible=verdict == "improvement",
    )


def _from_runs(baseline_run: object, candidate_run: object):
    from meta_evolve.application.results import Run

    if not isinstance(baseline_run, Run) or not isinstance(candidate_run, Run):
        raise TypeError("baseline_run and candidate_run must be Run values")
    baseline_start = baseline_run._projection().start
    candidate_start = candidate_run._projection().start
    if baseline_start is None or candidate_start is None:
        raise RunError("policy comparison requires started runs")
    for start in (baseline_start, candidate_start):
        if (
            start.search.policy.name != "greedy"
            or start.search.policy.version != "1"
            or start.search.configuration.get("max_trials") != 0
        ):
            raise RunsNotComparable("seed-only Greedy(max_trials=0) search")
        if (
            start.task.artifact_kind != PolicyArtifact.KIND
            or start.task.artifact_representation != PolicyArtifact.REPRESENTATION
        ):
            raise RunsNotComparable("search-policy seed artifact")
    for name, left, right in (
        ("evaluator", baseline_start.task.evaluator, candidate_start.task.evaluator),
        ("objectives", baseline_start.task.objectives, candidate_start.task.objectives),
        ("task budget", baseline_start.task.budget, candidate_start.task.budget),
        (
            "task environment",
            baseline_start.task.environment,
            candidate_start.task.environment,
        ),
        ("run budget", baseline_start.run_budget, candidate_start.run_budget),
        ("search declaration", baseline_start.search, candidate_start.search),
        ("random seed", baseline_start.random_seed, candidate_start.random_seed),
        (
            "context declaration",
            baseline_run._projection().context_declaration,
            candidate_run._projection().context_declaration,
        ),
        (
            "experience declaration",
            baseline_run._projection().experience_declaration,
            candidate_run._projection().experience_declaration,
        ),
    ):
        _equal(left, right, name)
    baseline_seed = _seed(baseline_run, baseline_start)
    candidate_seed = _seed(candidate_run, candidate_start)
    baseline = _captured(baseline_run)
    candidate = _captured(candidate_run)
    if baseline.artifact != baseline_seed or candidate.artifact != candidate_seed:
        raise RunsNotComparable("captured evaluation must match its policy seed")
    return baseline, candidate


def _seed(run, start) -> PolicyArtifact:
    artifact = run._storage.artifacts.get(start.seed_artifact_id)
    value = run._codecs.decode(artifact)
    if not isinstance(value, PolicyArtifact):
        raise RunsNotComparable("search-policy seed artifact")
    return value


def _captured(run) -> PolicyEvaluation:
    trials = run.trials()
    if len(trials) != 1 or trials[0].logical_step != 0:
        raise RunsNotComparable("one seed evaluation and no successor trials")
    evidence = tuple(
        item for item in trials[0].evidence if item.kind == "policy-evaluation"
    )
    if len(evidence) != 1:
        raise RunsNotComparable("one captured policy-evaluation evidence record")
    try:
        captured = PolicyEvaluation.from_payload(evidence[0].data)
    except (TypeError, ValueError) as error:
        raise RunsNotComparable("valid captured policy evaluation") from error
    if captured.rankable:
        if trials[0].failure is not None:
            raise RunsNotComparable("rankable captured outer evaluation")
        if trials[0].metrics.get("quality") != captured.quality:
            raise RunsNotComparable("captured and outer aggregate quality")
    return captured


def _equal(left: object, right: object, declaration: str) -> None:
    if left != right:
        raise RunsNotComparable(declaration)


__all__ = ["PolicyComparison", "Verdict", "compare_policies"]
