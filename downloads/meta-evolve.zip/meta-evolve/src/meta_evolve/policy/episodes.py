"""Portable policy-evaluation episodes and explicit split declarations."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field, replace

from meta_evolve import serialization
from meta_evolve.domain import Budget, ComponentRef, ContentDigest, FrozenMap, Task
from meta_evolve.domain.values import _require_text


@dataclass(frozen=True, slots=True)
class PolicyEpisode:
    """One independently runnable inner search declaration."""

    name: str
    task: Task
    seed: object = field(compare=False)
    proposer: ComponentRef | Callable[..., object] = field(compare=False)
    budget: Budget
    random_seed: int = 0
    environment: Mapping[str, object] = field(default_factory=FrozenMap)

    def __post_init__(self) -> None:
        _require_text(self.name, "policy episode name")
        if not isinstance(self.task, Task):
            raise TypeError("policy episode task must be a Task")
        if not isinstance(self.budget, Budget):
            raise TypeError("policy episode budget must be a Budget")
        if isinstance(self.random_seed, bool) or not isinstance(self.random_seed, int):
            raise TypeError("policy episode random_seed must be an integer")
        environment = FrozenMap(self.environment)
        if self.task.environment and environment != self.task.environment:
            raise ValueError("policy episode environment conflicts with task")
        if not environment:
            environment = FrozenMap(self.task.environment)
        object.__setattr__(self, "environment", environment)
        proposer = self.proposer
        if not isinstance(proposer, ComponentRef):
            if not callable(proposer) and not callable(
                getattr(proposer, "propose", None)
            ):
                raise TypeError(
                    "policy episode proposer must be callable or a ComponentRef"
                )
            proposer = ComponentRef.local_proposer(proposer)
            object.__setattr__(self, "proposer", proposer)
        if proposer.role != "proposer":
            raise TypeError("policy episode proposer reference must have proposer role")
        # Validate and freeze the seed now against the task's declared codec.
        self.seed_payload

    @property
    def effective_task(self) -> Task:
        """Task identity with evaluator-owned environment folded into it."""

        return replace(self.task, environment=self.environment)

    @property
    def seed_payload(self):
        from meta_evolve.application.codecs import CodecIndex

        return CodecIndex.builtin().encode(
            self.task.artifact_kind,
            self.task.artifact_representation,
            self.seed,
        )

    @property
    def portable(self) -> bool:
        return (
            isinstance(self.task.evaluator, ComponentRef)
            and self.task.evaluator.origin == "registered"
            and isinstance(self.proposer, ComponentRef)
            and self.proposer.origin == "registered"
        )

    def to_payload(self) -> FrozenMap:
        assert isinstance(self.proposer, ComponentRef)
        return FrozenMap(
            {
                "name": self.name,
                "task": serialization.identity_content(self.effective_task),
                "seed": self.seed_payload,
                "proposer": serialization.identity_content(self.proposer),
                "budget": serialization.identity_content(self.budget),
                "random_seed": self.random_seed,
                "environment": self.environment,
                "portable": self.portable,
            }
        )

    @property
    def digest(self) -> str:
        return ContentDigest.for_payload(self.to_payload()).value


@dataclass(frozen=True, slots=True)
class PolicySuite:
    """Non-empty, explicitly separated development and held-out episodes."""

    development: tuple[PolicyEpisode, ...]
    held_out: tuple[PolicyEpisode, ...]

    def __post_init__(self) -> None:
        for name in ("development", "held_out"):
            episodes = getattr(self, name)
            if not isinstance(episodes, tuple) or not episodes:
                raise ValueError(f"policy suite {name} split must be non-empty")
            if not all(isinstance(item, PolicyEpisode) for item in episodes):
                raise TypeError(
                    f"policy suite {name} must contain PolicyEpisode values"
                )
        names = tuple(item.name for item in (*self.development, *self.held_out))
        if len(names) != len(set(names)):
            raise ValueError("policy episode names must be unique across both splits")

    def episodes(self, split: str) -> tuple[PolicyEpisode, ...]:
        if split not in {"development", "held_out"}:
            raise ValueError("policy suite split must be development or held_out")
        return getattr(self, split)

    def to_payload(self) -> FrozenMap:
        return FrozenMap(
            {
                "schema": "policy-suite/v1",
                "development": tuple(item.to_payload() for item in self.development),
                "held_out": tuple(item.to_payload() for item in self.held_out),
            }
        )

    @property
    def digest(self) -> str:
        return ContentDigest.for_payload(self.to_payload()).value


__all__ = ["PolicyEpisode", "PolicySuite"]
