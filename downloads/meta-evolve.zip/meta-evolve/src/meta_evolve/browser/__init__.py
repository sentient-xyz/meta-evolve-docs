"""Optional, local-only presentation over public read-only run queries."""

from .app import create_app
from .server import serve

__all__ = ["create_app", "serve"]
