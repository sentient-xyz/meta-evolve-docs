"""Fixed-scope Uvicorn lifecycle for the local browser command."""

from __future__ import annotations

from pathlib import Path

import meta_evolve as meta
import uvicorn

from .app import create_app
from .reader import BrowserReader


LOOPBACK = "127.0.0.1"


def serve(
    *, storage: Path | str, port: int, registry: meta.Registry | None = None
) -> None:
    """Open storage before binding, then serve one loopback-only worker."""

    reader = (
        BrowserReader(storage)
        if registry is None
        else BrowserReader(storage, registry=registry)
    )
    try:
        reader.start_sync()
    except Exception:
        reader.close_sync()
        raise
    try:
        application = (
            create_app(storage, reader=reader)
            if registry is None
            else create_app(storage, reader=reader, registry=registry)
        )
        uvicorn.run(
            application,
            host=LOOPBACK,
            port=port,
            workers=1,
        )
    finally:
        reader.close_sync()


__all__ = ["LOOPBACK", "serve"]
