"""Single-threaded read-only storage access and exact-version caches."""

from __future__ import annotations

import asyncio
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable, TypeVar

import meta_evolve as meta

from . import presentation
from .models import (
    ArtifactSnapshot,
    CatalogCard,
    CatalogResult,
    InspectionSnapshot,
    MissingArtifact,
    MissingRun,
    UnstableComparison,
    poll_token,
)


class _KnownRun:
    __slots__ = ("run_id", "version", "complete")

    def __init__(self, run_id: object, version: int, complete: bool) -> None:
        self.run_id = run_id
        self.version = version
        self.complete = complete


T = TypeVar("T")


class BrowserReader:
    """Own one read-only handle and all of its work on one dedicated thread."""

    def __init__(
        self,
        path: Path | str,
        *,
        cache_size: int = 32,
        registry: meta.Registry | None = None,
    ) -> None:
        if cache_size < 1:
            raise ValueError("cache_size must be positive")
        self._path = Path(path)
        self._cache_size = cache_size
        self._registry = registry
        self._executor = ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="meta-evolve-browser-storage"
        )
        self._storage: meta.Storage | None = None
        self._known: dict[str, _KnownRun] = {}
        # One entry per run: a newer observed version replaces the older
        # card, so churning incomplete runs cannot grow this without bound.
        self._cards: dict[str, tuple[int, CatalogCard]] = {}
        self._inspections: OrderedDict[
            tuple[str, int], meta.RunInspection
        ] = OrderedDict()
        self._comparisons: OrderedDict[
            tuple[str, int, str, int], meta.RunComparison
        ] = OrderedDict()
        self._closed = False

    def start_sync(self) -> None:
        self._executor.submit(self._open).result()

    async def start(self) -> None:
        await self._call(self._open)

    def _open(self) -> None:
        if self._storage is None:
            self._storage = meta.Storage.read_only(self._path)

    def close_sync(self) -> None:
        if self._closed:
            return
        try:
            self._executor.submit(self._close).result()
        finally:
            self._closed = True
            self._executor.shutdown(wait=True)

    async def close(self) -> None:
        if self._closed:
            return
        try:
            await self._call(self._close)
        finally:
            self._closed = True
            self._executor.shutdown(wait=True)

    def _close(self) -> None:
        if self._storage is not None:
            self._storage.close()
            self._storage = None

    async def _call(self, function: Callable[..., T], *arguments: object) -> T:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            self._executor, lambda: function(*arguments)
        )

    def _require_storage(self) -> meta.Storage:
        if self._storage is None:
            raise RuntimeError("browser storage is not open")
        return self._storage

    async def catalog(self, query: str = "") -> CatalogResult:
        return await self._call(self._catalog, query)

    async def inspection(self, run_id: str) -> InspectionSnapshot:
        return await self._call(self._inspection, run_id)

    async def comparison(self, left: str, right: str) -> meta.RunComparison:
        return await self._call(self._comparison, left, right)

    async def artifact(self, run_id: str, artifact_id: str) -> ArtifactSnapshot:
        return await self._call(self._artifact, run_id, artifact_id)

    async def poll_catalog(self) -> tuple[tuple[str, int], ...]:
        return await self._call(self._poll_catalog)

    async def poll_run(self, run_id: str) -> int:
        return await self._call(self._poll_run, run_id)

    async def run_ids(self) -> tuple[str, ...]:
        return await self._call(lambda: tuple(self._listed()))

    def _listed(self) -> dict[str, object]:
        return {str(item): item for item in self._require_storage().runs()}

    def _resolve(self, *names: str) -> tuple[object, ...]:
        listed = self._listed()
        try:
            return tuple(listed[name] for name in names)
        except KeyError as error:
            raise MissingRun(str(error.args[0])) from None

    def _version(self, run_id: object) -> int:
        return self._require_storage().run_version(run_id)  # type: ignore[arg-type]

    def _remember_lru(self, cache: OrderedDict, key: tuple, value: object) -> None:
        cache[key] = value
        cache.move_to_end(key)
        while len(cache) > self._cache_size:
            cache.popitem(last=False)

    def _remember_inspection(
        self, run_id: object, version: int, inspection: meta.RunInspection
    ) -> None:
        name = str(run_id)
        self._known[name] = _KnownRun(
            run_id, version, inspection.overview.lifecycle == "complete"
        )
        self._remember_lru(self._inspections, (name, version), inspection)

    def _inspect_sandwich(
        self, run_id: object, first_version: int
    ) -> InspectionSnapshot:
        storage = self._require_storage()
        before = first_version
        latest: meta.RunInspection | None = None
        for _attempt in range(2):
            latest = meta.Run(  # type: ignore[arg-type]
                run_id, storage, registry=self._registry
            ).inspect()
            after = self._version(run_id)
            if before == after:
                self._remember_inspection(run_id, after, latest)
                return InspectionSnapshot(latest, after)
            before = after
        assert latest is not None
        self._known[str(run_id)] = _KnownRun(run_id, before, False)
        return InspectionSnapshot(latest, None)

    def _current_version(self, run_id: object) -> int:
        known = self._known.get(str(run_id))
        if known is not None and known.complete:
            return known.version
        version = self._version(run_id)
        if version == 0:
            raise MissingRun(str(run_id))
        return version

    def _inspection(self, name: str) -> InspectionSnapshot:
        (run_id,) = self._resolve(name)
        version = self._current_version(run_id)
        return self._inspection_resolved(run_id, version)

    def _inspection_resolved(
        self, run_id: object, version: int
    ) -> InspectionSnapshot:
        name = str(run_id)
        key = (name, version)
        cached = self._inspections.get(key)
        if cached is not None:
            self._inspections.move_to_end(key)
            return InspectionSnapshot(cached, version)
        known = self._known.get(name)
        if known is not None and known.complete:
            inspection = meta.Run(  # type: ignore[arg-type]
                run_id, self._require_storage(), registry=self._registry
            ).inspect()
            self._remember_inspection(run_id, version, inspection)
            return InspectionSnapshot(inspection, version)
        return self._inspect_sandwich(run_id, version)

    def _card(
        self, run_id: object, snapshot: InspectionSnapshot
    ) -> CatalogCard:
        inspection = snapshot.inspection
        declaration = inspection.declaration
        overview = inspection.overview
        objective = declaration.objectives[0].metric
        best = overview.best_trial
        score = best.metrics[objective] if best is not None else None
        policy = declaration.search.policy
        return CatalogCard(
            run_id=str(run_id),
            version=snapshot.version,
            task_id=str(declaration.task_id),
            lifecycle=overview.lifecycle,
            rankability=overview.rankability,
            policy=f"{policy.name}@{policy.version} ({policy.origin})",
            objective=objective,
            score=score,
            artifact_kind=declaration.artifact_kind,
            usage=presentation.usage(overview.task_usage),
        )

    def _error_card(
        self, run_id: object, version: int, error: Exception
    ) -> CatalogCard:
        if isinstance(error, meta.CapabilityError):
            message = str(error)
            if "no artifact codec registered" in message:
                message = (
                    "Artifact codec unavailable; restart with --module MODULE "
                    "to load its registry."
                )
        elif isinstance(error, meta.DurableCorruption):
            message = "Stored run data failed integrity validation."
        else:
            message = "Storage is temporarily unavailable."
        return CatalogCard(
            run_id=str(run_id), version=version, error=message
        )

    def _catalog(self, query: str) -> CatalogResult:
        cards: list[CatalogCard] = []
        versions: list[tuple[str, int]] = []
        for run_id in self._listed().values():
            name = str(run_id)
            known = self._known.get(name)
            version = known.version if known is not None and known.complete else self._version(run_id)
            if version == 0:
                continue
            versions.append((name, version))
            entry = self._cards.get(name)
            card = (
                entry[1] if entry is not None and entry[0] == version else None
            )
            if card is None:
                try:
                    snapshot = self._inspection_resolved(run_id, version)
                    card = self._card(run_id, snapshot)
                    if snapshot.version is not None:
                        self._cards[name] = (snapshot.version, card)
                except meta.RunNotFound:
                    continue
                except (meta.CapabilityError, meta.DurableStoreError) as error:
                    card = self._error_card(run_id, version, error)
                    self._cards[name] = (version, card)
            haystack = " ".join(
                str(value) for value in (
                    card.run_id, card.task_id, card.lifecycle,
                    card.rankability, card.policy, card.objective,
                    card.artifact_kind,
                )
            ).casefold()
            if query.casefold() in haystack:
                cards.append(card)
        return CatalogResult(tuple(cards), poll_token(versions))

    def _poll_catalog(self) -> tuple[tuple[str, int], ...]:
        versions = []
        for run_id in self._listed().values():
            known = self._known.get(str(run_id))
            version = known.version if known is not None and known.complete else self._version(run_id)
            versions.append((str(run_id), version))
        return tuple(versions)

    def _poll_run(self, name: str) -> int:
        (run_id,) = self._resolve(name)
        return self._current_version(run_id)

    def _artifact(self, run_name: str, artifact_name: str) -> ArtifactSnapshot:
        snapshot = self._inspection(run_name)
        artifacts = snapshot.inspection.artifacts
        artifact = next(
            (item for item in artifacts if str(item.id) == artifact_name), None
        )
        if artifact is None:
            raise MissingArtifact(artifact_name)
        return ArtifactSnapshot(run_name, snapshot.version, artifact, artifacts)

    def _comparison(self, left_name: str, right_name: str) -> meta.RunComparison:
        left_id, right_id = self._resolve(left_name, right_name)
        left_before = self._current_version(left_id)
        right_before = self._current_version(right_id)
        key = (left_name, left_before, right_name, right_before)
        cached = self._comparisons.get(key)
        if cached is not None:
            self._comparisons.move_to_end(key)
            return cached
        storage = self._require_storage()
        for _attempt in range(2):
            result = meta.Run(  # type: ignore[arg-type]
                left_id, storage, registry=self._registry
            ).compare(
                meta.Run(  # type: ignore[arg-type]
                    right_id, storage, registry=self._registry
                )
            )
            left_after = self._version(left_id)
            right_after = self._version(right_id)
            if (left_before, right_before) == (left_after, right_after):
                stable_key = (
                    left_name, left_after, right_name, right_after
                )
                self._remember_lru(self._comparisons, stable_key, result)
                return result
            left_before, right_before = left_after, right_after
        raise UnstableComparison("run streams continued changing")
