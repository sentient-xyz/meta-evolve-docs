"""Sanitize public views into template data without decoded artifact values."""

from __future__ import annotations

from typing import Any

import meta_evolve as meta
from meta_evolve._formatting import render_budget, render_usage


def usage(value: meta.Usage) -> str:
    return render_usage(value, separator=", ", wall=True)


def budget(value: meta.Budget | None) -> str:
    return render_budget(value, separator=", ")


def artifact(value: meta.ArtifactView | None) -> dict[str, object] | None:
    if value is None:
        return None
    return {
        "id": str(value.id),
        "kind": value.kind,
        "representation": value.representation,
        "digest": value.digest,
        "parents": tuple(str(item) for item in value.parent_ids),
    }


def _artifact_preview(value: meta.ArtifactView) -> str:
    presentation = meta.present_artifact(value)
    documents = presentation.documents
    if not documents:
        return "No preview documents"
    size = sum(len(item.text.encode("utf-8")) for item in documents)
    noun = "document" if len(documents) == 1 else "documents"
    truncation = " · bounded preview" if any(item.truncated for item in documents) else ""
    return f"{len(documents)} {noun} · {size} UTF-8 bytes{truncation}"


def _evidence(value: meta.EvidenceView) -> dict[str, object]:
    return {"kind": value.kind, "data": repr(value.data), "uri": value.uri}


def _component(value: object) -> dict[str, object]:
    return {
        "role": getattr(value, "role"),
        "name": getattr(value, "name"),
        "version": getattr(value, "version"),
        "origin": getattr(value, "origin"),
    }


def _trial(value: meta.TrialView) -> dict[str, object]:
    failure = value.failure
    return {
        "id": str(value.id),
        "logical_step": value.logical_step,
        "state": value.state,
        "artifact": artifact(value.artifact),
        "parents": tuple(str(item) for item in value.parent_ids),
        "hypothesis": value.hypothesis,
        "predicted": repr(value.predicted_outcomes),
        "metadata": repr(value.metadata),
        "metrics": repr(value.metrics),
        "uncertainty": repr(value.uncertainty),
        "evidence": tuple(_evidence(item) for item in value.evidence),
        "usage": usage(value.usage),
        "failure": (
            None
            if failure is None
            else {"kind": failure.kind, "message": failure.message}
        ),
        "derivations": tuple(
            {
                "run_id": str(item.run_id),
                "kind": item.kind,
                "occurrence_id": item.occurrence_id,
            }
            for item in value.derived_from
        ),
    }


def _decision(value: meta.DecisionView) -> dict[str, object]:
    common: dict[str, object] = {
        "id": str(value.id),
        "logical_step": value.logical_step,
        "kind": value.kind,
        "rationale": value.rationale,
        "randomness": repr(value.randomness),
    }
    if isinstance(value, meta.TrialDecisionView):
        common.update(
            parents=tuple(str(item) for item in value.parent_ids),
            trial_id=str(value.trial_id),
        )
    elif isinstance(value, meta.ArchiveDecisionView):
        common.update(
            candidate=artifact(value.candidate),
            admitted=value.admitted,
            eviction=artifact(value.eviction),
            members=tuple(str(item) for item in value.member_ids),
        )
    else:
        common["reason"] = value.reason
    return common


def _lineage(values: tuple[meta.ArtifactView, ...]) -> dict[str, object]:
    by_id = {str(item.id): item for item in values}
    depths: dict[str, int] = {}

    def depth(item_id: str) -> int:
        known = depths.get(item_id)
        if known is not None:
            return known
        parents = tuple(str(item) for item in by_id[item_id].parent_ids)
        # Parents outside this run's occurrence set (the same case the edge
        # loop skips) leave a node at the root column rather than crashing.
        result = 1 + max(
            (depth(parent) for parent in parents if parent in by_id),
            default=-1,
        )
        depths[item_id] = result
        return result

    nodes = []
    coordinates: dict[str, tuple[int, int]] = {}
    for index, item in enumerate(values):
        item_id = str(item.id)
        x = 30 + depth(item_id) * 210
        y = 28 + index * 76
        coordinates[item_id] = (x, y)
        nodes.append({"id": item_id, "x": x, "y": y})
    edges = []
    for item in values:
        child = str(item.id)
        child_x, child_y = coordinates[child]
        for parent in map(str, item.parent_ids):
            if parent in coordinates:
                parent_x, parent_y = coordinates[parent]
                edges.append(
                    {
                        "x1": parent_x + 160,
                        "y1": parent_y + 18,
                        "x2": child_x,
                        "y2": child_y + 18,
                    }
                )
    return {
        "nodes": tuple(nodes),
        "edges": tuple(edges),
        "width": max((node["x"] for node in nodes), default=0) + 190,
        "height": max(120, len(nodes) * 76 + 24),
    }


def inspection_page(
    snapshot: object, choices: tuple[str, ...]
) -> dict[str, Any]:
    inspection = snapshot.inspection
    overview = inspection.overview
    declaration = inspection.declaration
    best = overview.best_trial
    objectives = tuple(
        {
            "direction": type(item).__name__.lower(),
            "metric": item.metric,
            "satisfy": item.satisfy,
        }
        for item in declaration.objectives
    )
    policy = declaration.search.policy
    return {
        "run_id": str(overview.run_id),
        "version": snapshot.version,
        "choices": tuple(item for item in choices if item != str(overview.run_id)),
        "overview": {
            "lifecycle": overview.lifecycle,
            "rankability": overview.rankability,
            "best_trial": None if best is None else str(best.id),
            "stop_reason": overview.stop_reason,
            "usage": usage(overview.task_usage),
            "experience_usage": repr(overview.experience_usage),
        },
        "declaration": {
            "task_id": str(declaration.task_id),
            "objectives": objectives,
            "artifact_kind": declaration.artifact_kind,
            "artifact_representation": declaration.artifact_representation,
            "seed": artifact(declaration.seed),
            "evaluator": _component(declaration.evaluator),
            "proposer": _component(declaration.proposer),
            "policy": f"{policy.name}@{policy.version} ({policy.origin})",
            "search_configuration": repr(declaration.search.configuration),
            "task_budget": budget(declaration.task_budget),
            "effective_budget": budget(declaration.effective_budget),
            "capabilities": repr(declaration.capabilities),
            "context": repr(declaration.context),
            "experience": repr(declaration.experience),
            "random_seed": declaration.random_seed,
        },
        "trials": tuple(_trial(item) for item in inspection.trials),
        "decisions": tuple(_decision(item) for item in inspection.decisions),
        "evidence": tuple(_evidence(item) for item in inspection.evidence),
        "artifacts": tuple(
            {**artifact(item), "preview": _artifact_preview(item)}
            for item in inspection.artifacts
        ),
        "lineage": _lineage(inspection.artifacts),
    }


def comparison_page(value: meta.RunComparison) -> dict[str, object]:
    def side(summary: meta.RunSummary) -> dict[str, object]:
        return {
            "run_id": str(summary.run_id),
            "score": summary.primary_score,
            "usage": usage(summary.usage),
        }

    winner = "tie"
    if value.winner is value.left:
        winner = "left"
    elif value.winner is value.right:
        winner = "right"
    return {
        "left": side(value.left),
        "right": side(value.right),
        "winner": winner,
        "same_random_seed": value.same_random_seed,
        "same_context": value.same_context_declaration,
        "same_experience": value.same_experience_declaration,
    }


__all__ = [
    "budget",
    "comparison_page",
    "inspection_page",
    "usage",
]
