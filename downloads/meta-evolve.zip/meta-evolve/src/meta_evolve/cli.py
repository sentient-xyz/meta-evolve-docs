"""The ``meta-evolve`` command line: five reports and one UI lifecycle.

Each verb parses its arguments, makes ONE public call, and returns a report::

    run      meta.run over an experiment module
    list     Storage.runs()
    inspect  Run.inspect()
    resume   meta.resume
    compare  Run.compare

``ui`` and ``worker`` are the explicit long-running exceptions: ``worker``
joins a dispatcher that is listening and serves its work until the run ends,
making no run of its own (``distributed/command_line.py`` owns its parsing).
``ui`` conditionally imports and
delegates to the optional browser server, owns no domain logic or HTML, fixes
the server to loopback and one worker, and leaves operational logs to Uvicorn.
Its optional module contributes only the factory declaration's registry for
custom artifact reconstruction; browser dependencies import before module code.
The five report verbs retain the one-call and sole-writer conventions below.

``workers`` -- ``add``, ``list``, ``revoke`` -- is the operator's allow-list,
and the one verb about a STORE rather than a run in it. Its nested commands,
their reports, and the only two calls in the package that write a
trusted-worker row are ``worker_administration.py``'s.

An experiment module exposes exactly one factory::

    def experiment() -> meta.Experiment: ...

returning a typed declaration. Compatibility dictionaries remain accepted with
a ``DeprecationWarning`` under the documented pre-1.0 release policy. The command line imports the module,
calls the factory, and overlays only the infrastructure it owns: ``--storage``
and ``--mode``. It contains no capability logic of its own — durable-local's
component requirements, whether a run is resumable, and whether a store can
enumerate its runs are all the library's rules, surfaced here as the library's
own typed failures.

Two conventions keep output honest and in one place: ``main`` is the only
function that writes to a stream, while ``_render_summary`` and
``_render_inspection`` format their public view models; ``_summary_report``
also reads rankability to choose the exit status. The renderers omit measured
wall-clock values so deterministic runs retain identical text.
These conventions are enforced by ``tests/test_cli.py``.

On length: well past the ~300 guideline, and deliberately not split, which its
siblings under ``application/`` say of themselves in the same words. What is
here is ONE auditable command-line boundary -- the five report parsers, their
one-call translators, and both public-view renderers -- and the conventions
above are what make it one: a single writer to the streams, renderers over view
models, and no capability logic of its own. Split by verb, each file would carry
its own copy of those conventions and the AST tests in ``tests/test_cli.py``
would have several boundaries to check rather than one, which is the failure
those tests exist to prevent. The parts that ARE separate responsibilities have
already left: the worker flags and the ``worker`` verb are
``distributed/command_line.py``'s, the ``workers`` verb and its two writes are
``worker_administration.py``'s, and value formatting is ``_formatting.py``'s.
"""

from __future__ import annotations

import argparse
import sys
from collections.abc import Callable
from dataclasses import dataclass
from typing import get_args

import meta_evolve as meta
from meta_evolve._formatting import render_budget, render_usage
from meta_evolve.application.results import drift_since_start
from meta_evolve.application.runtime import ExecutionMode
from meta_evolve.domain import RunId
from meta_evolve.errors import RunError
from meta_evolve.ports.worker_registry import InvalidTrustedWorker
from meta_evolve.distributed.command_line import (
    add_worker_flags,
    add_worker_verb,
    drive_with,
    execution_for,
    preflight,
    run_worker_verb,
)
from meta_evolve.experiment_modules import (
    MODULE_HELP as _MODULE_HELP,
    ExperimentModuleError,
    experiment_declaration as _experiment_declaration,
)
from meta_evolve.worker_administration import (
    add_worker_administration_verb,
    administer_workers,
)

_LABEL = 16


class BrowserUnavailable(Exception):
    """The optional browser dependency group is not installed."""


@dataclass(frozen=True, slots=True)
class _CommandReport:
    text: str
    exit_code: int = 0


def _summary_report(summary: meta.RunSummary) -> _CommandReport:
    return _CommandReport(_render_summary(summary), int(summary.rankability == "unrankable"))


def _row(label: str, value: object) -> str:
    separator = " " if len(label) >= _LABEL else ""
    return f"{label:<{_LABEL}}{separator}{value}\n"


def _render_summary(summary: meta.RunSummary) -> str:
    """Format one run summary. The single place output formatting lives.

    Every ``RunSummary`` field is reported except ``usage.wall_seconds``: it
    is a wall-clock measurement, so printing it would make two byte-identical
    runs produce different reports.
    """

    usage = summary.usage
    return "".join(
        (
            _row("run", summary.run_id),
            _row("lifecycle", summary.lifecycle),
            _row("rankability", summary.rankability),
            _row("stop", summary.stop_reason or "none"),
            _row(
                "policy",
                f"{summary.policy.name}@{summary.policy.version} "
                f"({summary.policy.origin})",
            ),
            _row("score", "none" if summary.primary_score is None else summary.primary_score),
            _row("evaluations", summary.evaluation_count),
            _row("usage", render_usage(usage)),
            _row("random seed", summary.random_seed),
            _row(
                "initial",
                f"{summary.initial_artifact!r} "
                f"({summary.initial_artifact_digest.value})",
            ),
            _row(
                "lineage",
                " -> ".join(repr(value) for value in summary.winning_lineage) or "none",
            ),
            _row("context", summary.context_spec),
            _row("experience", summary.experience_spec),
            _row("experience use", summary.experience_usage),
            # The roles identified by name alone, so a reader of two reports
            # can see whether their declared equality means anything.
            _row("name only", ", ".join(summary.name_only_components) or "none"),
        )
    )


def _render_inspection(inspection: meta.RunInspection) -> str:
    """Format all four parts of one aggregate inspection deterministically."""

    overview = inspection.overview
    declaration = inspection.declaration

    def component(value: object) -> str:
        return (
            f"{value.role}:{value.name}@{value.version} ({value.origin})"
        )

    best = overview.best_trial
    best_text = "none"
    if best is not None and best.artifact is not None:
        best_text = f"{best.artifact.value!r} ({best.id})"

    lines = [
        "overview\n",
        _row("run", overview.run_id),
        _row("lifecycle", overview.lifecycle),
        _row("rankability", overview.rankability),
        _row("best", best_text),
        _row("stop", overview.stop_reason or "none"),
        _row("task usage", render_usage(overview.task_usage)),
        _row("experience use", overview.experience_usage),
        "\ndeclaration\n",
        _row("task", declaration.task_id),
        _row("objectives", declaration.objectives),
        _row(
            "artifact",
            f"{declaration.artifact_kind}/{declaration.artifact_representation}",
        ),
        _row(
            "seed",
            f"{declaration.seed.value!r} ({declaration.seed.id}, "
            f"digest={declaration.seed.digest})",
        ),
        _row("evaluator", component(declaration.evaluator)),
        _row("proposer", component(declaration.proposer)),
        _row("search", declaration.search),
        _row("task budget", render_budget(declaration.task_budget)),
        _row("effective budget", render_budget(declaration.effective_budget)),
        _row("capabilities", declaration.capabilities),
        _row("context", declaration.context),
        _row("experience", declaration.experience),
        _row("random seed", declaration.random_seed),
        "\ntrials\n",
    ]
    for trial in inspection.trials:
        lines.append(_row(f"trial {trial.logical_step}", f"{trial.state} ({trial.id})"))
        lines.append(_row("  parents", ", ".join(map(str, trial.parent_ids)) or "none"))
        if trial.artifact is not None:
            lines.append(
                _row(
                    "  artifact",
                    f"{trial.artifact.value!r} ({trial.artifact.id}, "
                    f"digest={trial.artifact.digest})",
                )
            )
        lines.append(_row("  metrics", trial.metrics))
        lines.append(_row("  evidence", ", ".join(item.kind for item in trial.evidence) or "none"))
        lines.append(_row("  usage", render_usage(trial.usage)))
        if trial.failure is not None:
            lines.append(
                _row("  failure", f"{trial.failure.kind}: {trial.failure.message}")
            )
    lines.extend((
        _row("artifacts", len(inspection.artifacts)),
        _row("evidence", len(inspection.evidence)),
        "\ndecisions\n",
    ))
    for decision in inspection.decisions:
        randomness = ", ".join(
            f"{name}={seed}" for name, seed in decision.randomness.items()
        ) or "none"
        if isinstance(decision, meta.TrialDecisionView):
            detail = "trial"
        elif isinstance(decision, meta.ArchiveDecisionView):
            detail = "archive"
        else:
            detail = "stop"
        lines.append(
            _row(f"decision {decision.logical_step}", f"{detail} ({decision.id})")
        )
        lines.append(_row("  rationale", decision.rationale))
        lines.append(_row("  randomness", randomness))
        if isinstance(decision, meta.TrialDecisionView):
            lines.append(
                _row("  parents", ", ".join(map(str, decision.parent_ids)) or "none")
            )
            lines.append(_row("  trial", decision.trial_id))
        elif isinstance(decision, meta.ArchiveDecisionView):
            lines.append(_row("  candidate", decision.candidate.id))
            lines.append(_row("  admitted", decision.admitted))
            lines.append(
                _row(
                    "  eviction",
                    decision.eviction.id if decision.eviction is not None else "none",
                )
            )
            lines.append(
                _row("  members", ", ".join(map(str, decision.member_ids)) or "none")
            )
        else:
            lines.append(_row("  reason", decision.reason))
    return "".join(lines)


def _run(arguments: argparse.Namespace) -> _CommandReport:
    declaration = _experiment_declaration(arguments.module)
    execution = execution_for(arguments, _parser())
    if execution is None:
        with meta.Storage.durable(arguments.storage) as storage:
            result = meta.run(declaration, storage=storage, mode=arguments.mode)
            return _summary_report(result.summary())
    # Worker processes need the session itself: `meta.run` drives with no
    # execution and would run every component here.
    preflight(declaration)
    with meta.Storage.durable(arguments.storage) as storage:
        session = meta.Session.start(declaration, storage=storage, mode=arguments.mode)
        drive_with(session, execution, arguments)
        return _summary_report(session.run.summary())


def _list(arguments: argparse.Namespace) -> _CommandReport:
    with meta.Storage.durable(arguments.storage) as storage:
        return _CommandReport("".join(f"{run_id}\n" for run_id in storage.runs()))


def _inspect(arguments: argparse.Namespace) -> _CommandReport:
    with meta.Storage.durable(arguments.storage) as storage:
        result = meta.Run(RunId(arguments.run), storage)
        return _CommandReport(_render_inspection(result.inspect()))


def _resume(arguments: argparse.Namespace) -> _CommandReport:
    declaration = _experiment_declaration(arguments.module)
    execution = execution_for(arguments, _parser())
    if execution is not None:
        preflight(declaration)
        with meta.Storage.durable(arguments.storage) as storage:
            session = meta.Session.resume(
                RunId(arguments.run), storage=storage, registry=declaration.registry
            )
            drive_with(session, execution, arguments)
            return _resume_report(session.run)
    with meta.Storage.durable(arguments.storage) as storage:
        result = meta.resume(
            RunId(arguments.run),
            storage=storage,
            # A factory that registers nothing hands ``resume`` no registry
            # and the library refuses the resume; the command line does not
            # pre-empt that check.
            registry=declaration.registry,
        )
        return _resume_report(result)


def _resume_report(result: meta.Run) -> _CommandReport:
    """The summary, led by one row when the environment changed since start.

    Only when it changed, so every other resume prints what it always has. A
    resume that raises reports only its error: ``main`` is the one writer, and
    a failing verb reaches it as the exception alone.
    """

    summary = result.summary()
    report = _summary_report(summary)
    drift = drift_since_start(summary)
    if drift is None:
        return report
    return _CommandReport(f"{drift}\n{report.text}", report.exit_code)


def _compare(arguments: argparse.Namespace) -> _CommandReport:
    with meta.Storage.durable(arguments.storage) as storage:
        left = meta.Run(RunId(arguments.left), storage)
        comparison = left.compare(meta.Run(RunId(arguments.right), storage))
        winner = (
            "tie"
            if comparison.winner is None
            else ("left" if comparison.winner is comparison.left else "right")
        )
        return _CommandReport(
            "left\n"
            + _render_summary(comparison.left)
            + "\nright\n"
            + _render_summary(comparison.right)
            + "\n"
            + _row("winner", winner)
            + _row("same seed", comparison.same_random_seed)
            + _row("same context", comparison.same_context_declaration)
            + _row("same experience", comparison.same_experience_declaration)
        )


def _ui(arguments: argparse.Namespace) -> _CommandReport:
    try:
        from meta_evolve.browser import serve

    except ModuleNotFoundError as error:
        if error.name is None or error.name.split(".", 1)[0] not in {
            "jinja2", "starlette", "uvicorn"
        }:
            raise
        raise BrowserUnavailable(
            "browser dependencies are not installed; run "
            "`uv sync --extra browser` (or install `meta-evolve[browser]`)"
        ) from error
    # Browser dependencies are proven available before optional author module
    # code is loaded. Only its registry crosses into the read-only reader.
    if arguments.module is None:
        serve(storage=arguments.storage, port=arguments.port)
    else:
        declaration = _experiment_declaration(arguments.module)
        serve(
            storage=arguments.storage,
            port=arguments.port,
            registry=declaration.registry,
        )
    return _CommandReport("")


def _worker(arguments: argparse.Namespace) -> _CommandReport:
    """The long-running exception: it serves until the run ends."""

    return _CommandReport("", run_worker_verb(arguments))


def _workers(arguments: argparse.Namespace) -> _CommandReport:
    """The operator's allow-list: one call, like the report verbs, into the
    one module that writes a trusted-worker row."""

    return _CommandReport(administer_workers(arguments))


def _port(value: str) -> int:
    try:
        port = int(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("port must be an integer") from error
    if not 1 <= port <= 65535:
        raise argparse.ArgumentTypeError("port must be between 1 and 65535")
    return port


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="meta-evolve",
        description=(
            "Run, list, inspect, resume, compare, and locally browse "
            "Meta-Evolve runs."
        ),
    )
    verbs = parser.add_subparsers(dest="verb", required=True, metavar="verb")

    Verb = Callable[[argparse.Namespace], _CommandReport]

    def verb(name: str, help_text: str, execute: Verb) -> argparse.ArgumentParser:
        subparser = verbs.add_parser(name, help=help_text, description=help_text)
        subparser.add_argument(
            "--storage", required=True, metavar="PATH", help="durable storage directory"
        )
        subparser.set_defaults(execute=execute)
        return subparser

    run_verb = verb("run", "run an experiment module", _run)
    run_verb.add_argument("module", help=_MODULE_HELP)
    run_verb.add_argument(
        "--mode",
        # Taken from the library's own mode vocabulary rather than restated,
        # so the command line never becomes a second source of truth for it.
        choices=get_args(ExecutionMode),
        default="local",
        help="execution mode (default: local)",
    )

    verb("list", "list the runs a storage directory holds", _list)

    inspect_verb = verb("inspect", "report one run's summary and best artifact", _inspect)
    inspect_verb.add_argument("run", metavar="RUN_ID", help="run to report on")

    resume_verb = verb("resume", "resume an interrupted durable-local or distributed run", _resume)
    resume_verb.add_argument("run", metavar="RUN_ID", help="run to resume")
    resume_verb.add_argument("--module", required=True, help=_MODULE_HELP)
    add_worker_flags(run_verb)
    add_worker_flags(resume_verb)

    compare_verb = verb("compare", "compare two runs in one storage", _compare)
    compare_verb.add_argument("left", metavar="LEFT", help="run reported first")
    compare_verb.add_argument("right", metavar="RIGHT", help="run reported second")

    ui_verb = verb("ui", "browse durable runs locally and read-only", _ui)
    ui_verb.add_argument(
        "--port",
        type=_port,
        default=8000,
        metavar="PORT",
        help="loopback port from 1 to 65535 (default: 8000)",
    )
    ui_verb.add_argument(
        "--module",
        help=(
            "optional experiment module whose registry reconstructs custom "
            "artifact codecs"
        ),
    )

    # Last, after the five report verbs and `ui`: `worker` makes no run of its
    # own, and `workers` is about the store rather than about any run in it.
    # The surface reads in that order.
    add_worker_verb(verbs, _worker)
    add_worker_administration_verb(verbs, _workers)

    return parser


def main(argv: list[str] | None = None) -> int:
    """Parse, execute one verb, print its report. The only stream writer.

    Exit codes: 0 success, 1 unrankable run or domain failure — a registry
    command the store refuses is one — 2 usage error. Anything that is
    neither — a defect in an experiment module's own code, say — is left to
    propagate with its traceback rather than being flattened into a message.
    """

    arguments = _parser().parse_args(argv)
    try:
        report = arguments.execute(arguments)
    except ExperimentModuleError as error:
        sys.stderr.write(f"error: {error}\n")
        return 2
    except BrowserUnavailable as error:
        sys.stderr.write(f"error: {error}\n")
        return 2
    # `InvalidTrustedWorker` is a `ValueError` to mirror `InvalidWorkAppend`,
    # not because an operator's refused command is less a domain failure.
    except (RunError, InvalidTrustedWorker) as error:
        sys.stderr.write(f"error: {type(error).__name__}: {error}\n")
        return 1
    sys.stdout.write(report.text)
    return report.exit_code


__all__ = ["BrowserUnavailable", "ExperimentModuleError", "main"]


if __name__ == "__main__":  # pragma: no cover - exercised by subprocess tests
    raise SystemExit(main())
