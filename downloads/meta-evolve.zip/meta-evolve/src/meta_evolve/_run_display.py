"""Bounded text and escaped notebook reports from captured scalar facts."""

from __future__ import annotations

from html import escape
from typing import TYPE_CHECKING
from unicodedata import category

from meta_evolve._formatting import dollars
from meta_evolve.domain import Maximize

from .presentation.models import PresentationField

if TYPE_CHECKING:
    from meta_evolve.application.run_summary import RunSummary

TEXT_LIMIT = 200
_STOP_REASONS = {
    "trial_limit_reached": "Proposal limit reached",
    "budget_exhausted": "Budget exhausted",
    "accounting_unavailable": "Required cost accounting unavailable",
    "objective_satisfied": "Objective target reached",
    "population_empty": "No population candidates remain",
    "specialist_frontier_empty": "No specialist candidates remain",
}


def bounded_text(value: str, *, limit: int = TEXT_LIMIT) -> str:
    """Bound work as well as output, and make terminal controls visible."""
    safe = "".join(
        char.encode("unicode_escape").decode("ascii")
        if category(char) in {"Cc", "Cf", "Cs"} else char
        for char in value[:limit]
    )
    if len(value) > limit or len(safe) > limit:
        return safe[:limit - 1] + "…"
    return safe


def _number(value: int | float | None) -> str:
    if value is None:
        return "Unavailable"
    if isinstance(value, int):
        # Avoid Python's integer-string digit ceiling and unbounded conversion.
        if int.bit_length(value) > 640:
            return "[integer exceeds display limit]"
        return int.__repr__(value)
    return float.__repr__(value)


def _spend(value: int | None) -> str:
    if value is None:
        return "Unknown"
    if int.bit_length(value) > 640:
        return "Known; exceeds display limit"
    return dollars(value)


def _improvement(summary: RunSummary) -> str:
    baseline, selected = summary.baseline_score, summary.primary_score
    if baseline is None or selected is None or summary.primary_objective is None:
        return "Unavailable"
    better = (
        selected > baseline if isinstance(summary.primary_objective, Maximize)
        else selected < baseline
    )
    return "Improved over baseline" if better else "No measured improvement"


def _history(summary: RunSummary) -> str:
    if summary.storage_is_durable is None:
        return "Unknown"
    if not summary.storage_is_durable:
        return "Not saved durably"
    if summary.storage_location is None:
        return "Saved; location unspecified"
    return "Saved at " + bounded_text(summary.storage_location)


def _resume(summary: RunSummary) -> str:
    capabilities = summary.capabilities
    if capabilities is None:
        return "Unknown"
    if not capabilities.resumable:
        return f"No ({capabilities.mode} execution)"
    text = f"Declared ({capabilities.mode}); compatibility not checked"
    if summary.lifecycle == "complete":
        text += "; complete, no continuation pending"
    return text


def summary_fields(summary: RunSummary) -> tuple[PresentationField, ...]:
    """Read captured scalar facts only; do not visit artifacts or evidence."""
    objective = summary.primary_objective
    label = "Score"
    if objective is not None:
        direction = "maximize" if isinstance(objective, Maximize) else "minimize"
        label = f"{bounded_text(objective.metric, limit=180)} ({direction})"
    rows = [
        ("Run", summary.run_id.value),
        ("Status", "Complete" if summary.lifecycle == "complete" else "Incomplete"),
        ("Measurement", "Available" if summary.rankability == "rankable"
         else "No successful measurement"),
        (label, f"baseline {_number(summary.baseline_score)} → "
         f"selected {_number(summary.primary_score)}"),
        ("Improvement", _improvement(summary)),
        ("Proposals", _number(summary.usage.trials)),
        ("Evaluations", _number(summary.evaluation_count) + " (includes baseline when evaluated)"),
        ("Failed attempts", "Unknown" if summary.failure_count is None
         else _number(summary.failure_count)),
        ("Stop", "Not stopped" if summary.stop_reason is None
         else _STOP_REASONS.get(summary.stop_reason, summary.stop_reason)),
        ("Task tokens", _number(summary.usage.tokens)),
        ("Task spend", _spend(summary.usage.spend_micros)),
        ("History at capture", _history(summary)),
        ("Recorded resume support", _resume(summary)),
    ]
    context, pull = summary.experience_usage.context, summary.experience_usage.pull
    if context.records or context.chars:
        rows.append(("Context usage", f"{_number(context.records)} records; "
                     f"{_number(context.chars)} characters"))
    if pull.operations or pull.results or pull.records or pull.chars:
        rows.append(("Pull usage", f"{_number(pull.operations)} operations; "
                     f"{_number(pull.results)} results; {_number(pull.records)} records; "
                     f"{_number(pull.chars)} characters"))
    return tuple(
        PresentationField(bounded_text(label), bounded_text(value))
        for label, value in rows
    )


def run_repr(run_id: str) -> str:
    return f"Run(id={bounded_text(run_id)!r}; call summary() while storage is open)"


def summary_repr(summary: RunSummary) -> str:
    rows = summary_fields(summary)
    return (
        f"RunSummary(id={rows[0].text!r}, status={rows[1].text!r}, "
        f"measurement={rows[2].text!r}, score={rows[3].text!r})"
    )


def summary_text(summary: RunSummary) -> str:
    return "\n".join(f"{row.label}: {row.text}" for row in summary_fields(summary))


def summary_html(summary: RunSummary) -> str:
    rows = summary_fields(summary)
    fields = "".join(
        '<div style="min-width:0;overflow-wrap:anywhere">'
        '<dt style="font-size:.85em;opacity:.75">'
        f'{escape(row.label)}</dt><dd style="margin:0">{escape(row.text)}</dd></div>'
        for row in rows[1:]
    )
    return (
        '<section aria-label="Run snapshot" style="box-sizing:border-box;'
        'max-width:46rem;padding:1rem;border:1px solid #8888;border-radius:.6rem;'
        'color:inherit;font:inherit;line-height:1.5">'
        '<h3 style="margin:0 0 .3rem;font-size:1.1em">Run snapshot</h3>'
        '<p style="margin:0 0 1rem;font-family:monospace;overflow-wrap:anywhere">'
        f'{escape(rows[0].text)}</p>'
        '<dl style="margin:0;display:grid;gap:.8rem 1.5rem;'
        'grid-template-columns:repeat(auto-fit,minmax(min(100%,16rem),1fr))">'
        f'{fields}</dl></section>'
    )
