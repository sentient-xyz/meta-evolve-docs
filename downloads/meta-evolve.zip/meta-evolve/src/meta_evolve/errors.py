"""Typed failures raised by local run orchestration and queries."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover - typing only
    from meta_evolve.domain import RunId


class RunError(RuntimeError):
    """Base class for application-level run failures."""


class BudgetUnavailable(RunError):
    """The requested action cannot fit within its effective budget."""


class InvalidDecision(RunError):
    """A search decision is stale, malformed, or exceeds its authority.

    A VERDICT, and the work table now reads it as one: a row whose recorded
    cause names this type is ended on resume without re-running its component,
    because nothing about a second attempt can make a malformed decision valid.
    Whatever raises this is asserting exactly that.
    """


class InputsUnavailable(RunError):
    """A trial's committed inputs could not be read, and the read may succeed.

    A sibling of `InvalidDecision`, not a subclass, and the distinction is
    load-bearing rather than taxonomic. `load_parents` raises this for every
    non-escaping fault an artifact store answers with -- a `KeyError`, a
    timeout -- and the retry bound exists for precisely those. Under the older
    name the same fault read as a verdict on the decision's validity, which the
    deterministic-abort rule would have ended after one attempt.

    Not a subclass, because a subclass would keep the conflation this type
    exists to remove. Every caller that catches `InvalidDecision` would go on
    reading an unreadable input as a validity verdict; and the work table would
    leave such a row retryable only because its recorded NAME happens to differ
    -- protection resting on a spelling rather than on what the type is.
    """


class DispatcherSuperseded(RunError):
    """Another dispatcher now drives this run; this one must stop.

    Every resume rolls the run's epoch over, so a second process driving the
    same run makes the first one's epoch stale without telling it -- and since
    a rollover writes no event, the stream's own concurrency check cannot see
    it. Raised when a write made under the old epoch meets the new one.
    Exclusion, not failover: nothing here decides which dispatcher should win.

    Importable from here and deliberately NOT a root export: M11.3 adds no
    root exports, and it is raised from inside a distributed drive rather
    than from an API a caller invokes to get it.
    """

    def __init__(self, run_id: "RunId", *, held: int, current: int) -> None:
        self.run_id = run_id
        self.held = held
        self.current = current
        super().__init__(
            f"run {run_id} is being driven by another dispatcher: this one "
            f"holds epoch {held}, and the run is at epoch {current}"
        )


class WorkerNotTrusted(RunError):
    """This worker is not one the store's operator authorises to claim work.

    Three states share it, because they are one fact from the broker's side: a
    worker an operator never enrolled, one whose row is revoked, and one
    presenting a generation the registry no longer honours. Dispatcher-minted
    ids are never refused this way -- they are the dispatcher's own, and to
    stop them you stop the dispatcher.

    RAISED rather than answered with `None`, which is the whole reason it is a
    type: the drive reads `None` from `acquire` as "nothing ready just now"
    and comes round again, so a refusal spelled that way would spin against a
    worker it can never serve. Importable from here and deliberately NOT a
    root export, like `DispatcherSuperseded`; and NOT in `ESCAPING_EXCEPTIONS`,
    because it is a fact about one endpoint rather than about the run, and the
    loop fails that endpoint's claim instead of aborting the drive.
    """

    def __init__(self, worker_id: str, *, reason: str) -> None:
        self.worker_id = worker_id
        self.reason = reason
        super().__init__(f"worker {worker_id!r} may not claim work: {reason}")


class NoSuccessfulEvaluation(RunError):
    """A winner-dependent query has no successful measurement to rank.

    Use ``Run.trials()``, ``Run.inspect()``, or ``Run.usage()`` to diagnose and
    account for unsuccessful work. A missing measurement is never a zero score.
    """


class RunNotFound(RunError):
    """The requested run has no event stream, or a saved store contains no runs."""


class RunSelectionRequired(RunError):
    """A saved store contains several runs and needs an explicit selection.

    :param run_ids: Available run identities, exposed as a lexical-order tuple.
        Pass one as ``run_id=...`` to [open_run][meta_evolve.open_run].
    """

    run_ids: tuple[RunId, ...]

    def __init__(self, run_ids: tuple[RunId, ...]) -> None:
        self.run_ids = tuple(sorted(run_ids, key=lambda run_id: run_id.value))
        available = ", ".join(run_id.value for run_id in self.run_ids)
        super().__init__(
            f"multiple recorded runs; pass run_id=... to choose one; available IDs: {available}"
        )


class RunsNotComparable(RunError):
    """Two runs disagree on a declaration their comparison is defined over.

    ``compare_runs`` ranks two runs only when they answer the same question:
    the same task, objective, budgets, initial artifact, and authorized
    components. ``declaration`` names the one that differed, so a caller can
    branch on it without parsing the message.
    """

    def __init__(self, declaration: str) -> None:
        super().__init__(f"runs declare different {declaration}s")
        self.declaration = declaration


class UnboundSearchProgram(RunError):
    """A public search preset was used without run-level binding."""


class CapabilityError(RunError):
    """A run's declared or requested execution profile is not honored.

    Raised for unverifiable component implementations (lambdas, closures,
    ``functools.partial``, decorated wrappers, or callables with no
    resolvable module source), unregistered ``(role, name, version)``
    lookups, and durable-local configuration that lacks a registry, durable
    storage, or a registered evaluator/proposer/policy. Also raised when
    storage is asked for an optional capability its components do not
    declare, such as enumerating runs through a non-``RunIndex`` event store.
    Also raised when a search declares a generational cohort width above one,
    which needs the dispatcher that commits a cohort as one batch and is
    therefore refused on the synchronous path, at start and again at resume.
    """


class ContextDisabled(CapabilityError):
    """Evidence lookup requires explicitly enabled pushed context.

    Check ``context.evidence.enabled`` when feedback is optional. An unhandled
    lookup aborts at the call site, possibly after seed evaluation, rather than
    recording a proposal failure or repeatedly consuming the attempt budget.
    """


class DurableStoreError(RunError):
    """Base class for durable-format and durable-store failures."""


class SchemaVersionRejected(DurableStoreError):
    """A durable schema version is unknown, future, or unmigratable."""


class DurableCorruption(DurableStoreError):
    """Durable data is internally inconsistent or references missing content."""


class ExperienceStoreUnavailable(DurableStoreError):
    """A durable audit-event commit for an experience reader operation failed.

    Raised at the experience reader's audit-append boundary when the underlying
    store commit fails with a raw infrastructure fault (``OSError`` /
    ``sqlite3.Error``). It is INFRASTRUCTURE, not a logical proposer failure:
    it is the one typed signal a proposer-driven reader emits so the proposer
    adapter can let a genuine audit-store commit fault ESCAPE while a user
    proposer's own ``OSError`` still becomes a recoverable ``ProposerFailure``.
    """


class ExecutionAccountingUnknown(RunError):
    """Provider work may have started without exact required accounting.

    Part of the user-owned wrapper contract rather than an internal detail,
    imported as ``from meta_evolve.errors import ExecutionAccountingUnknown``.
    Raise when required nonnullable accounting, such as token usage after a
    dispatched request, cannot be recovered. Unknown billed spend alone can
    be retained as ``Usage(spend_micros=None)`` alongside a result or failure.
    An ordinary exception instead becomes a typed failure with default usage.

    It aborts a local structural run. It is not a durable failure outcome and
    makes no retry or resume claim.
    """


_EXPERIENCE_DENIED = "experience access denied"
_EXPERIENCE_EXHAUSTED = "experience budget exhausted"


class ExperienceAccessDenied(LookupError):
    """An opaque denial that discloses no protected content or topology."""

    def __init__(self) -> None:
        super().__init__(_EXPERIENCE_DENIED)


class ExperienceBudgetExhausted(RuntimeError):
    """A content-free signal that a grant's operation ceiling was exceeded."""

    def __init__(self) -> None:
        super().__init__(_EXPERIENCE_EXHAUSTED)


__all__ = [
    "BudgetUnavailable",
    "CapabilityError",
    "ContextDisabled",
    "DispatcherSuperseded",
    "DurableCorruption",
    "DurableStoreError",
    "ExecutionAccountingUnknown",
    "ExperienceAccessDenied",
    "ExperienceBudgetExhausted",
    "ExperienceStoreUnavailable",
    "InputsUnavailable",
    "InvalidDecision",
    "NoSuccessfulEvaluation",
    "RunError",
    "RunNotFound",
    "RunSelectionRequired",
    "RunsNotComparable",
    "SchemaVersionRejected",
    "UnboundSearchProgram",
    "WorkerNotTrusted",
]
