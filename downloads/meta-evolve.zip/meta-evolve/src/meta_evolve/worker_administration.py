"""Enrol, inspect, and revoke the workers a store trusts."""

from __future__ import annotations

import argparse
import json

import meta_evolve as meta
from meta_evolve.domain.values import FrozenMap, canonical_payload_bytes
from meta_evolve.domain.workers import TrustedWorker, WorkerId
from meta_evolve.ports.worker_registry import decide_revocation
from meta_evolve.worker_capabilities import compact_json

_STORAGE_HELP = "durable storage directory"

#: The identity column a listing lays its values out after, in the shape
#: `cli.py` gives its own reports.
_IDENTITY = 24

#: Revocation applies to every run in the store, including repeated commands.
_INSTALLATION_WIDE = (
    "leases from earlier generations are freed in every run in this store "
    "at that run's next broker transaction"
)


def add_worker_administration_verb(verbs, execute) -> argparse.ArgumentParser:
    """`meta-evolve workers`: enrol, list, and withdraw trust in a worker."""

    parser = verbs.add_parser(
        "workers",
        help="administer the workers a store trusts",
        description=(
            "Enrol a worker, list the enrolments, or withdraw one. The "
            "allow-list belongs to the store, so it outlives every run in it."
        ),
    )
    parser.set_defaults(execute=execute)
    commands = parser.add_subparsers(dest="command", required=True, metavar="command")

    enrol = _command(commands, "add", "enrol a worker this store will trust", _add)
    _names_a_worker(enrol, "the identity the worker will connect under")
    enrol.add_argument(
        "--capability",
        dest="capabilities",
        action=_DeclareCapability,
        default={},
        metavar="KEY=VALUE",
        help=(
            "a capability this worker declares, repeatable; VALUE is read as "
            "JSON if it is JSON and as text otherwise"
        ),
    )

    _command(commands, "list", "report every worker this store has a row for", _listing)

    withdraw = _command(
        commands, "revoke", "withdraw this store's trust in a worker", _revoke
    )
    _names_a_worker(withdraw, "the enrolled identity to withdraw trust in")
    return parser


def administer_workers(arguments: argparse.Namespace) -> str:
    """Carry out the one `workers` command these arguments name."""

    return arguments.administer(arguments)


def _command(commands, name: str, help_text: str, administer):
    """One sub-verb, shaped like `cli.py`'s own: storage, then what to do."""

    parser = commands.add_parser(name, help=help_text, description=help_text)
    parser.add_argument(
        "--storage", required=True, metavar="PATH", help=_STORAGE_HELP
    )
    parser.set_defaults(administer=administer)
    return parser


def _names_a_worker(parser: argparse.ArgumentParser, help_text: str) -> None:
    """The one positional both writing commands take, read by one rule."""

    parser.add_argument(
        "worker_id", metavar="WORKER_ID", type=_operator_id, help=help_text
    )


def _operator_id(value: str) -> WorkerId:
    """The text an operator typed, through the domain's one constructor for it.

    A parser `type`, so a bad id is a usage error before any store is opened.
    """

    try:
        return WorkerId.operator_supplied(value)
    except ValueError as refusal:
        raise argparse.ArgumentTypeError(str(refusal)) from refusal


class _DeclareCapability(argparse.Action):
    """One `--capability KEY=VALUE`, added to the declaration the flags build.

    VALUE is whatever JSON it spells, as a component's `work_requirements` may,
    and the literal text when it spells none: `arch=arm64` needs no quotes and
    `gpu=true` is a boolean. `NaN` and `Infinity` are text: Python's `json`
    reads them, and no recorded value may hold them.

    An empty key, a repeated key (as a flag, or inside a JSON object) and a
    value no record can hold are usage errors, raised before any store opens.
    `FrozenMap` judges the last by the rule a manifest's requirements are
    frozen by, which is also why an array typed here equals a tuple a
    component declared, and encoding it is what refuses text no record can
    store: a lone surrogate, which is how an undecodable argv byte arrives.
    """

    def __call__(self, parser, namespace, values, option_string=None) -> None:
        key, separator, text = str(values).partition("=")
        if not separator or not key:
            raise argparse.ArgumentError(
                self, f"expected KEY=VALUE with a non-empty KEY, not {values!r}"
            )
        declared = dict(getattr(namespace, self.dest))
        if key in declared:
            raise argparse.ArgumentError(self, f"the capability {key!r} is declared twice")
        try:
            declared[key] = _declared_value(text)
            canonical_payload_bytes(FrozenMap(declared))
        except RecursionError as refusal:
            raise argparse.ArgumentError(
                self, "capability value is nested too deeply"
            ) from refusal
        except (TypeError, ValueError, _Ambiguous) as refusal:
            raise argparse.ArgumentError(self, str(refusal)) from refusal
        setattr(namespace, self.dest, declared)


class _Ambiguous(Exception):
    """Not a `ValueError`, which would make the text a literal instead."""


def _declared_value(text: str) -> object:
    try:
        return json.loads(
            text, parse_constant=_not_a_value, object_pairs_hook=_unambiguous
        )
    except ValueError:
        return text


def _unambiguous(pairs: list[tuple[str, object]]) -> dict[str, object]:
    """One JSON object, refused if it names a key twice: `json` keeps the last."""

    seen: dict[str, object] = {}
    for key, value in pairs:
        if key in seen:
            raise _Ambiguous(f"the value declares {key!r} twice")
        seen[key] = value
    return seen


def _not_a_value(constant: str) -> object:
    raise ValueError(f"{constant} is not a JSON value")


def _add(arguments: argparse.Namespace) -> str:
    """Enrol a worker, creating the store if needed, and report the committed row."""

    with meta.Storage.durable(arguments.storage) as storage:
        enrolled = storage.trusted_worker_authority().trust(
            arguments.worker_id, arguments.capabilities
        )
    return (
        f"{enrolled.worker.value} is enrolled at generation {enrolled.generation} "
        f"with capabilities {compact_json(dict(enrolled.capabilities))}\n"
    )


def _listing(arguments: argparse.Namespace) -> str:
    """Every row this store holds, trusted and revoked, in the order it keeps.

    Opened read-only: it never migrates a store, works while a dispatcher holds
    it, and reads a pre-5 store as empty.
    """

    with meta.Storage.read_only(arguments.storage) as inspecting:
        rows = inspecting.trusted_workers().all()
    if not rows:
        return "no workers are enrolled in this store\n"
    return "".join(_listed(row) for row in rows)


def _listed(row: TrustedWorker) -> str:
    """One row: who, whether they are trusted, at which generation, declaring what.

    Laid out like `cli.py`'s reports (whose `_row` cannot be imported here:
    `cli.py` imports this module). A long id pushes its columns along rather
    than being truncated.
    """

    identity = row.worker.value
    separator = " " if len(identity) >= _IDENTITY else ""
    return (
        f"{identity:<{_IDENTITY}}{separator}{row.status.value:<8} "
        f"generation {row.generation}  {compact_json(dict(row.capabilities))}\n"
    )


def _revoke(arguments: argparse.Namespace) -> str:
    """Revoke a worker and report the committed generation.

    Check existence read-only first to avoid creating a mistyped path or
    migrating an older store only to refuse an unknown id. The write decides
    again inside its transaction, since another operator may change the row.
    """

    with meta.Storage.read_only(arguments.storage) as inspecting:
        decide_revocation(
            inspecting.trusted_workers().get(arguments.worker_id), arguments.worker_id
        )
    with meta.Storage.durable(arguments.storage) as storage:
        withdrawn = storage.trusted_worker_authority().revoke(arguments.worker_id)
    return (
        f"{withdrawn.worker.value} is revoked at generation {withdrawn.generation}\n"
        f"{_INSTALLATION_WIDE}\n"
    )


__all__ = ["add_worker_administration_verb", "administer_workers"]
