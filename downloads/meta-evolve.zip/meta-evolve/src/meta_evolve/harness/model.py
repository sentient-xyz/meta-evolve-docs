"""Typed agent-harness artifacts and their declared mutation surfaces."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from typing import ClassVar, TypeAlias

from meta_evolve.domain import (
    ComponentRef,
    Failure,
    FrozenMap,
    InvalidOutput,
)
from meta_evolve.domain.values import FrozenValue, _require_text, freeze
from meta_evolve.mutation import MutationApplication, MutationSurface


@dataclass(frozen=True, slots=True)
class HarnessMutation:
    """One structured request to change a manifest-declared surface."""

    surface: str
    value: FrozenValue

    def __post_init__(self) -> None:
        _require_text(self.surface, "mutation surface")
        object.__setattr__(self, "value", freeze(self.value))


@dataclass(frozen=True, slots=True)
class TextParam:
    """A named mutable text value with immutable component authority."""

    name: str
    component: ComponentRef
    interface: str
    value: str

    def __post_init__(self) -> None:
        _validate_declaration(self.name, self.component, self.interface)
        if not isinstance(self.value, str):
            raise TypeError("text parameter value must be a string")

    def apply(self, mutation: HarnessMutation) -> MutationApplication[TextParam]:
        failure = _mutation_failure(self.name, mutation)
        if failure is not None:
            return MutationApplication(failure=failure)
        if not isinstance(mutation.value, str):
            return MutationApplication(
                failure=InvalidOutput(
                    message="text mutation value must be a string",
                    details={"surface": self.name},
                )
            )
        if mutation.value == self.value:
            return _no_op(self.name)
        return MutationApplication(surface=replace(self, value=mutation.value))


@dataclass(frozen=True, slots=True)
class PolicyParam:
    """A named mutable policy configuration with immutable authority."""

    name: str
    component: ComponentRef
    interface: str
    configuration: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)

    def __post_init__(self) -> None:
        _validate_declaration(self.name, self.component, self.interface)
        object.__setattr__(self, "configuration", FrozenMap(self.configuration))

    def apply(self, mutation: HarnessMutation) -> MutationApplication[PolicyParam]:
        failure = _mutation_failure(self.name, mutation)
        if failure is not None:
            return MutationApplication(failure=failure)
        if not isinstance(mutation.value, Mapping):
            return MutationApplication(
                failure=InvalidOutput(
                    message="policy mutation value must be a mapping",
                    details={"surface": self.name},
                )
            )
        try:
            configuration = FrozenMap(mutation.value)
        except (TypeError, ValueError) as error:
            return MutationApplication(
                failure=InvalidOutput(
                    message="policy mutation configuration is invalid",
                    details={"surface": self.name, "error": str(error)},
                )
            )
        if configuration == self.configuration:
            return _no_op(self.name)
        return MutationApplication(surface=replace(self, configuration=configuration))


Surface: TypeAlias = TextParam | PolicyParam


@dataclass(frozen=True, slots=True)
class HarnessArtifact:
    """Schema-v1 harness manifest with exactly two mutable parameters."""

    KIND: ClassVar[str] = "agent-harness"
    REPRESENTATION: ClassVar[str] = "harness-manifest-v1"

    planner: TextParam
    context_policy: PolicyParam

    def __post_init__(self) -> None:
        if not isinstance(self.planner, TextParam):
            raise TypeError("harness planner must be a TextParam")
        if not isinstance(self.context_policy, PolicyParam):
            raise TypeError("harness context_policy must be a PolicyParam")
        if self.planner.name == self.context_policy.name:
            raise ValueError("harness mutation surface names must be unique")

    def apply(self, mutation: HarnessMutation) -> HarnessArtifact | Failure:
        """Construct an intended successor through a declared surface.

        This is wrapper convenience. The artifact codec independently repeats
        the authority check inside proposal completion before commit.
        """

        if not isinstance(mutation, HarnessMutation):
            raise TypeError("mutation must be a HarnessMutation")
        for field_name in ("planner", "context_policy"):
            current = getattr(self, field_name)
            if current.name != mutation.surface:
                continue
            application = current.apply(mutation)
            if application.failure is not None:
                return application.failure
            assert application.surface is not None
            return replace(self, **{field_name: application.surface})
        return InvalidOutput(
            message="mutation names an undeclared surface",
            details={"surface": mutation.surface},
        )


def _validate_declaration(
    name: object, component: object, interface: object
) -> None:
    _require_text(name, "parameter name")
    if not isinstance(component, ComponentRef):
        raise TypeError("parameter component must be a ComponentRef")
    _require_text(interface, "parameter interface")


def _mutation_failure(name: str, mutation: object) -> InvalidOutput | None:
    if not isinstance(mutation, HarnessMutation):
        raise TypeError("mutation must be a HarnessMutation")
    if mutation.surface != name:
        return InvalidOutput(
            message="mutation targets a different surface",
            details={"declared": name, "requested": mutation.surface},
        )
    return None


def _no_op(name: str) -> MutationApplication[object]:
    return MutationApplication(
        failure=InvalidOutput(
            message="harness mutation is a no-op",
            details={"surface": name},
        )
    )


__all__ = [
    "HarnessArtifact",
    "HarnessMutation",
    "MutationApplication",
    "MutationSurface",
    "PolicyParam",
    "TextParam",
]
