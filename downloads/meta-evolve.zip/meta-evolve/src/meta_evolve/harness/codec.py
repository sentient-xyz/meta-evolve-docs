"""Canonical harness codec and trusted successor validation."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from meta_evolve.domain import (
    ComponentRef,
    Failure,
    FrozenMap,
    InvalidOutput,
    PolicyViolation,
)
from meta_evolve.domain.values import FrozenValue

from .model import HarnessArtifact, PolicyParam, TextParam


def _component_payload(component: ComponentRef) -> FrozenMap:
    return FrozenMap(
        {
            "role": component.role,
            "name": component.name,
            "version": component.version,
            "origin": component.origin,
        }
    )


def _component(value: object) -> ComponentRef:
    if not isinstance(value, Mapping) or set(value) != {
        "role",
        "name",
        "version",
        "origin",
    }:
        raise ValueError("harness component has invalid fields")
    return ComponentRef(
        role=value["role"],
        name=value["name"],
        version=value["version"],
        origin=value["origin"],
    )


def _text_payload(value: TextParam) -> FrozenMap:
    return FrozenMap(
        {
            "type": "text",
            "name": value.name,
            "component": _component_payload(value.component),
            "interface": value.interface,
            "value": value.value,
        }
    )


def _policy_payload(value: PolicyParam) -> FrozenMap:
    return FrozenMap(
        {
            "type": "policy",
            "name": value.name,
            "component": _component_payload(value.component),
            "interface": value.interface,
            "configuration": value.configuration,
        }
    )


def _require_fields(value: object, fields: set[str], name: str) -> Mapping:
    if not isinstance(value, Mapping) or set(value) != fields:
        raise ValueError(f"{name} has invalid fields")
    return value


@dataclass(frozen=True, slots=True)
class HarnessArtifactCodec:
    """Translate harness manifests and guard every successor before commit."""

    kind: str = HarnessArtifact.KIND
    representation: str = HarnessArtifact.REPRESENTATION
    interfaces: tuple[str, ...] = ("agent-harness/v1",)

    def encode(self, value: object) -> FrozenValue:
        if not isinstance(value, HarnessArtifact):
            raise TypeError("agent-harness tasks require a HarnessArtifact value")
        return FrozenMap(
            {
                "schema": "agent-harness/v1",
                "planner": _text_payload(value.planner),
                "context_policy": _policy_payload(value.context_policy),
            }
        )

    def decode(self, payload: FrozenValue) -> HarnessArtifact:
        manifest = _require_fields(
            payload,
            {"schema", "planner", "context_policy"},
            "harness manifest",
        )
        if manifest["schema"] != "agent-harness/v1":
            raise ValueError("unsupported harness manifest schema")
        planner = _require_fields(
            manifest["planner"],
            {"type", "name", "component", "interface", "value"},
            "planner parameter",
        )
        policy = _require_fields(
            manifest["context_policy"],
            {"type", "name", "component", "interface", "configuration"},
            "context policy parameter",
        )
        if planner["type"] != "text" or policy["type"] != "policy":
            raise ValueError("harness parameter types do not match schema v1")
        return HarnessArtifact(
            planner=TextParam(
                name=planner["name"],
                component=_component(planner["component"]),
                interface=planner["interface"],
                value=planner["value"],
            ),
            context_policy=PolicyParam(
                name=policy["name"],
                component=_component(policy["component"]),
                interface=policy["interface"],
                configuration=policy["configuration"],
            ),
        )

    def validate_successor(
        self,
        parents: tuple[FrozenValue, ...],
        candidate: FrozenValue,
    ) -> Failure | None:
        if len(parents) != 1:
            return InvalidOutput(
                message="harness mutation requires exactly one parent",
                details={"parent_count": len(parents)},
            )
        try:
            parent = self.decode(parents[0])
            successor = self.decode(candidate)
        except (TypeError, ValueError) as error:
            return InvalidOutput(
                message="harness successor is malformed",
                details={"error": str(error)},
            )
        if parent == successor:
            return InvalidOutput(message="harness successor is a no-op")
        changed = authority_changes(parent, successor)
        if changed:
            return PolicyViolation(
                message="harness successor expands mutation authority",
                details={"changed_declarations": changed},
            )
        return None


def authority_changes(
    parent: HarnessArtifact, successor: HarnessArtifact
) -> tuple[str, ...]:
    """Return immutable declarations changed by ``successor``."""

    changed: list[str] = []
    for field_name in ("planner", "context_policy"):
        before = getattr(parent, field_name)
        after = getattr(successor, field_name)
        if type(before) is not type(after):
            changed.append(f"{field_name}.type")
            continue
        for attribute in ("name", "component", "interface"):
            if getattr(before, attribute) != getattr(after, attribute):
                changed.append(f"{field_name}.{attribute}")
    return tuple(changed)


__all__ = ["HarnessArtifactCodec", "authority_changes"]
