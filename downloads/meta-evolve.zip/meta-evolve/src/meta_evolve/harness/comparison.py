"""Strict held-out comparison for unchanged harness seeds."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from meta_evolve.domain import Failure, Maximize, RunId, Usage
from meta_evolve.errors import RunError, RunsNotComparable

from .codec import authority_changes
from .model import HarnessArtifact


Verdict = Literal["improvement", "tie", "regression", "unrankable"]


@dataclass(frozen=True, slots=True)
class HarnessEvaluation:
    """The held-out quality and actual cost evidence from one seed-only run."""

    run_id: RunId
    quality: int | float | None
    usage: Usage
    failures: tuple[Failure, ...]


@dataclass(frozen=True, slots=True)
class HarnessComparison:
    """A strict report; eligibility is evidence, never deployment authority."""

    baseline: HarnessEvaluation
    candidate: HarnessEvaluation
    verdict: Verdict
    promotion_eligible: bool

    def __post_init__(self) -> None:
        if self.verdict not in {
            "improvement",
            "tie",
            "regression",
            "unrankable",
        }:
            raise ValueError("unknown harness comparison verdict")
        expected = self.verdict == "improvement"
        if self.promotion_eligible != expected:
            raise ValueError(
                "promotion eligibility requires a rankable strict improvement"
            )


def compare_harnesses(baseline_run: object, candidate_run: object) -> HarnessComparison:
    """Compare two compatible held-out seed evaluations under equal controls."""

    from meta_evolve.application.results import Run

    if not isinstance(baseline_run, Run) or not isinstance(candidate_run, Run):
        raise TypeError("baseline_run and candidate_run must be Run values")
    baseline_projection = baseline_run._projection()
    candidate_projection = candidate_run._projection()
    baseline_start = baseline_projection.start
    candidate_start = candidate_projection.start
    if baseline_start is None or candidate_start is None:
        raise RunError("held-out comparison requires started runs")

    for start in (baseline_start, candidate_start):
        if (
            start.search.policy.name != "greedy"
            or start.search.policy.version != "1"
            or start.search.configuration.get("max_trials") != 0
        ):
            raise RunsNotComparable("seed-only Greedy(max_trials=0) search")

    _equal(baseline_start.task.evaluator, candidate_start.task.evaluator, "evaluator")
    _equal(
        baseline_start.task.artifact_kind,
        candidate_start.task.artifact_kind,
        "artifact kind",
    )
    _equal(
        baseline_start.task.artifact_representation,
        candidate_start.task.artifact_representation,
        "artifact representation",
    )
    _equal(baseline_start.task.objectives, candidate_start.task.objectives, "objectives")
    _equal(baseline_start.task.budget, candidate_start.task.budget, "task budget")
    _equal(baseline_start.run_budget, candidate_start.run_budget, "run budget")
    _equal(baseline_start.search, candidate_start.search, "search declaration")
    _equal(baseline_start.random_seed, candidate_start.random_seed, "random seed")
    _equal(
        baseline_projection.context_declaration,
        candidate_projection.context_declaration,
        "context declaration",
    )
    _equal(
        baseline_projection.experience_declaration,
        candidate_projection.experience_declaration,
        "experience declaration",
    )

    baseline_artifact = baseline_run._storage.artifacts.get(
        baseline_start.seed_artifact_id
    )
    candidate_artifact = candidate_run._storage.artifacts.get(
        candidate_start.seed_artifact_id
    )
    _equal(baseline_artifact.kind, candidate_artifact.kind, "seed artifact kind")
    _equal(
        baseline_artifact.representation,
        candidate_artifact.representation,
        "seed artifact representation",
    )
    _equal(
        baseline_artifact.schema_version,
        candidate_artifact.schema_version,
        "seed artifact schema",
    )
    baseline_value = baseline_run._codecs.decode(baseline_artifact)
    candidate_value = candidate_run._codecs.decode(candidate_artifact)
    if not isinstance(baseline_value, HarnessArtifact) or not isinstance(
        candidate_value, HarnessArtifact
    ):
        raise RunsNotComparable("agent-harness seed artifact")
    if authority_changes(baseline_value, candidate_value):
        raise RunsNotComparable("harness component references and interfaces")

    baseline = _evaluation(baseline_run)
    candidate = _evaluation(candidate_run)
    if baseline.quality is None or candidate.quality is None:
        verdict: Verdict = "unrankable"
    elif baseline.quality == candidate.quality:
        verdict = "tie"
    else:
        objective = baseline_start.task.objectives[0]
        better = (
            candidate.quality > baseline.quality
            if isinstance(objective, Maximize)
            else candidate.quality < baseline.quality
        )
        verdict = "improvement" if better else "regression"
    return HarnessComparison(
        baseline=baseline,
        candidate=candidate,
        verdict=verdict,
        promotion_eligible=verdict == "improvement",
    )


def _evaluation(run) -> HarnessEvaluation:
    projection = run._projection()
    start = projection.start
    assert start is not None
    trials = run.trials()
    if len(trials) != 1 or trials[0].logical_step != 0:
        raise RunsNotComparable("one seed evaluation and no successor trials")
    trial = trials[0]
    metric = start.task.objectives[0].metric
    quality = trial.metrics.get(metric) if trial.failure is None else None
    return HarnessEvaluation(
        run_id=run.id,
        quality=quality,
        usage=projection.search_state.usage,
        failures=tuple(item.failure for item in trials if item.failure is not None),
    )


def _equal(left: object, right: object, declaration: str) -> None:
    if left != right:
        raise RunsNotComparable(declaration)


__all__ = [
    "HarnessComparison",
    "HarnessEvaluation",
    "Verdict",
    "compare_harnesses",
]
