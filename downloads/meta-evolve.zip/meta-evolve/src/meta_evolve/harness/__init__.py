"""Trusted harness artifacts, mutation surfaces, episodes, and egress views."""

from .episodes import EpisodeSuite, RepositoryEpisode
from .model import (
    HarnessArtifact,
    HarnessMutation,
    MutationApplication,
    MutationSurface,
    PolicyParam,
    TextParam,
)


def __getattr__(name: str):
    # Keep codec discovery acyclic: application.codecs imports harness.codec
    # while the application result types are still being initialized.
    if name in {"HarnessComparison", "HarnessEvaluation"}:
        from .comparison import HarnessComparison, HarnessEvaluation

        return {
            "HarnessComparison": HarnessComparison,
            "HarnessEvaluation": HarnessEvaluation,
        }[name]
    if name == "HarnessExport":
        from .export import HarnessExport

        return HarnessExport
    raise AttributeError(name)

__all__ = [
    "EpisodeSuite",
    "HarnessArtifact",
    "HarnessComparison",
    "HarnessEvaluation",
    "HarnessExport",
    "HarnessMutation",
    "MutationApplication",
    "MutationSurface",
    "PolicyParam",
    "RepositoryEpisode",
    "TextParam",
]
