"""Portable repository episodes for captured harness evaluation."""

from __future__ import annotations

from dataclasses import dataclass

from meta_evolve.domain import ContentDigest, FrozenMap, SourceTree
from meta_evolve.domain.values import _require_text
from meta_evolve.ports import ProcessSpec


@dataclass(frozen=True, slots=True)
class RepositoryEpisode:
    """Public task seed plus evaluator-only tests and bounded execution."""

    name: str
    instruction: str
    source: SourceTree
    evaluator_tests: SourceTree
    process: ProcessSpec

    def __post_init__(self) -> None:
        _require_text(self.name, "episode name")
        _require_text(self.instruction, "episode instruction")
        if not isinstance(self.source, SourceTree):
            raise TypeError("episode source must be a SourceTree")
        if not isinstance(self.evaluator_tests, SourceTree):
            raise TypeError("episode evaluator_tests must be a SourceTree")
        if not isinstance(self.process, ProcessSpec):
            raise TypeError("episode process must be a ProcessSpec")

    def to_payload(self) -> FrozenMap:
        return FrozenMap(
            {
                "name": self.name,
                "instruction": self.instruction,
                "source": self.source.to_payload(),
                "evaluator_tests": self.evaluator_tests.to_payload(),
                "process": {
                    "argv": self.process.argv,
                    "cwd": self.process.cwd,
                    "environment": self.process.environment,
                    "timeout_seconds": self.process.timeout_seconds,
                    "stdout_limit": self.process.stdout_limit,
                    "stderr_limit": self.process.stderr_limit,
                },
            }
        )

    @property
    def digest(self) -> str:
        return ContentDigest.for_payload(self.to_payload()).value


@dataclass(frozen=True, slots=True)
class EpisodeSuite:
    """Explicit, non-overlapping development and held-out episode splits."""

    development: tuple[RepositoryEpisode, ...]
    held_out: tuple[RepositoryEpisode, ...]

    def __post_init__(self) -> None:
        for name in ("development", "held_out"):
            episodes = getattr(self, name)
            if not isinstance(episodes, tuple) or not episodes:
                raise ValueError(f"episode suite {name} split must be non-empty")
            if not all(isinstance(item, RepositoryEpisode) for item in episodes):
                raise TypeError(f"episode suite {name} must contain episodes")
        names = tuple(item.name for item in (*self.development, *self.held_out))
        if len(set(names)) != len(names):
            raise ValueError("episode names must be unique across both splits")

    def to_payload(self) -> FrozenMap:
        return FrozenMap(
            {
                "schema": "repository-episode-suite/v1",
                "development": tuple(item.to_payload() for item in self.development),
                "held_out": tuple(item.to_payload() for item in self.held_out),
            }
        )

    @property
    def digest(self) -> str:
        return ContentDigest.for_payload(self.to_payload()).value


__all__ = ["EpisodeSuite", "RepositoryEpisode"]
