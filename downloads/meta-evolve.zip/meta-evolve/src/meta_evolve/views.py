"""Dependency-light public view records shared by queries and presentation."""

from __future__ import annotations

from dataclasses import dataclass, field

from meta_evolve.domain import ArtifactId, ExperienceUsage
from meta_evolve.domain.experience_access import EXPERIENCE_OPERATIONS
from meta_evolve.domain.values import FrozenValue


@dataclass(frozen=True, slots=True)
class ArtifactView:
    """One artifact occurrence with decoded and inert payload projections.

    ``value`` retains the established author-facing decoded object.  Safe
    presentation consumes only the private frozen payload captured beside it.
    The payload is deliberately absent from repr and equality so adding it does
    not change the existing public view semantics.
    """

    id: ArtifactId
    value: object
    kind: str
    representation: str
    digest: str
    parent_ids: tuple[ArtifactId, ...]
    _payload: FrozenValue = field(repr=False, compare=False)
    _run_token: object = field(repr=False, compare=False)

    def __str__(self) -> str:
        return str(object.__getattribute__(self, "value"))


@dataclass(frozen=True, slots=True)
class ExperienceOperationUsage:
    """Application view of cumulative pull usage for one operation name."""

    operation: str
    usage: ExperienceUsage

    def __post_init__(self) -> None:
        if self.operation not in EXPERIENCE_OPERATIONS:
            raise ValueError(
                f"unsupported experience operation: {self.operation!r}"
            )
        if not isinstance(self.usage, ExperienceUsage):
            raise TypeError("operation usage must be ExperienceUsage")
        if self.usage == ExperienceUsage():
            raise ValueError("zero operation usage must be omitted")


__all__ = ["ArtifactView", "ExperienceOperationUsage"]
