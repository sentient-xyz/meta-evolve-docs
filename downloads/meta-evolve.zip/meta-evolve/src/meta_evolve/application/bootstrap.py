"""Build and atomically commit a run's evaluated bootstrap."""

from __future__ import annotations


from typing import Protocol

from meta_evolve.domain.work import WorkKind, WorkRow
from meta_evolve.ports.work_store import EnqueueWork
from meta_evolve.domain import (
    Artifact,
    ArtifactCreated,
    ArtifactId,
    BootstrapPrepared,
    Budget,
    ComponentRef,
    ContextPolicyDeclared,
    ContextSpec,
    DecisionId,
    ExperienceAccessDeclared,
    ExperienceSpec,
    OperatorSpec,
    Proposal,
    ProposalId,
    RunCapabilities,
    RunId,
    RunStarted,
    SearchSpec,
    Task,
    TaskId,
    Trial,
    TrialCompleted,
    TrialId,
    TrialOutcome,
    TrialSpec,
    Usage,
)
from meta_evolve.domain.values import FrozenValue
from meta_evolve.errors import BudgetUnavailable
from meta_evolve.ports.callables import Evaluator

from .hosts import CommitBatchHost
from .batch_envelopes import batch_envelopes
from .codecs import CodecIndex
from .evaluation_execution import build_evaluation
from .identities import correlation_for_run, stable_id
from .projections import RunProjection
from .committed_fold import fold_committed
from .work import DEFAULT_MAX_ATTEMPTS, has_zero_resource


class BootstrapHost(CommitBatchHost, Protocol):
    run_id: RunId
    task_id: TaskId
    task: Task
    run_budget: Budget
    random_seed: int
    search: SearchSpec
    evaluator: Evaluator
    capabilities: RunCapabilities
    codecs: CodecIndex

    @property
    def projection(self) -> RunProjection: ...


# The retry bound a genesis enqueue records. Declared here rather than defaulted
# on `WorkRow` so the value has one home and a dispatcher can override it per
# run when `RetryPolicy` lands; the record pins no number, and budget cannot
# supply one because an orphaned attempt writes nothing and never reaches usage.


def start_run(
    host: BootstrapHost,
    seed: FrozenValue,
    *,
    context_spec: ContextSpec | None,
    experience_spec: ExperienceSpec | None,
) -> Trial | None:
    required = Usage(evaluations=1)
    if not host.run_budget.allows(required) or has_zero_resource(
        host.run_budget, evaluation=True
    ):
        raise BudgetUnavailable("effective budget cannot fund seed evaluation")
    if host.task.budget is not None and (
        not host.task.budget.allows(required)
        or has_zero_resource(host.task.budget, evaluation=True)
    ):
        raise BudgetUnavailable("task budget cannot fund seed evaluation")

    seed_id = stable_id(ArtifactId, "artifact", host.run_id.value, "seed")
    run_correlation = correlation_for_run(host.run_id)
    run_started = RunStarted(
        task_id=host.task_id,
        task=host.task,
        seed_artifact_id=seed_id,
        run_budget=host.run_budget,
        random_seed=host.random_seed,
        search=host.search,
        capabilities=host.capabilities,
    )

    decision_id = stable_id(DecisionId, "bootstrap-decision", host.run_id.value)
    trial_id = stable_id(TrialId, "trial", decision_id.value)
    operator = OperatorSpec(kind="bootstrap")
    spec = TrialSpec(
        task_id=host.task_id,
        parent_ids=(),
        proposer=ComponentRef.proposer("meta_evolve:bootstrap", "1"),
        operator=operator,
        budget=Budget(evaluations=1),
        random_seed=host.random_seed,
    )
    trial = Trial(
        id=trial_id,
        run_id=host.run_id,
        decision_id=decision_id,
        logical_step=0,
        spec=spec,
    )
    proposal = Proposal(
        id=stable_id(ProposalId, "proposal", trial_id.value),
        trial_id=trial_id,
        parent_ids=(),
        operator=operator,
        metadata={"bootstrap": True},
    )
    artifact = Artifact(
        id=seed_id,
        payload=seed,
        kind=host.task.artifact_kind,
        representation=host.task.artifact_representation,
        provenance={
            "proposal_id": proposal.id.value,
            "run_id": host.run_id.value,
            "trial_id": trial.id.value,
        },
    )
    outcome = TrialOutcome.succeeded(
        trial_id=trial.id,
        proposal_id=proposal.id,
        artifact_ids=(artifact.id,),
    )
    prefix_bodies = [
        run_started,
        BootstrapPrepared(trial=trial, proposal=proposal),
        ArtifactCreated(artifact_id=artifact.id),
        TrialCompleted(trial=trial, outcome=outcome),
    ]

    provisional = host.projection
    for envelope in batch_envelopes(
        host.run_id, prefix_bodies, run_correlation, host.projection
    ):
        provisional = fold_committed(provisional, envelope)

    if host.capabilities.mode == "distributed":
        # Genesis stops here and the bootstrap's evaluation becomes WORK.
        #
        # `prefix_bodies` is already exactly the shape a distributed genesis
        # wants, which is why this is a branch and not a second builder. What
        # cannot be split from it is the enqueue: a genesis that deferred the
        # evaluation and enqueued nothing would owe an evaluation no one holds
        # and could never reach readiness, and the record is explicit that rows
        # are never left unclaimable. So both ride one transaction, through the
        # seam PR-B1 built for exactly this.
        #
        # Context and experience declarations are absent by construction rather
        # than by omission: distributed start refuses both, so there is nothing
        # to fold in after the prefix.
        host.commit_batch(
            list(prefix_bodies),
            occurrences=(artifact,),
            correlation=run_correlation,
            work=(
                EnqueueWork(row=WorkRow.enqueued(
                    run_id=host.run_id,
                    trial_id=trial.id,
                    kind=WorkKind.EVALUATION,
                    max_attempts=DEFAULT_MAX_ATTEMPTS,
                )),
            ),
        )
        return trial

    evidence_bodies, evaluation_completed = build_evaluation(
        provisional,
        trial,
        artifact.id,
        task=host.task,
        result=host.evaluator.evaluate(host.codecs.decode(artifact)),
        run_budget=host.run_budget,
    )
    genesis_bodies: list[object] = [
        *prefix_bodies,
        *evidence_bodies,
        evaluation_completed,
    ]
    if context_spec is not None:
        genesis_bodies.append(ContextPolicyDeclared(spec=context_spec))
    if experience_spec is not None:
        genesis_bodies.append(ExperienceAccessDeclared(spec=experience_spec))

    host.commit_batch(
        genesis_bodies,
        occurrences=(artifact,),
        correlation=run_correlation,
    )
    return None


__all__ = ["start_run"]
