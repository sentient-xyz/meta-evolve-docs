"""Canonical preparation and replay validation for authorized source history."""

from __future__ import annotations

from dataclasses import dataclass

from meta_evolve.domain import (
    Artifact,
    ExperienceFilter,
    ExperienceObservation,
    ExperienceRef,
    ExperienceRequest,
    SourceHistoryBounds,
    SourceHistoryManifest,
    SourcePathListing,
    SourceRead,
    SourceTree,
    TrialId,
)
from meta_evolve.domain.source_history import SOURCE_HISTORY_FORMAT
from meta_evolve.domain.search import InvalidSearchHistory


from .source_history_selection import (
    HISTORY_RECORD_KINDS,
    SourceHistoryFacts,
    SourceHistoryUnavailable,
)


@dataclass(frozen=True, slots=True)
class PreparedSourceHistory:
    manifest: SourceHistoryManifest
    trees: tuple[tuple[ExperienceRef, SourceTree], ...]
    messages: tuple[tuple[ExperienceRef, str | None, str], ...]
    archive_refs: tuple[tuple[int, ExperienceRef], ...]


class _Operations:
    """Replay the fixed mount-owned request prefix from committed outcomes."""

    def __init__(self, operations) -> None:
        self._operations = operations
        self._cursor = 0

    @property
    def complete(self) -> bool:
        return self._cursor == len(self._operations)

    def _next(self, request: ExperienceRequest):
        if self._cursor >= len(self._operations):
            raise InvalidSearchHistory("source history mount has an incomplete operation prefix")
        attempt, resolution = self._operations[self._cursor]
        self._cursor += 1
        if attempt.request != request:
            raise InvalidSearchHistory("source history mount operation prefix is not canonical")
        result = getattr(resolution, "result", None)
        if result is None:
            raise InvalidSearchHistory("source history mount operation did not succeed")
        return result

    def list_source_paths(self, ref, *, as_of=None, limit=None):
        return self._next(
            ExperienceRequest(
                operation="list_source_paths", ref=ref, as_of=as_of, limit=limit
            )
        )

    def read_source(self, ref, *, paths, as_of=None):
        return self._next(
            ExperienceRequest(
                operation="read_source", ref=ref, paths=paths, as_of=as_of
            )
        )

    def search(self, *, record_kinds=(), failure_kinds=(), as_of=None, limit=None):
        return self._next(
            ExperienceRequest(
                operation="search",
                filters=ExperienceFilter(
                    record_kinds=record_kinds, failure_kinds=failure_kinds
                ),
                as_of=as_of,
                limit=limit,
            )
        )

    def ancestors(self, ref, *, as_of=None, limit=None):
        return self._next(
            ExperienceRequest(
                operation="ancestors", ref=ref, as_of=as_of, limit=limit
            )
        )


def prepare_source_history(
    parent: Artifact,
    tree: SourceTree,
    reader,
    bounds: SourceHistoryBounds,
) -> PreparedSourceHistory:
    """Build, audit, and commit one manifest through the scoped reader."""

    head_ref = ExperienceRef(
        run_id=reader.grant.run_id,
        kind="artifact",
        occurrence_id=parent.id.value,
    )
    prepared = _prepare(head_ref, reader, bounds)
    listing = reader._projection().operations_for(reader.grant.trial_id)[0][1].result
    if (
        not isinstance(listing, SourcePathListing)
        or listing.digest != parent.digest
        or listing.paths != tuple(tree)
    ):
        raise SourceHistoryUnavailable(
            "selected source history parent does not match its workspace"
        )
    reader._mount_source_history(prepared.manifest)
    return PreparedSourceHistory(
        manifest=prepared.manifest,
        trees=((head_ref, tree), *prepared.trees[1:]),
        messages=prepared.messages,
        archive_refs=prepared.archive_refs,
    )


def reconstruct_source_history(state, trial_id: TrialId, manifest) -> SourceHistoryManifest:
    """Rebuild a mount only from the exact committed reader outcomes."""

    operations = _Operations(state.operations_for(trial_id))
    try:
        rebuilt = _prepare(manifest.head_ref, operations, manifest.bounds).manifest
    except SourceHistoryUnavailable as error:
        raise InvalidSearchHistory(str(error)) from error
    if not operations.complete:
        raise InvalidSearchHistory("source history mount does not own the exact operation prefix")
    return rebuilt


def _prepare(head_ref, reader, bounds: SourceHistoryBounds) -> PreparedSourceHistory:
    listing = reader.list_source_paths(head_ref)
    _complete_listing(listing, head_ref)

    metadata = reader.search(record_kinds=HISTORY_RECORD_KINDS)
    _complete_observation(metadata, "source history metadata search")
    facts = SourceHistoryFacts(head_ref, metadata)

    ancestors = reader.ancestors(facts.head_trial_ref)
    _complete_observation(ancestors, "source history ancestor traversal")
    candidates = facts.select(bounds, ancestors)

    retained = [candidates[0]]
    digests = {head_ref: listing.digest}
    trees: list[tuple[ExperienceRef, SourceTree]] = [(head_ref, SourceTree())]
    remaining = bounds.max_chars
    for candidate in candidates[1:]:
        item_listing = reader.list_source_paths(candidate.artifact_ref)
        _complete_listing(item_listing, candidate.artifact_ref)
        if not item_listing.paths:
            retained.append(candidate)
            digests[candidate.artifact_ref] = item_listing.digest
            trees.append((candidate.artifact_ref, SourceTree()))
            continue
        read = reader.read_source(candidate.artifact_ref, paths=item_listing.paths)
        _complete_read(read, item_listing)
        if len(read.rendered) > remaining:
            break
        remaining -= len(read.rendered)
        retained.append(candidate)
        digests[candidate.artifact_ref] = read.digest
        trees.append(
            (
                candidate.artifact_ref,
                SourceTree((item.path, item.source) for item in read.files),
            )
        )

    retained_refs = {item.artifact_ref for item in retained}
    entries = tuple(
        facts.entry(item, digests[item.artifact_ref], retained_refs)
        for item in retained
    )
    return PreparedSourceHistory(
        manifest=SourceHistoryManifest(
            format_version=SOURCE_HISTORY_FORMAT,
            head_ref=head_ref,
            entries=entries,
            bounds=bounds,
        ),
        trees=tuple(trees),
        messages=tuple(
            (
                item.artifact_ref,
                *facts.message(item.artifact_ref),
            )
            for item in retained
        ),
        archive_refs=tuple(
            (position, facts.artifact_refs[artifact_id])
            for position, artifact_id in enumerate(
                facts.archive[: bounds.max_archive_members], start=1
            )
            if facts.artifact_refs[artifact_id] in retained_refs
        ),
    )


def _complete_listing(result, ref) -> None:
    if not isinstance(result, SourcePathListing) or result.artifact_ref != ref:
        raise SourceHistoryUnavailable(
            "source history listing does not match its occurrence"
        )
    if result.truncated:
        raise SourceHistoryUnavailable(
            "source history requires a complete path listing"
        )


def _complete_read(result, listing: SourcePathListing) -> None:
    if (
        not isinstance(result, SourceRead)
        or result.artifact_ref != listing.artifact_ref
        or result.digest != listing.digest
        or tuple(item.path for item in result.files) != listing.paths
        or result.truncated
    ):
        raise SourceHistoryUnavailable(
            "source history requires a complete ordered source read"
        )


def _complete_observation(result, name: str) -> None:
    if not isinstance(result, ExperienceObservation) or result.truncated:
        raise SourceHistoryUnavailable(f"{name} must be complete")


__all__ = [
    "HISTORY_RECORD_KINDS",
    "PreparedSourceHistory",
    "SourceHistoryUnavailable",
    "prepare_source_history",
    "reconstruct_source_history",
]
