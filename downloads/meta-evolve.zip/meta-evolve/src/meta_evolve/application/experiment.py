"""The typed declaration accepted by :func:`meta_evolve.run`."""

from __future__ import annotations

from dataclasses import dataclass
from typing import cast

from meta_evolve.domain import SearchProgram, Task
from meta_evolve.policies.context import ContextPolicy
from meta_evolve.ports.experience import ExperienceAccess
from meta_evolve.registry import Registry

from .run_support import ProposerLike


@dataclass(frozen=True, slots=True, kw_only=True)
class Experiment:
    """An immutable evaluated-search declaration.

    Execution starts only when passed to [run][meta_evolve.run] or
    [Session.start][meta_evolve.Session.start]. Construction does not invoke
    components; execution validates their compatibility. Storage, mode, and
    a narrowing budget are execution options. Use ``dataclasses.replace`` to
    make a new declaration while reusing unchanged components.

    Equality is ordinary dataclass equality over these eight fields. In
    particular, no structural equality is promised for live proposer or
    registry objects.

    :param task: Evaluation contract, artifact type, objectives, and optional
        budget ceiling.
    :param seed: Initial value accepted by the task's artifact codec.
    :param proposer: Callable accepting ``(parent)`` or ``(parent, *, context)``,
        adapter, or registered proposer component. Only keyword-only ``context``
        requests [ProposerContext][meta_evolve.ProposerContext]; other defaults remain unchanged.
    :param search: Search policy; ``None`` means budget-led ``Greedy()`` at
        execution time.
    :param context: Policy-pushed feedback, such as [AncestorsOnly][meta_evolve.AncestorsOnly].
        ``None`` and [NoMemory][meta_evolve.NoMemory] select no records.
    :param experience: Bounded agent-pulled access, such as [PullAccess][meta_evolve.PullAccess].
        ``None`` provides no reader. Recording evidence does not enable either
        feedback channel automatically.
    :param random_seed: Integer seed for recorded deterministic search choices;
        defaults to ``0``.
    :param registry: Extra artifact codecs and registered durable components;
        ``None`` uses built-ins and live local callables.
    """

    task: Task
    seed: object
    proposer: ProposerLike
    search: SearchProgram | None = None
    context: ContextPolicy | None = None
    experience: ExperienceAccess | None = None
    random_seed: int = 0
    registry: Registry | None = None


_UNSET = object()


def _normalize_experiment(
    experiment: Experiment | object = _UNSET,
    /,
    *,
    task: Task | object = _UNSET,
    seed: object = _UNSET,
    proposer: ProposerLike | object = _UNSET,
    search: SearchProgram | None | object = _UNSET,
    context: ContextPolicy | None | object = _UNSET,
    experience: ExperienceAccess | None | object = _UNSET,
    random_seed: int | object = _UNSET,
    registry: Registry | None | object = _UNSET,
) -> Experiment:
    """Normalize the positional and compatibility keyword declarations."""

    declarations = {
        "task": task,
        "seed": seed,
        "proposer": proposer,
        "search": search,
        "context": context,
        "experience": experience,
        "random_seed": random_seed,
        "registry": registry,
    }
    supplied = [name for name, value in declarations.items() if value is not _UNSET]
    if experiment is not _UNSET:
        if not isinstance(experiment, Experiment):
            raise TypeError("run() positional declaration must be an Experiment")
        if supplied:
            conflicts = ", ".join(supplied)
            raise TypeError(
                "pass the declaration either as an Experiment or as keywords, "
                f"not both; conflicting fields: {conflicts}"
            )
        return experiment

    missing = [
        name for name in ("task", "seed", "proposer")
        if declarations[name] is _UNSET
    ]
    if missing:
        fields = ", ".join(missing)
        raise TypeError(f"run() missing required declaration keywords: {fields}")

    return Experiment(
        task=cast(Task, task),
        seed=seed,
        proposer=cast(ProposerLike, proposer),
        search=None if search is _UNSET else cast(SearchProgram | None, search),
        context=None if context is _UNSET else cast(ContextPolicy | None, context),
        experience=(
            None
            if experience is _UNSET
            else cast(ExperienceAccess | None, experience)
        ),
        random_seed=0 if random_seed is _UNSET else cast(int, random_seed),
        registry=None if registry is _UNSET else cast(Registry | None, registry),
    )


__all__ = ["Experiment"]
