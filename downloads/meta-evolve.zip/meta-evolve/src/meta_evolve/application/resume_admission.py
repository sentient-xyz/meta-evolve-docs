"""What a resume refuses, and why a changed environment is not among it.

Local mode records no reconstructible component identities. Other modes name
an incompatible component when one exists; otherwise the recorded resumable
flag still governs, even if current admission rules would allow the components.

A changed environment is never a refusal, only reported
(`environment.EnvironmentDrift`, AD6): each worker is still admitted against
the dispatcher's CURRENT fingerprint.
"""

from __future__ import annotations

from meta_evolve.domain import RunId
from meta_evolve.domain.components import RunCapabilities
from meta_evolve.errors import CapabilityError
from meta_evolve.manifests import require_components_for


def require_resumable_run(run_id: RunId, capabilities: RunCapabilities) -> None:
    """Refuse a run that may not resume, naming the reason that applies.

    Every message keeps "is not resumable", because callers match on it.
    """

    if capabilities.resumable:
        return
    if capabilities.mode == "local":
        raise CapabilityError(
            f"run {run_id} is not resumable: it was started in local mode, "
            "which records no component identities for a resume to check "
            "against; start it with mode='durable-local' or mode='distributed' "
            "to make it resumable"
        )
    try:
        require_components_for(capabilities.mode, capabilities.component_manifests)
    except CapabilityError as unadmitted:
        raise CapabilityError(
            f"run {run_id} is not resumable: its recorded components do not "
            f"meet the {capabilities.mode} rule -- {unadmitted}"
        ) from unadmitted
    raise CapabilityError(
        f"run {run_id} is not resumable: the build that started it recorded it "
        f"as not resumable in {capabilities.mode} mode, although its recorded "
        "components meet that mode's rule today; a resume does not upgrade "
        "the flag a run was recorded with"
    )


__all__ = ["require_resumable_run"]
