"""Validation for one pre-proposal authorized source-history mount."""

from __future__ import annotations

from dataclasses import replace

from meta_evolve.domain import SourceHistoryMounted, TrialSpec
from meta_evolve.domain.search import InvalidSearchHistory

from .identities import correlation_for_trial
from .source_history import reconstruct_source_history


def mount_source_history(state, body: SourceHistoryMounted, sequence, correlation):
    decision = next(
        (item for item in state.decisions if item.trial_id == body.trial_id), None
    )
    if decision is None or not isinstance(decision.decision, TrialSpec):
        raise _invalid(sequence, "source history mount has no trial decision")
    if state.grant_for(body.trial_id) is None:
        raise _invalid(sequence, "source history mount has no experience grant")
    if state.source_history_for(body.trial_id) is not None:
        raise _invalid(sequence, "source history was already mounted for this trial")
    if state.proposal_for(body.trial_id) is not None:
        raise _invalid(sequence, "source history mount cannot follow its proposal")
    expected = correlation_for_trial(body.trial_id)
    if correlation != expected:
        raise _invalid(sequence, "source history mount has invalid authority")
    if body.observed_version != state.version:
        raise _invalid(sequence, "source history mount observed the wrong stream version")
    if len(decision.decision.parent_ids) != 1:
        raise _invalid(sequence, "source history mount requires one selected parent")
    if body.manifest.head_ref.run_id != state.run_id or (
        body.manifest.head_ref.occurrence_id
        != decision.decision.parent_ids[0].value
    ):
        raise _invalid(sequence, "source history head is not the selected parent")
    try:
        rebuilt = reconstruct_source_history(state, body.trial_id, body.manifest)
    except InvalidSearchHistory as error:
        raise _invalid(sequence, str(error)) from error
    if rebuilt != body.manifest:
        raise _invalid(sequence, "source history manifest is not canonical")
    return replace(
        state,
        version=sequence,
        source_history_mounts=state.source_history_mounts + (body,),
        experience_cursor_version=sequence,
    )


def _invalid(sequence: int, reason: str) -> InvalidSearchHistory:
    return InvalidSearchHistory(
        f"invalid search history at sequence {sequence}: {reason}"
    )


__all__ = ["mount_source_history"]
