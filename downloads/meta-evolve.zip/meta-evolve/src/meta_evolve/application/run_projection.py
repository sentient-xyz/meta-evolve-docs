"""Validated kernel lifecycle records and their policy-facing view.

Slightly over the usual file-size guideline: the record and the insertion
helpers that maintain its canonical order are one invariant, and splitting the
helpers out would let a caller build the tuples without them.
"""

from __future__ import annotations

from dataclasses import dataclass, replace

from meta_evolve.domain.events import (
    BootstrapPrepared,
    ContextPolicyDeclared,
    ContextSelected,
    EvaluationCompleted,
    ExperienceAccessDeclared,
    ExperienceGrantIssued,
    ExperienceOperationAttempted,
    ExperienceOperationBudgetExhausted,
    ExperienceOperationDenied,
    ExperienceOperationSucceeded,
    EvidenceRecorded,
    PolicyDecisionExplained,
    PolicyDecisionMade,
    ProposalSubmitted,
    RunStarted,
    TrialCompleted,
    SourceHistoryMounted,
)
from meta_evolve.domain.identity import (
    ArtifactId,
    DecisionId,
    EvidenceId,
    EventId,
    RunId,
    TrialId,
)
from meta_evolve.domain.context import ContextBundle, ContextRecord
from meta_evolve.domain.experience_access import ExperienceUsage
from meta_evolve.domain.search import (
    InvalidSearchHistory,
    SearchNotStarted,
    SearchState,
)
from meta_evolve.domain.trial import Proposal, Stop


def _ordered(items, *, key):
    """Stable sort into canonical order; identity on an already-ordered tuple."""

    return tuple(sorted(items, key=key))


@dataclass(frozen=True, slots=True, kw_only=True)
class RunProjection:
    run_id: RunId
    version: int = 0
    event_ids: tuple[EventId, ...] = ()
    experience_records: tuple[ContextRecord, ...] = ()
    start: RunStarted | None = None
    bootstrap: BootstrapPrepared | None = None
    artifact_ids: tuple[ArtifactId, ...] = ()
    decisions: tuple[PolicyDecisionMade, ...] = ()
    explanations: tuple[PolicyDecisionExplained, ...] = ()
    context_declaration: ContextPolicyDeclared | None = None
    context_selections: tuple[ContextSelected, ...] = ()
    experience_declaration: ExperienceAccessDeclared | None = None
    experience_grants: tuple[ExperienceGrantIssued, ...] = ()
    experience_attempts: tuple[ExperienceOperationAttempted, ...] = ()
    experience_successes: tuple[ExperienceOperationSucceeded, ...] = ()
    experience_denials: tuple[ExperienceOperationDenied, ...] = ()
    experience_exhaustions: tuple[ExperienceOperationBudgetExhausted, ...] = ()
    source_history_mounts: tuple[SourceHistoryMounted, ...] = ()
    experience_cursor_version: int = 0
    proposals: tuple[ProposalSubmitted, ...] = ()
    evidence: tuple[EvidenceRecorded, ...] = ()
    completed_trials: tuple[TrialCompleted, ...] = ()
    completed_evaluations: tuple[EvaluationCompleted, ...] = ()
    # Derived, never durable: the evaluation disposition pinned at each
    # successful completion. A tuple rather than a mapping because
    # ``FrozenMap`` keys are strings and a ``TrialId`` is not one, and
    # because the projection is a frozen record that must stay hashable.
    evaluation_dispositions: tuple[tuple[TrialId, bool], ...] = ()

    @classmethod
    def empty(cls, run_id: RunId) -> RunProjection:
        if not isinstance(run_id, RunId):
            raise TypeError("run projection id must be a RunId")
        return cls(run_id=run_id)

    @property
    def ready(self) -> bool:
        if self.start is None or self.bootstrap is None:
            return False
        trial_id = self.bootstrap.trial.id
        return (
            self.start.seed_artifact_id in self.artifact_ids
            and self.completed_trial(trial_id) is not None
            and self.evaluation_for(trial_id) is not None
        )

    @property
    def search_state(self) -> SearchState:
        if not self.ready:
            raise SearchNotStarted(f"search run {self.run_id} is not bootstrapped")
        return SearchState(
            run_id=self.run_id,
            version=self.version,
            start=self.start,
            artifact_ids=self.artifact_ids,
            decisions=self.decisions,
            completed_trials=self.completed_trials,
            completed_evaluations=self.completed_evaluations,
        )

    @property
    def stop(self) -> Stop | None:
        if self.decisions and isinstance(self.decisions[-1].decision, Stop):
            return self.decisions[-1].decision
        return None

    def proposal_for(self, trial_id: TrialId) -> Proposal | None:
        if self.bootstrap is not None and self.bootstrap.trial.id == trial_id:
            return self.bootstrap.proposal
        return next(
            (
                item.proposal
                for item in self.proposals
                if item.proposal.trial_id == trial_id
            ),
            None,
        )

    def completed_trial(self, trial_id: TrialId) -> TrialCompleted | None:
        return next(
            (item for item in self.completed_trials if item.trial.id == trial_id),
            None,
        )

    def disposition_for(self, trial_id: TrialId) -> bool | None:
        """Whether this trial's evaluation was authorized when it completed.

        THREE-VALUED, and the third value is the one readers get wrong.

        * ``True``  -- authorized; an evaluation is owed and its absence before
          a later decision is abandonment.
        * ``False`` -- refused; the budget answered no, and no evaluation is
          owed.
        * ``None``  -- NO ANSWER. Three cases, not two: a failed trial, the
          bootstrap (whose evaluation is committed inside genesis before the
          run is ready, so it is never pinned), and -- the case this docstring
          used to omit -- a trial that completed SUCCESSFULLY with recorded
          usage exceeding its own allocation (``transitions.py``). The budget
          question is ill-posed there rather than answered, and keeping it
          distinct from ``False`` is what lets replay stay total on historical
          overages.

        Reading this three-valued answer as two-valued is what produced #217,
        so every reader names which of the three it means.
        """

        return next(
            (
                authorized
                for pinned_id, authorized in self.evaluation_dispositions
                if pinned_id == trial_id
            ),
            None,
        )

    def with_completed_trial(
        self, body: TrialCompleted, *, version: int, disposition: bool | None
    ) -> RunProjection:
        """Record a completed trial in logical order, with its pinned disposition.

        Policy-facing collections are canonical: ordering them here is what makes
        a policy's view independent of the order results arrive in, rather than
        asking every consumer to sort. On a sequential stream commit order is
        already logical order, so this is an identity.
        """

        completed = _ordered(
            self.completed_trials + (body,),
            key=lambda item: (item.trial.logical_step, item.trial.id.value),
        )
        # The artifact list is the last policy-facing collection to become
        # canonical, and this is the first moment it can: an artifact is
        # committed BEFORE the completion that attributes it, so at
        # `ArtifactCreated` there is no producing trial to order by. The
        # completion carries both, and lands in the same batch immediately
        # after -- so ordering happens here rather than at insertion, and the
        # seed attributes to the bootstrap at step zero.
        produced = {
            artifact_id: item.trial.logical_step
            for item in completed
            for artifact_id in item.outcome.artifact_ids
        }
        artifacts = _ordered(
            self.artifact_ids, key=lambda item: (produced.get(item, 0), item.value)
        )
        recorded = replace(
            self,
            version=version,
            artifact_ids=artifacts,
            completed_trials=completed,
        )
        if disposition is None:
            return recorded
        return recorded.with_pinned_disposition(body.trial.id, disposition)

    def with_pinned_disposition(
        self, trial_id: TrialId, disposition: bool
    ) -> RunProjection:
        """Pin one trial's evaluation disposition, canonically.

        Split out because the disposition cannot be computed until the trial is
        already recorded -- the residual is read from the projection that
        includes it. The fold therefore built the projection with no
        disposition, read two fields off it, discarded it, and rebuilt from the
        prior state. Each build re-sorts every completed trial AND every
        artifact, so a run of n trials paid twice for both. Now it records
        once and pins onto that.
        """

        # Canonical like the collections beside it: two projections folded from
        # the same facts in different arrival orders must compare equal, or a
        # frozen record's equality becomes schedule-dependent.
        return replace(
            self,
            evaluation_dispositions=_ordered(
                self.evaluation_dispositions + ((trial_id, disposition),),
                key=lambda item: item[0].value,
            ),
        )

    def with_completed_evaluation(
        self, body: EvaluationCompleted, *, version: int, logical_step: int
    ) -> RunProjection:
        """Record a completed evaluation ordered by its producing trial's step.

        ``logical_step`` is the producing trial's, which an ``Evaluation`` does
        not carry; the evaluation id is the final tiebreak.
        """

        # One index per insertion, not a lookup per comparison. The sort calls
        # its key for every element, so scanning the completed trials inside the
        # key would make each insertion quadratic and replay cubic; the index
        # keeps insertion to one linear pass plus the sort.
        steps = {
            item.trial.id: item.trial.logical_step for item in self.completed_trials
        }
        steps[body.evaluation.trial_id] = logical_step

        def step_of(item: EvaluationCompleted) -> int:
            trial_id = item.evaluation.trial_id
            if trial_id not in steps:
                # The fold admits an evaluation only for a completed trial, so
                # this cannot happen on a validated stream. Fail closed rather
                # than sorting an orphan to the front as step zero.
                raise InvalidSearchHistory(
                    "evaluation references a trial with no completion: "
                    f"{trial_id.value}"
                )
            return steps[trial_id]

        ordered = _ordered(
            self.completed_evaluations + (body,),
            key=lambda item: (step_of(item), item.evaluation.id.value),
        )
        return replace(self, version=version, completed_evaluations=ordered)

    def evaluation_for(self, trial_id: TrialId) -> EvaluationCompleted | None:
        return next(
            (
                item
                for item in self.completed_evaluations
                if item.evaluation.trial_id == trial_id
            ),
            None,
        )

    def explanation_for(
        self, decision_id: DecisionId
    ) -> PolicyDecisionExplained | None:
        return next(
            (
                item
                for item in self.explanations
                if item.decision_id == decision_id
            ),
            None,
        )

    def selection_for(self, trial_id: TrialId) -> ContextSelected | None:
        return next(
            (item for item in self.context_selections if item.trial_id == trial_id),
            None,
        )

    def context_for(self, trial_id: TrialId) -> ContextBundle | None:
        selected = self.selection_for(trial_id)
        return selected.bundle if selected is not None else None

    def grant_for(self, trial_id: TrialId):
        issued = next(
            (item for item in self.experience_grants if item.grant.trial_id == trial_id),
            None,
        )
        return issued.grant if issued is not None else None

    def resolution_for(self, operation_id):
        return next(
            (
                item
                for item in (
                    *self.experience_successes,
                    *self.experience_denials,
                    *self.experience_exhaustions,
                )
                if item.operation_id == operation_id
            ),
            None,
        )

    def operations_for(self, trial_id: TrialId):
        return tuple(
            (
                attempt,
                self.resolution_for(attempt.operation_id),
            )
            for attempt in self.experience_attempts
            if attempt.trial_id == trial_id
        )

    def source_history_for(self, trial_id: TrialId) -> SourceHistoryMounted | None:
        return next(
            (item for item in self.source_history_mounts if item.trial_id == trial_id),
            None,
        )

    def experience_usage_for(self, trial_id: TrialId) -> ExperienceUsage:
        operations = self.operations_for(trial_id)
        if not operations:
            return ExperienceUsage()
        resolution = operations[-1][1]
        if resolution is None:
            return operations[-1][0].usage
        result = getattr(resolution, "result", None)
        return result.usage if result is not None else resolution.usage

    def evidence_by_id(self, evidence_id: EvidenceId):
        return next(
            (
                item.evidence
                for item in self.evidence
                if item.evidence.id == evidence_id
            ),
            None,
        )


__all__ = ["RunProjection"]
