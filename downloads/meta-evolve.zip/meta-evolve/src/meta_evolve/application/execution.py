"""Dispatch one committed trial to its configured proposer runner."""

from __future__ import annotations

import random
from collections.abc import Iterable
from typing import Protocol

from meta_evolve.domain import (
    Artifact,
    ArtifactId,
    Budget,
    ContextBundle,
    RunCapabilities,
    RunId,
    Task,
    Trial,
    TrialOutcome,
)
from meta_evolve.ports import ArtifactStore
from meta_evolve.ports.callables import Evaluator
from meta_evolve.ports.experience import ExperienceReader
from meta_evolve.ports.runners import ProposerRunner

from meta_evolve.errors import InputsUnavailable
from .hosts import CommitBatchHost
from .codecs import CodecIndex
from .integrity import load_committed_artifact
from meta_evolve.ports.escapes import escapes_normalization

from .identities import completion_key_for, correlation_for_trial
from .proposal_completion import complete_work
from .projections import RunProjection
from .work import (
    ProposerContext,
    ProposalWork,
)


class ExecutionHost(CommitBatchHost, Protocol):
    run_id: RunId
    task: Task
    run_budget: Budget
    proposer_runner: ProposerRunner
    evaluator: Evaluator
    artifacts: ArtifactStore
    capabilities: RunCapabilities
    codecs: CodecIndex

    @property
    def projection(self) -> RunProjection: ...


def load_parents(
    artifacts: ArtifactStore, parent_ids: Iterable[ArtifactId]
) -> tuple[Artifact, ...]:
    """Load committed parents for sequential and distributed execution.

    One home for both execution paths. The escape guard is ordered first, as
    the callable adapters order theirs: `escapes_normalization` reads the OUTER
    exception and never follows `__cause__`, so wrapping a durable fault in
    anything would put it below the boundary -- the dispatcher would release it,
    spend the retry bound against a deterministic fault and commit "exhausted N
    attempts" over a broken store, and a sequential run would stop with the
    durable fault's type hidden.

    What survives the guard is translated to `InputsUnavailable` rather than
    `InvalidDecision`. Both reach the same retry, so the choice looks cosmetic
    from here and is not: a resumed run ends a row whose recorded cause names
    `InvalidDecision` without re-running it, and a store that answered a read
    badly once is the case the retry bound is for.
    """

    try:
        return tuple(load_committed_artifact(artifacts, item) for item in parent_ids)
    except Exception as error:
        if escapes_normalization(error):
            raise
        raise InputsUnavailable(
            "trial parent is unavailable from artifact storage"
        ) from error


def execute_trial(
    host: ExecutionHost,
    trial: Trial,
    bundle: ContextBundle,
    experience: ExperienceReader | None = None,
) -> TrialOutcome:
    spec = trial.spec
    parents = load_parents(host.artifacts, spec.parent_ids)
    correlation = correlation_for_trial(trial.id)
    work = ProposalWork(
        trial=trial,
        completion_key=completion_key_for(trial.id),
    )
    result = host.proposer_runner.execute(
        parents,
        ProposerContext(
            rng=random.Random(spec.random_seed),
            step=trial.logical_step,
            objectives=host.task.objectives,
            bundle=bundle,
            experience=experience,
            context_policy=spec.context_policy,
        ),
    )
    return complete_work(host, work, result, correlation)


__all__ = [
    "ExecutionHost",
    "load_parents",
    "execute_trial",
]
