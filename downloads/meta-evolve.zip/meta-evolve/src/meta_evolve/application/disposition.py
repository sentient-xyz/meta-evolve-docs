"""Reserved capacity, and the one rule that authorizes an evaluation.

This lives in ``application`` rather than ``domain`` because the reservation
fold reads dispositions pinned on a ``RunProjection``. ``work.py`` re-exports
``evaluation_authorized`` and ``has_zero_resource``.

Reserved budget is *derived from committed events, never stored*. Capacity
freed outside the stream would make a later decision unreproducible, so there
is no ledger here -- only folds over facts that are already durable.

Only the count dimensions are reserved. ``tokens``, ``wall_seconds`` and
``spend_micros`` are measured: a component reports what it consumed, and a
monetary ceiling halts rather than holding capacity, so none of them has a
prospective form to reserve against. Reserving them would also be actively
wrong -- the shipped presets copy the run's whole measured allowance into every
trial, so one in-flight sibling would zero the pool for the next.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from meta_evolve.domain import Budget, TrialId, TrialSpec, Usage, spend_exhausted

if TYPE_CHECKING:  # pragma: no cover - annotation only
    from .run_projection import RunProjection


def has_zero_resource(budget: Budget, *, evaluation: bool = False) -> bool:
    fields = (budget.tokens, budget.wall_seconds)
    if evaluation:
        fields = (budget.evaluations, *fields)
    return any(value == 0 for value in fields if value is not None)


def evaluation_authorized(
    remaining_budget: Budget, trial_budget: Budget, used: Usage
) -> bool:
    """Whether a completed trial's evaluation still fits its effective budget.

    THE single source of the resume-equivalence-critical authorization calc.
    The coordinator pins this value at the trial's completion and every reader
    consumes the pinned result -- the live completion path, the resume tail,
    the recovery frontier classifier and the outstanding-work definition -- so
    an uninterrupted run and a resumed run make byte-identical evaluate/skip
    decisions because they read one recorded answer rather than re-deriving it.

    ``remaining_budget`` is the run's available capacity at that completion,
    already reduced by the reservations of every *other* outstanding trial;
    ``trial_budget`` is the trial's ``spec.budget`` and ``used`` its outcome
    usage. Two terms survive from the sequential rule and are not replaced by
    the reservation fold: the trial's own remaining allocation still narrows
    the result, and spend is adjudicated against the trial's own charge, so a
    free proposal under a ``$0`` ceiling still evaluates. Exhaustion caused by
    *earlier* trials is refused at admission instead.

    A trial whose recorded usage already exceeds its own allocation has nothing
    left to spend on an evaluation, so it is unauthorized rather than an error.
    Live execution commits such an overrun as a typed resource exhaustion
    before it ever completes successfully, but a historical stream may carry
    one, and replay must stay total -- historical overages are replayable,
    floored at zero, while prospective overruns are refused.

    That answer is *unauthorized*, not *legitimately skipped*, and the thing
    that keeps the two apart is the pin being tri-state, not a second check
    elsewhere. `recovery.classify_frontier` used to re-derive the overrun and
    call such a stream corrupt, which contradicted this fold's own claim that it
    replays (#217); it now reads the pinned value instead. Nothing unowed can be
    abandoned, so an inflated usage record has nothing left to hide behind.
    """

    if not trial_budget.allows(used):
        return False
    narrowed = remaining_budget.narrow(trial_budget.remaining_after(used))
    return not has_zero_resource(narrowed, evaluation=True) and not spend_exhausted(
        remaining=narrowed, charged=used
    )


def trial_allocation(spec: TrialSpec) -> Usage:
    """The capacity a decided trial holds until it reaches a terminal fact."""

    return Usage(
        trials=spec.budget.trials or 0,
        evaluations=spec.budget.evaluations or 0,
    )


def evaluation_residual(spec: TrialSpec, used: Usage) -> Usage:
    """What a completed trial still holds while an authorized evaluation is owed.

    On an accepted stream ``used.evaluations`` is zero, so this is the
    allocation's evaluation count; the subtraction and floor bound a foreign
    row's value.
    """

    allocation = trial_allocation(spec)
    return Usage(evaluations=max(0, allocation.evaluations - used.evaluations))


def less_reserved(budget: Budget, reserved: Usage) -> Budget:
    """``budget`` with reserved counts removed; unbounded stays unbounded.

    An empty reservation is the identity, which is what makes a sequential run
    -- where nothing is ever outstanding at decision time -- reduce exactly to
    the shipped admission rule.
    """

    def remaining(limit: int | None, amount: int) -> int | None:
        return None if limit is None else max(0, limit - amount)

    return Budget(
        evaluations=remaining(budget.evaluations, reserved.evaluations),
        trials=remaining(budget.trials, reserved.trials),
        tokens=budget.tokens,
        spend_micros=budget.spend_micros,
        wall_seconds=budget.wall_seconds,
    )


def outstanding_trial_ids(projection: RunProjection) -> tuple[TrialId, ...]:
    """Every trial that still owes work, in logical order.

    A trial is outstanding when it has a committed trial decision and either it
    has no completion, or its completion succeeded, its pinned evaluation
    disposition is *evaluate*, and no evaluation has completed. The second
    clause is what distinguishes a trial that still owes an evaluation from one
    whose evaluation was terminally skipped as unauthorized.

    The bootstrap trial is included, and it is the one trial whose answer does
    not come from the pin. It has no `PolicyDecisionMade` to iterate -- it
    arrives as `BootstrapPrepared` -- and it is never pinned a disposition,
    because its evaluation is owed by genesis rather than authorized by one. So
    it is outstanding while it has no completion, or a successful completion
    with no evaluation, and its disposition is never consulted.

    It was excluded until M11.2, justified by being outstanding "exactly while
    the run is not ready, which is already an absolute barrier to any policy
    decision". That holds only while genesis commits the evaluated bootstrap in
    one atomic batch. A distributed genesis makes the run observable in between,
    and an excluded bootstrap would leave no committed fact saying the
    evaluation is owed.
    """

    # Indexed once per call rather than scanned per decision. This runs at every
    # admission and every successful completion, each already costing one linear
    # pass, so a run is quadratic with the index and would be cubic without it.
    completed_by_id = {item.trial.id: item for item in projection.completed_trials}
    evaluated = {item.evaluation.trial_id for item in projection.completed_evaluations}
    pinned = dict(projection.evaluation_dispositions)

    outstanding: list[TrialId] = []
    bootstrap = projection.bootstrap
    if bootstrap is not None:
        bootstrap_id = bootstrap.trial.id
        completed = completed_by_id.get(bootstrap_id)
        if completed is None or (
            completed.outcome.failure is None and bootstrap_id not in evaluated
        ):
            outstanding.append(bootstrap_id)
    for decision in projection.decisions:
        trial_id = decision.trial_id
        if trial_id is None:
            continue
        completed = completed_by_id.get(trial_id)
        if completed is None:
            outstanding.append(trial_id)
            continue
        if completed.outcome.failure is not None:
            continue
        if pinned.get(trial_id) is not True:
            continue
        if trial_id not in evaluated:
            outstanding.append(trial_id)
    return tuple(outstanding)


def reserved_usage(
    projection: RunProjection, *, excluding: TrialId | None = None
) -> Usage:
    """Capacity held by outstanding trials, optionally excluding one.

    The completing trial is already omitted when a disposition is being pinned:
    its own answer is not yet recorded at that moment, and a completed trial
    counts as outstanding only once its disposition says *evaluate*.
    ``excluding`` states that intent explicitly, so a caller that pins before
    folding still gets the same answer. An incomplete sibling reserves its full
    allocation; a completed one reserves only its evaluation residual.

    ``excluding`` is inert at its only caller today, which calls this before
    the disposition is pinned. It guards a cohort member pinned while its
    siblings are still folding; no test drives it while it is a no-op.
    """

    specs = {
        item.trial_id: item.decision
        for item in projection.decisions
        if item.trial_id is not None and isinstance(item.decision, TrialSpec)
    }
    # The bootstrap's spec is on its `BootstrapPrepared`, not on a decision it
    # never had. Without this it falls through the `spec is None` guard below
    # and reserves nothing -- a silent zero for a trial the fold has just
    # declared outstanding.
    if projection.bootstrap is not None:
        specs.setdefault(
            projection.bootstrap.trial.id, projection.bootstrap.trial.spec
        )
    completed_by_id = {item.trial.id: item for item in projection.completed_trials}

    total = Usage()
    for trial_id in outstanding_trial_ids(projection):
        if trial_id == excluding:
            continue
        spec = specs.get(trial_id)
        if spec is None:
            continue
        completed = completed_by_id.get(trial_id)
        if completed is None:
            total = total + trial_allocation(spec)
        else:
            total = total + evaluation_residual(spec, completed.outcome.usage)
    return total


__all__ = [
    "evaluation_authorized",
    "evaluation_residual",
    "has_zero_resource",
    "less_reserved",
    "outstanding_trial_ids",
    "reserved_usage",
    "trial_allocation",
]
