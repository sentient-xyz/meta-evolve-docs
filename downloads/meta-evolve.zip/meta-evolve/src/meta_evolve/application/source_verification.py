"""Independent durable verification of committed source observations."""

from __future__ import annotations

from meta_evolve.domain import ExperienceOperationSucceeded
from meta_evolve.errors import (
    DurableCorruption,
    ExperienceAccessDenied,
    ExperienceBudgetExhausted,
)
from meta_evolve.ports import ArtifactStore

from .source_diff import build_source_diff_result
from .source_operations import (
    SOURCE_OPERATIONS, build_source_result, visible_source_occurrence,
)
from .source_resolution import resolve_source_tree


def verify_source_results(artifacts: ArtifactStore, state) -> None:
    """Reproduce every committed listing/read from its durable artifact."""

    attempts = {item.operation_id: item for item in state.experience_attempts}
    for success in state.experience_successes:
        if not isinstance(success, ExperienceOperationSucceeded):
            continue
        attempt = attempts.get(success.operation_id)
        if (
            attempt is None
            or attempt.request.operation not in SOURCE_OPERATIONS
        ):
            continue
        grant = state.grant_for(attempt.trial_id)
        assert grant is not None
        occurrence = visible_source_occurrence(state, grant, attempt.request)
        if occurrence is None:
            raise DurableCorruption(
                "committed source result has no authorized artifact occurrence"
            )
        try:
            resolved = resolve_source_tree(artifacts, occurrence)
            if attempt.request.operation == "diff_source":
                newer_occurrence = visible_source_occurrence(
                    state,
                    grant,
                    attempt.request,
                    ref=attempt.request.other_ref,
                )
                if newer_occurrence is None:
                    raise ExperienceAccessDenied()
                newer = resolve_source_tree(artifacts, newer_occurrence)
                expected = build_source_diff_result(
                    resolved,
                    newer,
                    attempt.request,
                    attempt.usage,
                    max_results=grant.spec.max_results,
                    max_records=grant.spec.max_records,
                    max_chars=grant.spec.max_chars,
                )
            else:
                expected = build_source_result(
                    resolved,
                    attempt.request,
                    attempt.usage,
                    max_results=grant.spec.max_results,
                    max_records=grant.spec.max_records,
                    max_chars=grant.spec.max_chars,
                )
        except (ExperienceAccessDenied, ExperienceBudgetExhausted) as error:
            raise DurableCorruption(
                "committed source result cannot be reproduced from its artifact"
            ) from error
        if success.result != expected:
            raise DurableCorruption(
                "committed source result does not match its durable artifact"
            )


__all__ = ["verify_source_results"]
