"""The dispatch loop: every backend an event source in one `selectors` loop.

The loop selects over its endpoints' file descriptors, settles each outcome
through the one completion path (`dispatch_submission.py`), and renews every
lease it holds while its endpoint is alive. It runs on the dispatcher thread,
the sole writer of the store's one connection; commits stay synchronous.

**Renewal.** A bound lease is renewed every `lease // 4` of the
injected clock while its endpoint has heartbeated within `lease // 4`. For the
inline endpoint the heartbeat IS its helper being alive, so the cadence is the
same cadence as `call_renewing`: the due time is read before the call starts,
and the loop wakes every `POLL_SECONDS` because the injected clock can move with
no fd event. A wire lease is not renewed per heartbeat frame: the frame stamps
the time, and the due rule renews, so broker writes do not scale with heartbeat
frequency. Inline, a renewal that fails while the call still runs ends the
drive, not the attempt -- released, the row would be claimed again beside the
running call -- and one that fails after the call returned is that attempt's
failure, since the call has ended. On the wire, a refused renewal is ANSWERED
`Stale` and the lease unbound; the drive goes on.

**Liveness under a blocking step.** Rule 1: before any step that can
block -- a commit, input resolution, reclaim, a policy call -- the loop drains
every readable endpoint (heartbeats and pulls apply at once; outcomes wait in
the inbox, so a commit never recurses into another) and renews every lease
whose deadline is closer than `lease // 2` and whose endpoint heartbeated
within `lease // 4`. Rule 2: disconnects are judged only after draining, at
silence past `3 * (lease // 4)`, so frames buffered while the loop was blocked
count. Rule 3: each step is measured, and one past `lease // 4` is recorded as
a `StepOverrun` -- ephemeral, never written anywhere durable.

**Transport failure.** An endpoint that breaks the protocol, or
breaks, is failed: every lease bound to it is released with cause
`WorkerDisconnected`, it is closed and forgotten, and the other endpoints go on.

Past the ~300-line guideline: selecting, draining, judging silence, settling,
renewing and the blocking-step guard are one iteration's control flow, and the
liveness rules only read correctly with all of them in view.

**Abandoning.** When an exception leaves a drive, `abandon` unbinds every
lease and retires every endpoint's call. The binding is scheduling state only:
the durable row keeps what the failure left, and the next drive on the same
dispatcher sees exactly what a fresh one would.
"""

from __future__ import annotations

import selectors
from collections import deque
from collections.abc import Callable, Iterable, Iterator
from contextlib import contextmanager

from meta_evolve.ports.escapes import escapes_normalization
from meta_evolve.domain.work import Lease, StaleReason, WorkItemId
from meta_evolve.ports.work_submission import StaleCompletion

from .dispatch_admission import Workers, admit_into
from .dispatch_endpoint import Endpoint
from .dispatch_messages import (
    WORKER_DISCONNECTED,
    WORKER_INTERRUPTED,
    Submission,
    StepOverrun,
    TransportFailure,
    Work,
)
from .dispatch_outcomes import reportable_cause
from .dispatch_binding import Binding
from .dispatch_endpoint import Endpoint
from .dispatch_submission import Settler

#: How often, in REAL seconds, the loop looks up from waiting -- not the renewal
#: interval, which is in broker seconds: how promptly anything due is noticed.
POLL_SECONDS = 0.01

class DispatchLoop:
    """The selector, the endpoints, the bindings in flight, the renewal rule."""

    def __init__(
        self,
        *,
        clock: Callable[[], int],
        lease_seconds: int,
        settler: Settler,
        admission: Workers | None = None,
    ) -> None:
        self._clock = clock
        self._interval = lease_seconds // 4
        self._half = lease_seconds // 2
        self._silence = 3 * (lease_seconds // 4)
        self._settler = settler
        self._admission = admission
        self._selector = selectors.DefaultSelector()
        self._bindings: dict[WorkItemId, Binding] = {}
        self._inbox: deque[tuple[Endpoint, Submission]] = deque()
        self.endpoints: list[Endpoint] = []
        self.overruns: list[StepOverrun] = []

    # -- endpoints and bindings ----------------------------------------------

    def register(self, endpoint: Endpoint) -> None:
        self._selector.register(endpoint.fileno(), selectors.EVENT_READ, endpoint)
        self.endpoints.append(endpoint)

    def in_flight(self) -> bool:
        return bool(self._bindings)

    def bound_to(self, endpoint: Endpoint) -> int:
        return sum(1 for binding in self._bindings.values() if binding.endpoint is endpoint)

    def holds(self, item: WorkItemId) -> bool:
        return item in self._bindings

    def wanting_work(self) -> list[Endpoint]:
        return [e for e in self.endpoints if e.wants_work(self.bound_to(e))]

    def start(self, binding: Binding, work: Work) -> None:
        """Bind `work`'s lease to its endpoint, then start the call there.

        The first renewal falls due one interval after the clock reading taken
        HERE, before the call starts: read after, a component that advances the
        clock at once pushes the first renewal a whole interval late.
        """

        binding.due = self._clock() + self._interval
        self._bindings[work.lease.item] = binding
        try:
            binding.endpoint.start(work)
        except TransportFailure as failure:
            self.fail(binding.endpoint, str(failure), failure.cause)

    def supersede(
        self, old: Endpoint, new: Endpoint, held: tuple[Lease, ...]
    ) -> None:
        """Hand `old`'s work to `new`, then fail what `new` did not claim.

        The ORDER is the rule (design PD5): `fail` releases every lease still
        bound to `old`, so a lease the reconnecting worker listed has to move
        BEFORE it runs. What it did not list is released at once rather than
        waited out -- it has no result to resend, so its deadline would only
        idle a capacity slot (D3).

        A listed lease is moved only when its credential still matches the
        binding. A lease from an earlier attempt or epoch is not this call;
        resent, it is answered from the store like any other late outcome.
        """

        listed = {lease.item: lease for lease in held}
        for item, binding in self._bindings.items():
            lease = listed.get(item)
            if (
                binding.endpoint is old
                and lease is not None
                # The epoch too: `credential_mismatch` deliberately leaves it
                # to its caller, and a lease from a superseded dispatcher is
                # not this call however well the rest of it matches.
                and lease.epoch == binding.lease.epoch
                and lease.credential_mismatch(binding.lease) is None
            ):
                binding.endpoint = new
        self.fail(old, "superseded by a reconnect of the same worker")
        self.register(new)

    def abandon(self) -> None:
        """Unbind everything and retire every call; see the module docstring."""

        for binding in self._bindings.values():
            binding.endpoint.retire()
        self._bindings.clear()
        self._inbox.clear()

    def fail(
        self, endpoint: Endpoint, reason: str, cause: str = WORKER_DISCONNECTED
    ) -> None:
        """Release what `endpoint` held, with its cause, and forget it.

        `cause` is the connection's, not the loop's: a worker that said
        goodbye was interrupted, and that is what its attempt records.
        """

        held = [
            (item, binding)
            for item, binding in self._bindings.items()
            if binding.endpoint is endpoint
        ]
        for item, _binding in held:
            del self._bindings[item]
        if endpoint in self.endpoints:
            self.endpoints.remove(endpoint)
            self._selector.unregister(endpoint.fileno())
            self._inbox = deque(entry for entry in self._inbox if entry[0] is not endpoint)
        first: Exception | None = None
        try:
            for _item, binding in held:
                # Every lease is released even if one release fails: they are
                # all already unbound, so one left unreleased here would wait
                # out its deadline with nothing tracking it.
                try:
                    self._settler.fail_attempt(binding.lease, (cause, reason))
                except Exception as error:
                    if first is None:
                        first = error
                    else:
                        first.add_note(f"releasing another lease also failed: {error!r}")
        finally:
            # Closed whatever the releases did: it is already forgotten, so
            # nothing else would ever close it.
            endpoint.close()
        if first is not None:
            raise first

    def close(self) -> None:
        self._selector.close()

    # -- one iteration -------------------------------------------------------

    def pump(self, timeout: float) -> None:
        """Wait up to `timeout`, drain, judge silence, settle, renew, write."""

        self._drain(self._selector.select(timeout))
        # Before anything is judged or settled: a worker admitted since the
        # last poll may be the one whose leases are about to be superseded.
        admit_into(self, self._admission)
        self._judge_silence()
        while self._inbox:
            endpoint, message = self._inbox.popleft()
            if endpoint in self.endpoints:
                self._settle(endpoint, message)
        # After the inbox, never before it: a worker that sent an outcome and
        # then said goodbye is owed that outcome's settlement, and `fail`
        # drops whatever of its inbox is left.
        self._judge_departures()
        self._renew_due()
        self._write()

    def _drain(self, ready: Iterable[tuple[selectors.SelectorKey, int]]) -> None:
        for key, _events in ready:
            endpoint = key.data
            if endpoint not in self.endpoints:
                continue
            try:
                messages = endpoint.receive(self._clock)
            except TransportFailure as failure:
                self.fail(endpoint, str(failure), failure.cause)
                continue
            self._inbox.extend((endpoint, message) for message in messages)

    def _judge_silence(self) -> None:
        for endpoint in list(self.endpoints):
            silent = endpoint.silent_for(self._clock)
            if silent is not None and silent > self._silence:
                self.fail(endpoint, f"no heartbeat for {silent} seconds")

    def _judge_departures(self) -> None:
        """Fail every endpoint that said goodbye (design PD6).

        Asked rather than read: a farewell arrives as a message, and after it
        the connection has no more readable bytes to wake the selector with,
        so nothing else would notice a worker that left without closing.
        """

        for endpoint in list(self.endpoints):
            reason = endpoint.departed()
            if reason is not None:
                self.fail(endpoint, reason, WORKER_INTERRUPTED)

    def _settle(self, endpoint: Endpoint, message: Submission) -> None:
        # Unbound BEFORE settling: a settle that raises aborts the drive, and
        # the binding must not outlive the call it described.
        binding = self._bindings.get(message.lease.item)
        try:
            if (
                binding is None
                or binding.endpoint is not endpoint
                # The attempt too, not only the item: a late outcome of an
                # earlier attempt must never settle the current one's lease.
                or message.lease.credential_mismatch(binding.lease) is not None
            ):
                self._settler.settle_unbound(endpoint, message)
                return
            # While still BOUND: a result of the wrong kind fails its
            # connection with the lease attached, so `fail` releases it with
            # its cause instead of stranding it until expiry.
            self._settler.refuse_foreign_result(binding, message)
            del self._bindings[message.lease.item]
            self._settler.settle(binding, message, self.blocking, self.protect)
        except TransportFailure as failure:
            self.fail(endpoint, str(failure), failure.cause)

    def _renew_due(self) -> None:
        for item, binding in list(self._bindings.items()):
            endpoint = binding.endpoint
            if not endpoint.alive(self._clock, self._interval):
                continue
            try:
                now = self._clock()
                if now >= binding.due:
                    renewed, _now = binding.keepalive()
                    binding.deadline = renewed.deadline
                    binding.due = now + self._interval
            except BaseException as error:
                if endpoint.answers_submissions:
                    if not isinstance(error, StaleCompletion):
                        raise
                    del self._bindings[item]
                    self._answer_stale(endpoint, binding.lease, error.reason)
                    continue
                if (
                    endpoint.alive(self._clock, self._interval)
                    or not isinstance(error, Exception)
                    or escapes_normalization(error)
                ):
                    raise
                # The call returned while the renewal was failing: its attempt
                # has ended, so the failure is that attempt's, and its outcome
                # -- which can no longer be committed under this lease -- is
                # dropped with the binding.
                del self._bindings[item]
                endpoint.retire()
                self._settler.fail_attempt(binding.lease, reportable_cause(error))

    def _write(self) -> None:
        for endpoint in list(self.endpoints):
            if not endpoint.wants_write():
                continue
            try:
                endpoint.flush()
            except TransportFailure as failure:
                self.fail(endpoint, str(failure), failure.cause)

    # -- blocking steps ------------------------------------------------------

    def protect(self, binding: Binding) -> Lease | StaleReason:
        """Renew `binding`'s lease before the commit it is about to make.

        `blocking` pre-renews from `self._bindings`, and the settling binding
        has already been removed from it -- it must be, or a settle that raises
        would leave a binding outliving the call it described. So the ONE lease
        whose result is being committed is the one lease its own commit cannot
        protect, and a long build spends its remaining time unrenewed.

        Called after entering `blocking`, so its drain has applied heartbeats
        queued during the preceding commit. Kept as an explicit call so a
        refused renewal returns from the settle, not from the generator
        context manager before its yield.

        The rule is `blocking`'s, unchanged: renew only what is inside half a
        lease of its deadline, and only while the endpoint is still heard from.
        A binding with time left needs nothing, and answers its own lease.
        """

        now = self._clock()
        if binding.deadline >= now + self._half:
            return binding.lease
        if not binding.endpoint.alive(self._clock, self._interval):
            return binding.lease
        renewed, _now = binding.keepalive()
        binding.deadline = renewed.deadline
        return renewed


    @contextmanager
    def blocking(self, step: str) -> Iterator[None]:
        """Drain, pre-renew what a long step could let lapse, measure the step."""

        self._drain(self._selector.select(0))
        now = self._clock()
        for item, binding in list(self._bindings.items()):
            if binding.deadline >= now + self._half:
                continue
            if not binding.endpoint.alive(self._clock, self._interval):
                continue
            try:
                renewed, _now = binding.keepalive()
            except StaleCompletion as stale:
                if not binding.endpoint.answers_submissions:
                    raise
                del self._bindings[item]
                self._answer_stale(binding.endpoint, binding.lease, stale.reason)
                continue
            binding.deadline = renewed.deadline
        try:
            yield
        except BaseException as error:
            try:
                self._measure(step, now)
            except Exception as clock_error:
                # The step's own raise is the one that must propagate; the
                # clock's failure travels with it rather than vanishing.
                error.add_note(
                    f"measuring the {step} step also failed: "
                    f"{type(clock_error).__name__}: {clock_error}"
                )
            raise
        self._measure(step, now)

    def _measure(self, step: str, since: int) -> None:
        spent = self._clock() - since
        if spent > self._interval:
            self.overruns.append(StepOverrun(step, spent))

    def _answer_stale(
        self, endpoint: Endpoint, lease: Lease, reason: StaleReason
    ) -> None:
        """Answer a refused renewal; a send that fails fails THAT connection."""

        try:
            self._settler.answer_stale(endpoint, lease, reason)
        except TransportFailure as failure:
            self.fail(endpoint, str(failure), failure.cause)


__all__ = [
    "POLL_SECONDS",
    "WORKER_DISCONNECTED",
    "WORKER_INTERRUPTED",
    "DispatchLoop",
    "Endpoint",
]
