"""Driving a distributed run, with or without worker processes.

`Session.drive`'s body, moved out so that the phase ordering and the cleanup
can be read together -- they are one rule, and `session.py` is at its length.

**The order is the promise** (PD2, T13). Workers are spawned and admitted
BEFORE the rollover, so a handshake that fails raises with the epoch
unchanged, nothing claimed and a genesis-only run still resumable. Without
`execution=` every call is PR 2's, byte for byte.

**Ownership starts the moment `open()` returns.** From there, rollover, the
dispatcher's construction and the drive itself all sit inside one `try`,
because each of them can raise while children are alive. Every cleanup step
runs even when an earlier one raised, and the drive's own error is the one
that propagates: a cleanup failure travels as a note on it rather than
replacing the fault an operator needs to see.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, cast

from meta_evolve.domain.events import RunStarted
from meta_evolve.domain.search import SearchProgram
from meta_evolve.environment import environment_fingerprint

from .dispatch_admission import Execution, HostTerms, Workers
from .dispatcher import Dispatcher

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .coordinator import SequentialCoordinator


def drive_distributed(
    coordinator: SequentialCoordinator,
    program: SearchProgram,
    *,
    execution: Execution | None,
    lease_seconds: int,
) -> None:
    """Run the work frontier to its terminal state through `execution`."""

    # ONE broker, built with the run's duration, so the dispatcher and every
    # renewal agree on when a lease ends. Built before anything is spawned, so
    # a duration below the floor refuses before a child exists.
    broker = coordinator.work_broker(lease_seconds=lease_seconds)
    workers = None if execution is None else execution.open(_terms(coordinator, lease_seconds))
    dispatcher: Dispatcher | None = None
    failure: BaseException | None = None
    try:
        # The record's explicit recovery step, run unconditionally rather than
        # behind a "was this resumed" flag. Harmless on a fresh run, and
        # load-bearing on a resumed one: `WorkerId.for_slot` is a pure digest,
        # so a restarted process reconstructs the SAME worker identities, and
        # without the rollover their own dead leases would count against
        # capacity until they expired -- or forever, on an injected clock.
        coordinator.fence.install(broker.rollover(coordinator.run_id))
        dispatcher = Dispatcher(
            coordinator,
            broker,
            program=program,
            endpoints=None if workers is None else workers.endpoints,
            admission=workers,
        )
        dispatcher.drive()
    except BaseException as error:
        failure = error
        raise
    finally:
        _clean_up(workers, dispatcher, failure)


def _terms(coordinator: SequentialCoordinator, lease_seconds: int) -> HostTerms:
    """The recorded run, this dispatcher's build, and access to its store's reader."""

    declaration = coordinator.projection.context_declaration
    return HostTerms(
        run_id=coordinator.run_id,
        # A cast, not a check: only a started run has a session to drive.
        started=cast(RunStarted, coordinator.projection.start),
        context=None if declaration is None else declaration.spec,
        manifests=coordinator.capabilities.component_manifests,
        fingerprint=environment_fingerprint(),
        heartbeat_seconds=max(1, lease_seconds // 4),
        trusted_workers=coordinator.trusted_workers,
    )


def _clean_up(
    workers: Workers | None,
    dispatcher: Dispatcher | None,
    failure: BaseException | None,
) -> None:
    """Every step runs; the drive's error is the one that propagates."""

    steps: list[Callable[[], None]] = []
    if workers is not None:
        steps.append(lambda: workers.finish(completed=failure is None))
    if dispatcher is not None:
        steps.append(dispatcher.close)
    first: BaseException | None = None
    for step in steps:
        try:
            step()
        except BaseException as error:  # noqa: BLE001 - re-raised or noted below
            if failure is not None:
                failure.add_note(f"cleaning up after the drive also failed: {error!r}")
            elif first is None:
                first = error
            else:
                first.add_note(f"another cleanup step also failed: {error!r}")
    if first is not None:
        raise first


__all__ = ["drive_distributed"]
