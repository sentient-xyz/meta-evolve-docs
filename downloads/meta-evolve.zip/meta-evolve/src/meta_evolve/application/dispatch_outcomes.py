"""What became of a call: the one split every backend reports an outcome with.

Split from `dispatch_messages.py`, which declares the protocol: this is the
behaviour both ends share around it. The inline helper thread and a wire
worker run a call with `call_for`, report it with `outcome_of`, and compute a
failure's recorded pair with `reportable_cause` where the exception was raised,
so one raise is one outcome, and one recorded cause, whichever backend ran it.
"""

from __future__ import annotations

from collections.abc import Callable

from meta_evolve.domain.work import Lease
from meta_evolve.ports.escapes import escapes_normalization

from .dispatch_messages import (
    Submission,
    AttemptFailed,
    Completed,
    CompletionFailed,
    Escaped,
    EvaluationCall,
    Work,
)
from .executors import CandidateEncodingError


def reportable_cause(error: BaseException) -> tuple[str, str]:
    """The failure pair, following one `__cause__` link.

    `load_parents` raises `InputsUnavailable("trial parent is unavailable
    from artifact storage") from error`, so the wrapper names the symptom and
    the real storage error is one link away. Recording only the wrapper put a
    generic sentence on the row and in the terminal fact, which is the thing
    the diagnostics work exists to stop.

    ONE link, not a walk to the root: the immediate cause is the one the
    wrapper chose to attach, and a deeper chain is the cause's own business.
    Here rather than in the dispatcher because a worker computes it too, where
    the exception was raised, so both backends record the same two strings.
    """

    cause = error.__cause__
    if cause is None:
        return (type(error).__name__, error_text(error))
    # The TYPE field stays a bare class name: `application/work.py` documents
    # that `exception_type` matches what the callable adapters record, and they
    # record `type(error).__name__`. The chain belongs in the message.
    return (
        type(error).__name__,
        f"{error_text(error)} (caused by {type(cause).__name__}: {error_text(cause)})",
    )


def error_text(error: BaseException) -> str:
    """`str(error)`, or a stand-in when the exception's own `__str__` raises.

    Computed on the helper thread while a failure is being reported: a raise
    here would end the helper before it handed any outcome back, and the call
    would stay bound, unsettled, forever. The wire shares it for the same
    reason in its own shape -- `serve` catches a failed send and reports the
    SAME outcome, so an unguarded `str()` raises again inside the handler and
    ends the connection, turning an escaping failure into a retryable
    disconnect.
    """

    try:
        return str(error)
    except Exception as broken:
        return f"<{type(error).__name__} whose str() raised {type(broken).__name__}>"


def call_for(work: Work, evaluation, proposal) -> Callable[[], object]:
    """The executor call `work` names, not yet made: one dispatch on the call's
    kind, shared by every backend that runs work."""

    call = work.call
    if isinstance(call, EvaluationCall):
        return lambda: evaluation.evaluate(call.artifact)
    return lambda: proposal.propose(call.parents, call.request)


def outcome_of(lease: Lease, call: Callable[[], object]) -> Submission:
    """Run `call` and say what became of it, as the message a backend sends.

    ONE statement of the split, used by the inline helper thread and by a wire
    worker alike, so the same raise is the same outcome whichever backend ran
    it: a value is `Completed`; a codec fault encoding the proposer's
    candidate is `CompletionFailed`; a raise past the normalization boundary,
    or any `BaseException`, is `Escaped`; any other exception is an attempt
    failure, its cause computed here where it was raised.
    """

    try:
        return Completed(lease=lease, result=call())
    except CandidateEncodingError as error:
        return CompletionFailed(lease=lease, error=error, cause=reportable_cause(error))
    except BaseException as error:  # handed back, never swallowed
        if isinstance(error, Exception) and not escapes_normalization(error):
            return AttemptFailed(lease=lease, cause=reportable_cause(error))
        return Escaped(lease=lease, error=error)


__all__ = ["call_for", "outcome_of", "reportable_cause"]
