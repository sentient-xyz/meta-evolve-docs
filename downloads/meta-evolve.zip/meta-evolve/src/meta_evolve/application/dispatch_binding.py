"""A claimed item in flight: its binding, and the `Work` its call is.

Split from `dispatch_submission.py`, which settles an outcome; this is what the
dispatcher and the loop hold while the call runs -- the lease, the row, the
resolved inputs the completion will need, the keepalive, and when the next
renewal falls due.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from meta_evolve.domain import Artifact, CorrelationId, RunId, Trial
from meta_evolve.domain.work import Lease, WorkRow
from meta_evolve.errors import DurableCorruption
from meta_evolve.ports.work_store import WorkBroker

from .executors import ProposalRequest

from .dispatch_endpoint import Endpoint
from .dispatch_messages import EvaluationCall, ProposalCall, Work
from .identities import correlation_for_work


@dataclass(frozen=True, slots=True)
class EvaluationInputs:
    """What an evaluation was resolved to: the trial it is owed for, and what
    is being evaluated."""

    trial: Trial
    artifact: Artifact


@dataclass(frozen=True, slots=True)
class ProposalInputs:
    """What a proposal was resolved to: the decided trial, its loaded parents,
    and the request the proposer is given."""

    trial: Trial
    parents: tuple[Artifact, ...]
    request: ProposalRequest


#: What `_resolve` reads for an item. The ROW'S KIND says which, and both the
#: bind and the settle branch on it -- named fields rather than positions,
#: because the two sites had to agree about `resolved[1]` by hand, where it is
#: an `Artifact` for one kind and a tuple of them for the other.
ResolvedInputs = EvaluationInputs | ProposalInputs


@dataclass(slots=True)
class Binding:
    """A claimed item in flight on one endpoint, and how to keep it alive."""

    endpoint: Endpoint
    lease: Lease
    row: WorkRow
    resolved: ResolvedInputs
    correlation: CorrelationId
    keepalive: Callable[[], tuple[Lease, int]]
    #: When the next renewal falls due, in broker seconds.
    due: int
    #: The deadline the lease was last renewed to.
    deadline: int


def bind_work(
    endpoint: Endpoint,
    lease: Lease,
    row: WorkRow,
    resolved: ResolvedInputs,
    *,
    broker: WorkBroker,
    run_id: RunId,
    keepalive: Callable[[], tuple[Lease, int]],
) -> tuple[Binding, Work]:
    """The binding a claimed lease is tracked by, and the `Work` its call is.

    The row was listed before the claim and must still be listed after it: a
    broker that leases an item it cannot list disagrees with the dispatcher
    about durable state, which is corruption rather than something to retry.
    """

    if all(listed.item != lease.item for listed in broker.rows(run_id)):
        raise DurableCorruption(
            f"leased work item {lease.item.value} is absent from the work table"
        )
    call: EvaluationCall | ProposalCall
    if isinstance(resolved, EvaluationInputs):
        call = EvaluationCall(artifact=resolved.artifact)
    else:
        call = ProposalCall(parents=resolved.parents, request=resolved.request)
    binding = Binding(
        endpoint=endpoint,
        lease=lease,
        row=row,
        resolved=resolved,
        correlation=correlation_for_work(row.item.value),
        keepalive=keepalive,
        due=0,
        deadline=lease.deadline,
    )
    return binding, Work(lease=lease, call=call)


__all__ = [
    "Binding",
    "EvaluationInputs",
    "ProposalInputs",
    "ResolvedInputs",
    "bind_work",
]
