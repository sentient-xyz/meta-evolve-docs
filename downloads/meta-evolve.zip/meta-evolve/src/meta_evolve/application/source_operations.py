"""Bounded source execution and replay-contract validation."""

from __future__ import annotations

import json
from dataclasses import replace
from typing import Callable

from meta_evolve.domain import (
    ArtifactCreated,
    ExperienceGrant,
    ExperienceOperationAttempted,
    ExperienceRequest,
    ExperienceUsage,
    SourceFile,
    SourceDiff,
    SourcePathListing,
    SourceRead,
)
from meta_evolve.errors import ExperienceAccessDenied, ExperienceBudgetExhausted

from .experience import ExperienceGraph, ExperienceQuery
from .source_diff import build_source_diff_result, source_diff_entry_is_canonical
from .source_resolution import ResolvedSourceTree


SOURCE_READ_OPERATIONS = frozenset({"list_source_paths", "read_source"})
SOURCE_OPERATIONS = SOURCE_READ_OPERATIONS | {"diff_source"}


def render_source_path(path: str) -> str:
    return json.dumps(path, ensure_ascii=False)


def render_source_file(file: SourceFile) -> str:
    return json.dumps(
        {"path": file.path, "source": file.source},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def _prefix(entries: tuple, lines: tuple[str, ...], records: int, chars: int):
    retained = []
    rendered = ""
    for entry, line in zip(entries[:records], lines[:records], strict=True):
        candidate = line if not retained else f"{rendered}\n{line}"
        if len(candidate) > chars:
            break
        retained.append(entry)
        rendered = candidate
    return tuple(retained), rendered


def build_source_result(
    resolved: ResolvedSourceTree,
    request: ExperienceRequest,
    before: ExperienceUsage,
    *,
    max_results: int,
    max_records: int,
    max_chars: int,
):
    """Build the canonical largest complete prefix for one resolved tree."""

    record_capacity = max(0, max_records - before.records)
    char_capacity = max(0, max_chars - before.chars)
    if request.operation == "list_source_paths":
        if before.results >= max_results:
            raise ExperienceBudgetExhausted()
        complete = tuple(resolved.tree)
        eligible = complete if request.limit is None else complete[: request.limit]
        paths, rendered = _prefix(
            eligible,
            tuple(render_source_path(path) for path in eligible),
            record_capacity,
            char_capacity,
        )
        usage = replace(
            before,
            results=before.results + 1,
            records=before.records + len(paths),
            chars=before.chars + len(rendered),
        )
        return SourcePathListing(
            artifact_ref=request.ref,
            digest=resolved.digest,
            paths=paths,
            rendered=rendered,
            truncated=len(paths) < len(complete),
            usage=usage,
        )
    if request.operation != "read_source":
        raise ExperienceAccessDenied()
    try:
        files = tuple(
            SourceFile(path=path, source=resolved.tree[path])
            for path in request.paths
        )
    except KeyError:
        # Every path is proved before capacity is reserved or any content is
        # disclosed, so a missing late path atomically denies the whole read.
        raise ExperienceAccessDenied() from None
    if before.results >= max_results:
        raise ExperienceBudgetExhausted()
    retained, rendered = _prefix(
        files,
        tuple(render_source_file(file) for file in files),
        record_capacity,
        char_capacity,
    )
    usage = replace(
        before,
        results=before.results + 1,
        records=before.records + len(retained),
        chars=before.chars + len(rendered),
    )
    return SourceRead(
        artifact_ref=request.ref,
        digest=resolved.digest,
        files=retained,
        rendered=rendered,
        truncated=len(retained) < len(files),
        usage=usage,
    )


def execute_source_request(
    graph: ExperienceGraph,
    request: ExperienceRequest,
    before: ExperienceUsage,
    *,
    max_results: int,
    max_records: int,
    max_chars: int,
    resolve: Callable[[object], ResolvedSourceTree] | None,
):
    if resolve is None or request.operation not in SOURCE_OPERATIONS:
        raise ExperienceAccessDenied()
    query = ExperienceQuery(
        task_id=graph.task_id,
        run_id=graph.run_id,
        as_of=request.as_of,
    )
    records = graph.state_at(query).records

    def occurrence(ref):
        found = next(
            (
                item
                for item in records
                if item.ref == ref and isinstance(item.value, ArtifactCreated)
            ),
            None,
        )
        if found is None:
            raise ExperienceAccessDenied()
        return found

    # Resolve and verify in declared operand order before reserving capacity.
    resolved = resolve(occurrence(request.ref))
    if request.operation == "diff_source":
        newer = resolve(occurrence(request.other_ref))
        return build_source_diff_result(
            resolved,
            newer,
            request,
            before,
            max_results=max_results,
            max_records=max_records,
            max_chars=max_chars,
        )
    return build_source_result(
        resolved,
        request,
        before,
        max_results=max_results,
        max_records=max_records,
        max_chars=max_chars,
    )


def visible_source_occurrence(
    state, grant: ExperienceGrant, request, *, ref=None
):
    """Return the exact committed target visible at the effective boundary."""

    as_of = grant.as_of if request.as_of is None else request.as_of
    target = request.ref if ref is None else ref
    if target is None or target.run_id != state.run_id:
        return None
    return next(
        (
            item
            for item in state.experience_records
            if item.ref == target
            and isinstance(item.value, ArtifactCreated)
            and item.logical_step <= as_of
        ),
        None,
    )


def source_success_violation(
    state,
    grant: ExperienceGrant,
    attempt: ExperienceOperationAttempted,
    result: object,
) -> str | None:
    request = attempt.request
    expected_type = {
        "list_source_paths": SourcePathListing,
        "read_source": SourceRead,
        "diff_source": SourceDiff,
    }[request.operation]
    if not isinstance(result, expected_type):
        return "source experience success has the wrong result shape"
    if isinstance(result, SourceDiff):
        if (
            result.older_artifact_ref != request.ref
            or result.newer_artifact_ref != request.other_ref
        ):
            return "source experience success targeted the wrong occurrences"
        if (
            visible_source_occurrence(state, grant, request) is None
            or visible_source_occurrence(
                state, grant, request, ref=request.other_ref
            ) is None
        ):
            return "source experience success targeted invisible source"
    else:
        if result.artifact_ref != request.ref:
            return "source experience success targeted the wrong occurrence"
        if visible_source_occurrence(state, grant, request) is None:
            return "source experience success targeted invisible source"
    before = attempt.usage
    after = result.usage
    entries = (
        result.paths
        if isinstance(result, SourcePathListing)
        else result.entries
        if isinstance(result, SourceDiff)
        else result.files
    )
    expected_results = 2 if isinstance(result, SourceDiff) else 1
    if (
        after.operations != before.operations
        or after.results - before.results != expected_results
        or after.records - before.records != len(entries)
        or after.chars - before.chars != len(result.rendered)
        or after.results > grant.spec.max_results
        or after.records > grant.spec.max_records
        or after.chars > grant.spec.max_chars
    ):
        return "source experience success usage does not match its result"
    if isinstance(result, SourceDiff):
        paths = tuple(entry.path for entry in result.entries)
        if paths != tuple(sorted(paths)):
            return "source diff paths are not canonically ordered"
        if request.paths and any(path not in request.paths for path in paths):
            return "source diff contains an unrequested path"
        if any(not source_diff_entry_is_canonical(entry) for entry in result.entries):
            return "source diff entry rendering is not canonical"
        rendered = "\n".join(entry.diff for entry in result.entries)
    elif isinstance(result, SourcePathListing):
        rendered = "\n".join(render_source_path(path) for path in result.paths)
        if request.limit is not None and len(result.paths) > request.limit:
            return "source listing exceeded its caller limit"
    else:
        paths = tuple(file.path for file in result.files)
        if paths != request.paths[: len(paths)]:
            return "source read does not preserve requested path order"
        if result.truncated != (len(paths) < len(request.paths)):
            return "source read has an invalid truncation claim"
        rendered = "\n".join(render_source_file(file) for file in result.files)
    if result.rendered != rendered:
        return "source experience rendering is not canonical"
    return None


__all__ = [
    "SOURCE_OPERATIONS",
    "SOURCE_READ_OPERATIONS",
    "build_source_diff_result",
    "build_source_result",
    "execute_source_request",
    "render_source_file",
    "render_source_path",
    "source_success_violation",
    "visible_source_occurrence",
]
