"""Pure canonical source-tree diff rendering and bounded construction."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, replace

from meta_evolve.domain import (
    ExperienceRequest,
    ExperienceUsage,
    SourceDiff,
    SourceDiffEntry,
    SourceTree,
)
from meta_evolve.errors import ExperienceBudgetExhausted

from .source_resolution import ResolvedSourceTree


_HUNK = re.compile(r"@@ -(\d+),(\d+) \+(\d+),(\d+) @@")
_NO_NEWLINE = r"\ No newline at end of file"


@dataclass(frozen=True, slots=True)
class _Line:
    text: str
    terminated: bool


@dataclass(frozen=True, slots=True)
class _Edit:
    kind: str
    line: _Line


def _lines(source: str) -> tuple[_Line, ...]:
    normalized = source.replace("\r\n", "\n").replace("\r", "\n")
    if not normalized:
        return ()
    parts = normalized.split("\n")
    if normalized.endswith("\n"):
        return tuple(_Line(part, True) for part in parts[:-1])
    return tuple(
        _Line(part, index < len(parts) - 1)
        for index, part in enumerate(parts)
    )


def _myers(older: tuple[_Line, ...], newer: tuple[_Line, ...]) -> tuple[_Edit, ...]:
    """Return one shortest edit script, preferring deletion at every tie."""

    n, m = len(older), len(newer)
    frontier = {1: 0}
    trace: list[dict[int, int]] = []
    for distance in range(n + m + 1):
        current: dict[int, int] = {}
        for diagonal in range(-distance, distance + 1, 2):
            if diagonal == -distance or (
                diagonal != distance
                and frontier.get(diagonal - 1, -1)
                < frontier.get(diagonal + 1, -1)
            ):
                x = frontier.get(diagonal + 1, 0)
            else:
                x = frontier.get(diagonal - 1, 0) + 1
            y = x - diagonal
            while x < n and y < m and older[x] == newer[y]:
                x += 1
                y += 1
            current[diagonal] = x
            if x >= n and y >= m:
                trace.append(current)
                return _backtrack(older, newer, trace)
        trace.append(current)
        frontier = current
    raise AssertionError("Myers diff did not reach the terminal coordinate")


def _backtrack(older, newer, trace) -> tuple[_Edit, ...]:
    x, y = len(older), len(newer)
    reversed_edits: list[_Edit] = []
    for distance in range(len(trace) - 1, 0, -1):
        prior = trace[distance - 1]
        diagonal = x - y
        if diagonal == -distance or (
            diagonal != distance
            and prior.get(diagonal - 1, -1) < prior.get(diagonal + 1, -1)
        ):
            previous_diagonal = diagonal + 1
            edit = "insert"
        else:
            previous_diagonal = diagonal - 1
            edit = "delete"
        previous_x = prior[previous_diagonal]
        previous_y = previous_x - previous_diagonal
        while x > previous_x and y > previous_y:
            reversed_edits.append(_Edit("equal", older[x - 1]))
            x -= 1
            y -= 1
        if edit == "delete":
            reversed_edits.append(_Edit("delete", older[x - 1]))
            x -= 1
        else:
            reversed_edits.append(_Edit("insert", newer[y - 1]))
            y -= 1
    while x > 0 and y > 0:
        reversed_edits.append(_Edit("equal", older[x - 1]))
        x -= 1
        y -= 1
    while x > 0:
        reversed_edits.append(_Edit("delete", older[x - 1]))
        x -= 1
    while y > 0:
        reversed_edits.append(_Edit("insert", newer[y - 1]))
        y -= 1
    return tuple(reversed(reversed_edits))


def _hunk_spans(edits: tuple[_Edit, ...]) -> tuple[tuple[int, int], ...]:
    changes = tuple(index for index, edit in enumerate(edits) if edit.kind != "equal")
    if not changes:
        return ()
    spans: list[tuple[int, int]] = []
    for index in changes:
        start, end = max(0, index - 3), min(len(edits), index + 4)
        if spans and start <= spans[-1][1]:
            spans[-1] = (spans[-1][0], max(spans[-1][1], end))
        else:
            spans.append((start, end))
    return tuple(spans)


def _range(start: int, count: int) -> tuple[int, int]:
    return (start if count else start - 1, count)


def _render_hunks(edits: tuple[_Edit, ...]) -> tuple[str, ...]:
    old_at, new_at = 1, 1
    positions = []
    for edit in edits:
        positions.append((old_at, new_at))
        old_at += edit.kind != "insert"
        new_at += edit.kind != "delete"
    rendered = []
    for start, end in _hunk_spans(edits):
        hunk = edits[start:end]
        old_count = sum(edit.kind != "insert" for edit in hunk)
        new_count = sum(edit.kind != "delete" for edit in hunk)
        old_range = _range(positions[start][0], old_count)
        new_range = _range(positions[start][1], new_count)
        rendered.append(
            f"@@ -{old_range[0]},{old_range[1]} "
            f"+{new_range[0]},{new_range[1]} @@"
        )
        for edit in hunk:
            prefix = {"equal": " ", "delete": "-", "insert": "+"}[edit.kind]
            rendered.append(prefix + edit.line.text)
            if not edit.line.terminated:
                rendered.append(_NO_NEWLINE)
    return tuple(rendered)


def _operand(side: str, path: str) -> str:
    return json.dumps(f"{side}/{path}", ensure_ascii=False, separators=(",", ":"))


def render_source_diff_entry(
    path: str, older: str | None, newer: str | None
) -> SourceDiffEntry | None:
    """Render one changed path, or return ``None`` when it is unchanged."""

    if older is None:
        status = "added"
    elif newer is None:
        status = "deleted"
    elif _lines(older) != _lines(newer):
        status = "modified"
    else:
        return None
    old_operand = "/dev/null" if status == "added" else _operand("a", path)
    new_operand = "/dev/null" if status == "deleted" else _operand("b", path)
    edits = _myers(_lines(older or ""), _lines(newer or ""))
    diff = "\n".join((f"--- {old_operand}", f"+++ {new_operand}", *_render_hunks(edits)))
    return SourceDiffEntry(path=path, status=status, diff=diff)


def render_source_diff(
    older: SourceTree, newer: SourceTree, paths: tuple[str, ...] = ()
) -> tuple[SourceDiffEntry, ...]:
    """Render the sorted changed-path union, optionally filtered by path."""

    requested = set(paths) if paths else None
    entries = []
    for path in sorted(set(older) | set(newer)):
        if requested is not None and path not in requested:
            continue
        entry = render_source_diff_entry(
            path,
            older[path] if path in older else None,
            newer[path] if path in newer else None,
        )
        if entry is not None:
            entries.append(entry)
    return tuple(entries)


def build_source_diff_result(
    older: ResolvedSourceTree,
    newer: ResolvedSourceTree,
    request: ExperienceRequest,
    before: ExperienceUsage,
    *,
    max_results: int,
    max_records: int,
    max_chars: int,
) -> SourceDiff:
    """Build the largest complete canonical prefix after reserving two results."""

    if before.results + 2 > max_results:
        raise ExperienceBudgetExhausted()
    complete = render_source_diff(older.tree, newer.tree, request.paths)
    retained = []
    rendered = ""
    record_capacity = max(0, max_records - before.records)
    char_capacity = max(0, max_chars - before.chars)
    for entry in complete[:record_capacity]:
        candidate = entry.diff if not retained else f"{rendered}\n{entry.diff}"
        if len(candidate) > char_capacity:
            break
        retained.append(entry)
        rendered = candidate
    usage = replace(
        before,
        results=before.results + 2,
        records=before.records + len(retained),
        chars=before.chars + len(rendered),
    )
    return SourceDiff(
        older_artifact_ref=request.ref,
        newer_artifact_ref=request.other_ref,
        older_digest=older.digest,
        newer_digest=newer.digest,
        entries=tuple(retained),
        rendered=rendered,
        truncated=len(retained) < len(complete),
        usage=usage,
    )


def source_diff_entry_is_canonical(entry: SourceDiffEntry) -> bool:
    """Validate self-contained syntax available to event-only replay."""

    lines = entry.diff.split("\n")
    old = "/dev/null" if entry.status == "added" else _operand("a", entry.path)
    new = "/dev/null" if entry.status == "deleted" else _operand("b", entry.path)
    if entry.diff.endswith("\n") or lines[:2] != [f"--- {old}", f"+++ {new}"]:
        return False
    cursor = 2
    if cursor == len(lines):
        return entry.status in {"added", "deleted"}
    while cursor < len(lines):
        match = _HUNK.fullmatch(lines[cursor])
        if match is None:
            return False
        old_count, new_count = int(match[2]), int(match[4])
        cursor += 1
        seen_old = seen_new = 0
        while cursor < len(lines) and not lines[cursor].startswith("@@ "):
            line = lines[cursor]
            if line == _NO_NEWLINE:
                if cursor == 0 or lines[cursor - 1][:1] not in {" ", "-", "+"}:
                    return False
            elif line.startswith(" "):
                seen_old += 1
                seen_new += 1
            elif line.startswith("-"):
                seen_old += 1
            elif line.startswith("+"):
                seen_new += 1
            else:
                return False
            cursor += 1
        if (seen_old, seen_new) != (old_count, new_count):
            return False
    return True


__all__ = [
    "build_source_diff_result",
    "render_source_diff",
    "render_source_diff_entry",
    "source_diff_entry_is_canonical",
]
