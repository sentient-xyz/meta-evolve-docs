"""A transparent search-program wrapper that stamps context authority."""

from __future__ import annotations

from dataclasses import replace

from meta_evolve.domain import PolicyRef, SearchDecision, SearchProgram, SearchState
from meta_evolve.domain.trial import TrialSpec


class ContextSearchProgram:
    def __init__(self, program: SearchProgram, policy: PolicyRef) -> None:
        self._program = program
        self._policy = policy

    def next(self, state: SearchState) -> SearchDecision:
        decision = self._program.next(state)
        if isinstance(decision, TrialSpec):
            return replace(decision, context_policy=self._policy)
        return decision

    def __getattr__(self, name: str):
        return getattr(self._program, name)


__all__ = ["ContextSearchProgram"]
