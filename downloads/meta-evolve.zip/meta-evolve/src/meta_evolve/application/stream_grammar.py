"""Shared incremental and full-history validation of batch ordering.

Batch shapes belong to ``batch_grammar``; budgets, authority and provenance
belong to the event fold. This state records only which results/evaluations
remain structurally possible. Preparing an advance never changes committed
state, and accepting it touches only that batch's trials and pending work.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

from meta_evolve.domain import (
    ArchiveUpdate,
    BootstrapPrepared,
    EvaluationCompleted,
    EvidenceRecorded,
    PolicyDecisionMade,
    ProposalSubmitted,
    Stop,
    TrialId,
    TrialSpec,
)
from meta_evolve.errors import DurableCorruption

from .batch_grammar import (
    consume_cohort,
    consume_evaluation,
    consume_genesis,
    consume_result,
    is_m3_fact,
)


@dataclass(frozen=True, slots=True)
class _Advance:
    """A validated batch's changes, independent of the size of prior history."""

    start: int
    end: int
    known: tuple[TrialId, ...] = ()
    pending: tuple[TrialId, ...] = ()
    completed: TrialId | None = None
    succeeded: TrialId | None = None
    evaluated: TrialId | None = None
    close_evaluations: bool = False
    stopped: bool = False
    trial_tail: bool = False


class StreamGrammar:
    """Ephemeral grammar state for one validated committed prefix.

    ``prepare`` reads one complete batch from a sequence; ``accept`` installs
    the prepared changes after commitment. Full-history reads use the same two
    operations on a fresh state. This is not a durable record or authority to
    skip validation when reopening storage.
    """

    def __init__(self) -> None:
        self.position = 0
        self._known: set[TrialId] = set()
        self._pending_results: set[TrialId] = set()
        self._pending_evaluations: set[TrialId] = set()
        self._stopped = False
        self._trial_tail = False

    @classmethod
    def from_history(cls, bodies: Sequence[object]) -> StreamGrammar:
        state = cls()
        index = 0
        while index < len(bodies):
            advance = state.prepare(bodies, index)
            state.accept(advance)
            index = advance.end
        return state

    def prepare(self, bodies: Sequence[object], start: int = 0) -> _Advance:
        """Validate the next batch without mutating this prefix's state.

        Adjacent trial decisions remain one cohort across write boundaries:
        the persisted stream has no delimiters to distinguish separate writes.
        """

        head = bodies[start] if start < len(bodies) else None
        if self._stopped:
            raise DurableCorruption(
                f"a committed Stop decision cannot be followed by "
                f"{type(head).__name__} at event {self.position}"
            )
        if self.position == 0:
            end = consume_genesis(bodies, start)
            prepared = bodies[start + 1]
            assert isinstance(prepared, BootstrapPrepared)
            evaluated = any(
                isinstance(body, EvaluationCompleted) for body in bodies[start:end]
            )
            return _Advance(
                start, end, known=(prepared.trial.id,),
                succeeded=None if evaluated else prepared.trial.id,
            )
        if is_m3_fact(head):
            return _Advance(start, start + 1)
        if isinstance(head, PolicyDecisionMade):
            decisions, end = consume_cohort(bodies, start)
            if self._trial_tail and not all(
                isinstance(decision, TrialSpec) for decision in decisions
            ):
                raise DurableCorruption(
                    "a decision batch above one member must be all trial decisions; "
                    f"a non-trial decision follows a trial at event {self.position}"
                )
            trial_ids: list[TrialId] = []
            added: set[TrialId] = set()
            for record in bodies[start:end:2]:
                assert isinstance(record, PolicyDecisionMade)
                if isinstance(record.decision, TrialSpec):
                    trial_id = record.trial_id
                    assert trial_id is not None
                    if trial_id in self._known or trial_id in added:
                        raise DurableCorruption(
                            f"trial {trial_id.value} was already decided "
                            f"at event {self.position}"
                        )
                    added.add(trial_id)
                    trial_ids.append(trial_id)
                elif not isinstance(record.decision, (Stop, ArchiveUpdate)):
                    raise DurableCorruption(
                        f"unsupported decision {type(record.decision).__name__} "
                        f"at event {self.position} in stream"
                    )
            return _Advance(
                start, end, known=tuple(trial_ids), pending=tuple(trial_ids),
                close_evaluations=not self._trial_tail,
                stopped=isinstance(decisions[-1], Stop),
                trial_tail=isinstance(decisions[-1], TrialSpec),
            )
        if isinstance(head, ProposalSubmitted):
            trial_id, succeeded, end = consume_result(bodies, start)
            if trial_id not in self._known:
                raise DurableCorruption(
                    f"result batch at event {self.position} belongs to undecided "
                    f"trial {trial_id.value}"
                )
            if trial_id not in self._pending_results:
                raise DurableCorruption(
                    f"trial {trial_id.value} already completed before the "
                    f"result batch at event {self.position}"
                )
            return _Advance(
                start, end, completed=trial_id,
                succeeded=trial_id if succeeded else None,
            )
        if isinstance(head, (EvidenceRecorded, EvaluationCompleted)):
            trial_id, end = consume_evaluation(bodies, start)
            if trial_id not in self._pending_evaluations:
                raise DurableCorruption(
                    f"evaluation batch at event {self.position} is not owed: trial "
                    f"{trial_id.value} has no successful, unevaluated result"
                )
            return _Advance(start, end, evaluated=trial_id)
        raise DurableCorruption(
            f"unexpected {type(head).__name__} at event {self.position}: a batch "
            "must open a decision, a result, or an evaluation"
        )

    def accept(self, advance: _Advance) -> None:
        """Install a prepared batch; no validation or historical walk occurs here."""

        self._known.update(advance.known)
        self._pending_results.update(advance.pending)
        if advance.close_evaluations:
            # A newer generation closes skipped evaluations. Only pending
            # work is visited; completed trials never need to be walked again.
            self._pending_evaluations.clear()
        if advance.completed is not None:
            self._pending_results.remove(advance.completed)
        if advance.succeeded is not None:
            self._pending_evaluations.add(advance.succeeded)
        if advance.evaluated is not None:
            self._pending_evaluations.remove(advance.evaluated)
        self._stopped = advance.stopped
        self._trial_tail = advance.trial_tail
        self.position += advance.end - advance.start


def scan_batch_grammar(bodies: Sequence[object]) -> None:
    """Validate a complete ordered history, including malformed/incomplete tails."""

    StreamGrammar.from_history(bodies)


__all__ = ["scan_batch_grammar"]
