"""What the dispatch loop requires of a backend, and nothing more.

One protocol, two implementations: the inline helper thread
(`inline_backend.py`) and one worker connection (`distributed/wire.py`). It is
declared in `application/`, never in `distributed/`, because the loop owns the
contract and the transport implements it -- the application layer imports
nothing from the transport (design SD5).

Its own module so that admission (`dispatch_admission.py`) can name an
endpoint without importing the loop that consumes one, and so that the binding
and the settle path can name it without importing the loop either.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Protocol

from meta_evolve.domain.workers import WorkerRegistration

from .dispatch_messages import Message, Submission, Work


class Endpoint(Protocol):
    """One backend, as the loop sees it."""

    #: False inline, where a stale submission RAISES; True on the wire, where it
    #: is answered.
    answers_submissions: bool

    #: The identities a claim for this endpoint is made under, in order.
    registrations: tuple[WorkerRegistration, ...]

    def fileno(self) -> int: ...

    def wants_work(self, bound: int) -> bool: ...

    def alive(self, clock: Callable[[], int], window: int) -> bool: ...

    def silent_for(self, clock: Callable[[], int]) -> int | None: ...

    #: The reason this endpoint said it was leaving, or None. ASKED rather than
    #: read off the stream: after a farewell the connection has no more
    #: readable bytes to wake the selector with (design PD6).
    def departed(self) -> str | None: ...

    def start(self, work: Work) -> None: ...

    #: Only OUTCOMES: a pull, a heartbeat or a farewell is applied by the
    #: endpoint itself and never handed up, which is what lets the loop settle
    #: every message it drains without asking what kind it is.
    def receive(self, clock: Callable[[], int]) -> tuple[Submission, ...]: ...

    def send(self, message: Message) -> None: ...

    def wants_write(self) -> bool: ...

    def flush(self) -> None: ...

    def retire(self) -> None: ...

    def close(self) -> None: ...


__all__ = ["Endpoint"]
