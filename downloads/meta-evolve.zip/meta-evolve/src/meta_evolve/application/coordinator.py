"""Synchronous coordinator for bootstrap, policy decisions, and event writes."""

from __future__ import annotations

from collections.abc import Sequence

from meta_evolve.domain.values import FrozenValue
from meta_evolve.domain.work import DEFAULT_LEASE_SECONDS
from meta_evolve.ports.work_store import WorkBroker, WorkIntent
from meta_evolve.ports.worker_registry import TrustedWorkerReader
from meta_evolve.domain import (
    Artifact,
    Budget,
    ComponentRef,
    ContextSpec,
    CorrelationId,
    EventEnvelope,
    ExperienceSpec,
    LEGACY_LOCAL_CAPABILITIES,
    RunCapabilities,
    RunId,
    SearchDecision,
    SearchProgram,
    SearchSpec,
    Task,
    TaskId,
    Trial,
    TrialOutcome,
)
from meta_evolve.ports.callables import Evaluator
from meta_evolve.ports.runners import ProposerRunner

from meta_evolve.errors import DurableCorruption, RunError
from .batch_grammar import recognized_batch_shape
from .bootstrap import start_run
from .codecs import CodecIndex
from .decisions import CommittedDecision, commit_decision
from .fencing import Fence
from .context_selection import (
    ContextSelector,
    declare_context,
    select_or_load_context,
)
from .execution import execute_trial
from .experience_reader import declare_experience, issue_or_load_reader
from .batch_envelopes import batch_envelopes
from .identities import correlation_for_trial
from .projections import RunProjection
from .stream_grammar import StreamGrammar
from .proposal_completion import resume_completed_trial
from .storage import Storage
from .committed_fold import fold_committed

class SequentialCoordinator:
    def __init__(
        self,
        *,
        run_id: RunId,
        task_id: TaskId,
        task: Task,
        run_budget: Budget,
        random_seed: int,
        search: SearchSpec,
        proposer_runner: ProposerRunner,
        proposer_ref: ComponentRef,
        evaluator: Evaluator,
        storage: Storage,
        codecs: CodecIndex,
        capabilities: RunCapabilities = LEGACY_LOCAL_CAPABILITIES,
        projection: RunProjection | None = None,
        committed_bodies: Sequence[object] | None = None,
        context_selector: ContextSelector | None = None,
        experience_spec: ExperienceSpec | None = None,
    ) -> None:
        self.run_id = run_id
        self.task_id = task_id
        self.task = task
        self.run_budget = run_budget
        self.random_seed = random_seed
        self.search = search
        self.proposer_runner = proposer_runner
        self.proposer_ref = proposer_ref
        self.evaluator = evaluator
        self._storage = storage
        self.fence = Fence()  # installed only by whoever ran `rollover`
        # Evaluation resolves codecs without coordinator branches on artifact types.
        self.codecs = codecs
        self.artifacts = storage.artifacts
        self.events = storage.events
        self.capabilities = capabilities
        self.context_selector = context_selector
        self.experience_spec = experience_spec
        if projection is not None and projection.run_id != run_id:
            # apply_event does not re-check envelope.run_id against the
            # projection's run_id (that guard lives only in
            # replay_run_projection), so a foreign-run seed would silently
            # fold this run's envelopes onto the wrong state.
            raise RunError("seeded projection belongs to another run")
        self._projection = (
            projection if projection is not None else RunProjection.empty(run_id)
        )
        # A resumed prefix is validated once, on the first write. Construction
        # alone must not bypass Session's capability/readiness refusal boundary.
        self._grammar: StreamGrammar | None = None
        if committed_bodies is not None:
            self._grammar_prefix: Sequence[object] = tuple(committed_bodies)
        elif self._projection.version > 0:
            self._grammar_prefix = tuple(
                event.body for event in storage.events.read(run_id)
            )
        else:
            self._grammar_prefix = ()

    @property
    def projection(self) -> RunProjection:
        return self._projection

    def work_broker(self, *, lease_seconds: int = DEFAULT_LEASE_SECONDS) -> WorkBroker:
        """This run's work broker, from the storage it was built with.

        Here rather than at the caller so nothing reaches through
        `coordinator._storage` -- a walk across two objects and one private
        field to ask a question the coordinator can answer itself. `Storage`
        decides whether it HAS a broker; this only says which storage to ask.
        """

        return self._storage.work_broker(lease_seconds=lease_seconds)

    def trusted_workers(self) -> TrustedWorkerReader:
        """Return the live enrolment reader from this run's store."""

        return self._storage.trusted_workers()

    def commit_batch(
        self,
        bodies: Sequence[object],
        *,
        occurrences: Sequence[Artifact] = (),
        correlation: CorrelationId,
        work: Sequence[WorkIntent] = (),
    ) -> RunProjection:
        """Atomically commit ``bodies`` as one contiguous event batch.

        The whole batch is preflight-folded on a local copy *before* any
        write, sharing the ``fold_committed`` step with
        ``replay_run_projection`` so the projection-equals-replay invariant
        cannot drift. It does not re-run replay's structural pre-checks
        (envelope type, run scope, sequence contiguity): the envelopes are
        constructed here and satisfy those by construction. A structurally
        invalid *batch* (e.g. a body ``apply_event`` rejects) raises
        ``InvalidSearchHistory`` and nothing is written. Only after the store
        commit succeeds is the incremental in-memory projection advanced; an
        ``EventStreamConflict`` (or any other commit failure) propagates with
        ``self._projection`` untouched.
        """

        if not bodies:
            raise ValueError("commit_batch requires at least one event body")

        pre = self._projection
        # The stream is contiguous, so ``version == len(stream)`` and
        # ``pre_version`` is exactly the ``expected_version`` the store wants.
        pre_version = pre.version

        envelopes = batch_envelopes(self.run_id, bodies, correlation, pre)

        # Preflight fold — share the fold step with replay_run_projection, on a
        # local copy, before any write, so an invalid batch leaves storage
        # untouched.
        folded = pre
        for envelope in envelopes:
            folded = fold_committed(folded, envelope)

        # Grammar preflight — the fold validates per-event semantics but NOT the
        # batch SHAPE, so a lone PolicyDecisionMade(Stop) (no explanation) would
        # fold cleanly yet be declared DurableCorruption by resume's recovery
        # grammar, violating "committed ⟹ recoverable". Reject any batch that is
        # not exactly one recognized coordinator batch (or a single M3 fact)
        # here, BEFORE persisting, using the SAME shape matchers recovery uses.
        new_bodies = [envelope.body for envelope in envelopes]
        if recognized_batch_shape(new_bodies) is None:
            raise ValueError(
                "commit_batch rejects a batch the recovery grammar would "
                "reject: bodies must form exactly one recognized coordinator "
                "batch (genesis / decision / result / evaluation) or a single "
                "M3 fact"
            )

        # Reuse the validated prefix; preparing a batch changes no committed
        # grammar state. Full-history readers apply these same transition rules.
        if self._grammar is None:
            grammar = StreamGrammar.from_history(self._grammar_prefix)
            if grammar.position != pre_version:
                raise DurableCorruption("grammar prefix does not match projection version")
            self._grammar = grammar
            self._grammar_prefix = ()
        advance = self._grammar.prepare(new_bodies)

        # A store failure (EventStreamConflict or otherwise) propagates here,
        # leaving self._projection untouched; mode-specific handling lives at
        # the call sites (CP-3), not in this method.
        # `work` rides the SAME transaction as the events that authorise it:
        # the record requires enqueue to insert work rows "in the same
        # transaction as the decision cohort or genesis", and this is the only
        # place both are in scope -- which is also why the fence is here.
        new_version = self._storage.commit(
            self.run_id,
            pre_version,
            events=tuple(envelopes),
            occurrences=tuple(occurrences),
            work=self.fence.guard(work),
        )
        # Contiguity invariant: the committed stream length must equal the
        # projected version. A mismatch is a real store/projection divergence,
        # not an assertion (which -O would strip).
        if new_version != folded.version:
            raise DurableCorruption(
                f"committed stream length {new_version} does not match "
                f"projected version {folded.version}"
            )
        self._grammar.accept(advance)
        self._projection = folded
        return folded

    def read_events(self) -> tuple[EventEnvelope, ...]:
        return self.events.read(self.run_id)

    def start(
        self,
        seed: FrozenValue,
        *,
        context_spec: ContextSpec | None = None,
        experience_spec: ExperienceSpec | None = None,
    ) -> None:
        start_run(
            self,
            seed,
            context_spec=context_spec,
            experience_spec=experience_spec,
        )

    def record_decision(
        self, program: SearchProgram, decision: SearchDecision
    ) -> CommittedDecision:
        return commit_decision(self, program, decision)

    def declare_context(self, spec: ContextSpec | None) -> None:
        declare_context(self, spec)

    def declare_experience(self, spec: ExperienceSpec | None) -> None:
        declare_experience(self, spec)

    def execute(self, trial: Trial) -> TrialOutcome:
        bundle = select_or_load_context(self, trial, self.context_selector)
        reader = issue_or_load_reader(self, trial, self.experience_spec)
        return execute_trial(self, trial, bundle, reader)

    def resume_completed_trial(self, trial: Trial) -> TrialOutcome:
        """Finish an authorized pending evaluation with its original correlation.

        Require a committed trial, then share completion's disposition and
        idempotency checks. The proposer and proposal commit are never repeated.
        """

        existing = self._projection.completed_trial(trial.id)
        if existing is None:
            raise DurableCorruption(
                f"cannot resume evaluation of uncommitted trial {trial.id}"
            )
        correlation = correlation_for_trial(trial.id)
        return resume_completed_trial(self, trial, existing, correlation)


__all__ = ["SequentialCoordinator"]
