"""Replay validation for pull declarations, grants, and audit charging.

Successes are validated against committed source records and the shared
deterministic contract only; replay never re-runs live selection, traversal,
filtering, or comparison logic.
"""

from __future__ import annotations

from dataclasses import replace

from meta_evolve.domain import (
    ExperienceAccessDeclared,
    CorrelationId,
    ExperienceGrantIssued,
    ExperienceOperationAttempted,
    ExperienceOperationBudgetExhausted,
    ExperienceOperationDenied,
    ExperienceOperationId,
    ExperienceOperationSucceeded,
    ExperienceUsage,
    TrialSpec,
)
from meta_evolve.domain.search import InvalidSearchHistory

from .experience_contract import request_is_malformed, success_violation
from .identities import correlation_for_run, correlation_for_trial, stable_id
from .run_projection import RunProjection
from .source_operations import SOURCE_OPERATIONS, visible_source_occurrence


def _invalid(sequence: int, reason: str) -> InvalidSearchHistory:
    return InvalidSearchHistory(
        f"invalid search history at sequence {sequence}: {reason}"
    )


def declare_access(
    state: RunProjection,
    body: ExperienceAccessDeclared,
    sequence: int,
    correlation: CorrelationId,
) -> RunProjection:
    if not state.ready:
        raise _invalid(sequence, "bootstrap evaluation must precede experience access")
    if state.experience_declaration is not None:
        raise _invalid(sequence, "experience access was already declared")
    if state.decisions:
        raise _invalid(sequence, "experience access must precede policy decisions")
    expected = correlation_for_run(state.run_id)
    if correlation != expected:
        raise _invalid(sequence, "experience declaration has invalid authority")
    return replace(state, version=sequence, experience_declaration=body)


def issue_grant(
    state: RunProjection,
    body: ExperienceGrantIssued,
    sequence: int,
    correlation: CorrelationId,
) -> RunProjection:
    declaration = state.experience_declaration
    grant = body.grant
    decision = next(
        (item for item in state.decisions if item.trial_id == grant.trial_id), None
    )
    if declaration is None:
        raise _invalid(sequence, "experience grant has no access declaration")
    if decision is None or not isinstance(decision.decision, TrialSpec):
        raise _invalid(sequence, "experience grant has no trial decision")
    if state.grant_for(grant.trial_id) is not None:
        raise _invalid(sequence, "trial experience grant was already issued")
    if (
        grant.run_id != state.run_id
        or state.start is None
        or grant.task_id != state.start.task_id
        or grant.spec != declaration.spec
        or grant.as_of != decision.logical_step - 1
    ):
        raise _invalid(sequence, "experience grant exceeds or mismatches authority")
    expected = correlation_for_trial(grant.trial_id)
    if correlation != expected:
        raise _invalid(sequence, "experience grant has invalid authority")
    explanation = state.explanation_for(decision.decision_id)
    if explanation is None:
        raise _invalid(sequence, "experience grant requires a decision explanation")
    selected = state.selection_for(grant.trial_id)
    requires_context = decision.decision.context_policy is not None
    if requires_context != (selected is not None):
        raise _invalid(sequence, "experience grant has invalid context placement")
    if requires_context:
        if state.version != selected.observed_version + 1:
            raise _invalid(sequence, "experience grant must follow context selection")
    elif state.version != decision.observed_version + 2:
        raise _invalid(sequence, "experience grant must follow decision explanation")
    return replace(
        state,
        version=sequence,
        experience_grants=state.experience_grants + (body,),
        experience_cursor_version=sequence,
    )


def attempt_operation(
    state: RunProjection,
    body: ExperienceOperationAttempted,
    sequence: int,
    correlation: CorrelationId,
) -> RunProjection:
    grant = state.grant_for(body.trial_id)
    if grant is None:
        raise _invalid(sequence, "experience operation has no grant")
    if state.proposal_for(body.trial_id) is not None:
        raise _invalid(sequence, "experience operation cannot follow its proposal")
    expected_correlation = correlation_for_trial(body.trial_id)
    if correlation != expected_correlation:
        raise _invalid(sequence, "experience operation has invalid authority")
    prior = state.operations_for(body.trial_id)
    if prior and prior[-1][1] is None:
        raise _invalid(sequence, "experience operation has an unresolved predecessor")
    expected_ordinal = len(prior) + 1
    expected_id = stable_id(
        ExperienceOperationId,
        "experience-operation",
        body.trial_id.value,
        expected_ordinal,
    )
    if body.operation_id != expected_id:
        raise _invalid(sequence, "experience operation identity is not reproducible")
    previous = _previous_usage(prior)
    expected_usage = replace(previous, operations=previous.operations + 1)
    if body.usage != expected_usage:
        raise _invalid(sequence, "experience attempt usage is not cumulative")
    return replace(
        state,
        version=sequence,
        experience_attempts=state.experience_attempts + (body,),
        experience_cursor_version=sequence,
    )


def resolve_operation(
    state: RunProjection,
    body: (
        ExperienceOperationSucceeded
        | ExperienceOperationDenied
        | ExperienceOperationBudgetExhausted
    ),
    sequence: int,
    correlation: CorrelationId,
) -> RunProjection:
    attempt = state.experience_attempts[-1] if state.experience_attempts else None
    if (
        attempt is None
        or state.resolution_for(attempt.operation_id) is not None
        or body.operation_id != attempt.operation_id
        or body.trial_id != attempt.trial_id
    ):
        raise _invalid(sequence, "experience resolution has no matching attempt")
    grant = state.grant_for(body.trial_id)
    assert grant is not None
    expected_correlation = correlation_for_trial(body.trial_id)
    if correlation != expected_correlation:
        raise _invalid(sequence, "experience resolution has invalid authority")
    over_ceiling = attempt.usage.operations > grant.spec.max_operations
    result_ceiling = _result_ceiling_exhausted(state, grant, attempt)
    if isinstance(body, ExperienceOperationBudgetExhausted):
        if not (over_ceiling or result_ceiling) or body.usage != attempt.usage:
            raise _invalid(sequence, "experience exhaustion does not match its attempt")
        return replace(
            state,
            version=sequence,
            experience_exhaustions=state.experience_exhaustions + (body,),
            experience_cursor_version=sequence,
        )
    if over_ceiling:
        raise _invalid(sequence, "over-ceiling experience attempt must be exhausted")
    if isinstance(body, ExperienceOperationDenied):
        if body.usage != attempt.usage:
            raise _invalid(sequence, "experience denial consumed protected capacity")
        return replace(
            state,
            version=sequence,
            experience_denials=state.experience_denials + (body,),
            experience_cursor_version=sequence,
        )
    violation = success_violation(state, grant, attempt, body.result)
    if violation is not None:
        raise _invalid(sequence, violation)
    return replace(
        state,
        version=sequence,
        experience_successes=state.experience_successes + (body,),
        experience_cursor_version=sequence,
    )


def _result_ceiling_exhausted(state, grant, attempt) -> bool:
    request = attempt.request
    return (
        request.operation in SOURCE_OPERATIONS
        and not request_is_malformed(request)
        and (request.as_of is None or request.as_of <= grant.as_of)
        and visible_source_occurrence(state, grant, request) is not None
        and (
            request.operation != "diff_source"
            or visible_source_occurrence(
                state, grant, request, ref=request.other_ref
            ) is not None
        )
        and attempt.usage.results
        + (2 if request.operation == "diff_source" else 1)
        > grant.spec.max_results
    )


def _previous_usage(prior: tuple[tuple[object, object], ...]) -> ExperienceUsage:
    if not prior:
        return ExperienceUsage()
    resolution = prior[-1][1]
    assert resolution is not None
    return resolution.result.usage if isinstance(
        resolution, ExperienceOperationSucceeded
    ) else resolution.usage


__all__ = [
    "attempt_operation",
    "declare_access",
    "issue_grant",
    "resolve_operation",
]
