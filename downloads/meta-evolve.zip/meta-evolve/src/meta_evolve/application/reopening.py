"""Select and inspect a saved run with explicit storage ownership."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import TYPE_CHECKING

from meta_evolve.domain import RunId
from meta_evolve.errors import RunNotFound, RunSelectionRequired

from .durable_loading import load_validated_run
from .results import Run
from .storage import Storage

if TYPE_CHECKING:
    from meta_evolve.registry import Registry


@contextmanager
def open_run(
    path: str | Path,
    *,
    run_id: RunId | str | None = None,
    registry: Registry | None = None,
) -> Iterator[Run]:
    """Open a saved run for inspection within a ``with`` block.

    Without an ID, select the only run in the store. With several runs, pass
    ``run_id=...`` explicitly; lexical ID order does not establish recency.
    Context entry validates the selected history before yielding the existing
    [Run][meta_evolve.Run] type, including incomplete or unsuccessful runs.

    Validation and I/O start on context entry. The owned read-only storage
    closes on normal exit or error. Capture ``summary()`` or ``inspect()``
    inside the block to use a detached result afterward; later queries on the
    live Run still require open storage. Queries can observe new WAL commits.
    Reopening never resumes work, migrates a schema, or creates a missing store.
    SQLite may maintain WAL sidecars without changing committed history.

    :param path: Existing directory originally passed to ``Storage.durable``.
    :param run_id: Saved RunId or nonempty ID string without outer whitespace;
        ``None`` selects the only run. A missing explicit ID never falls back.
    :param registry: Optional reconstructed registry of custom artifact codecs.
        Needed by value-decoding queries, not by entry validation or ``usage()``.
    :returns: Context manager yielding a read-only Run backed by owned storage.
    :raises RunNotFound: The selected ID is missing, or the store contains no runs.
    :raises RunSelectionRequired: Multiple runs exist and no ID was supplied.
    :raises DurableStoreError: Storage is missing or inaccessible.
    :raises SchemaVersionRejected: The store schema requires migration or is unknown.
    :raises DurableCorruption: The schema or selected history is damaged.
    :raises TypeError: An ID or registry has the wrong type.
    :raises ValueError: An ID string is empty or has outer whitespace.
    """
    from meta_evolve.registry import Registry

    if isinstance(run_id, str):
        run_id = RunId(run_id)
    elif run_id is not None and not isinstance(run_id, RunId):
        raise TypeError("run_id must be a RunId, a string, or None")
    if registry is not None and not isinstance(registry, Registry):
        raise TypeError("registry must be a Registry")

    with Storage.read_only(path) as storage:
        if run_id is None:
            run_ids = storage.runs()
            if not run_ids:
                raise RunNotFound(f"no recorded runs in {path}; open a store containing a saved run")
            if len(run_ids) != 1:
                raise RunSelectionRequired(run_ids)
            run_id = run_ids[0]
        load_validated_run(storage, run_id, require_existing=True)
        yield Run(run_id, storage, registry=registry)


__all__ = ["open_run"]
