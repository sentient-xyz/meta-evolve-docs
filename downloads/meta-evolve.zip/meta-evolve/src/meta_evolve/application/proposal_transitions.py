"""Replay validation for successor proposal placement and authority."""

from __future__ import annotations

from dataclasses import replace

from meta_evolve.domain import ProposalSubmitted, TrialSpec
from meta_evolve.domain.search import InvalidSearchHistory

from .derivation import derivation_violation
from .run_projection import RunProjection


def _invalid(sequence: int, reason: str) -> InvalidSearchHistory:
    return InvalidSearchHistory(
        f"invalid search history at sequence {sequence}: {reason}"
    )


def submit_proposal(
    state: RunProjection, body: ProposalSubmitted, sequence: int
) -> RunProjection:
    proposal = body.proposal
    decision = next(
        (item for item in state.decisions if item.trial_id == proposal.trial_id),
        None,
    )
    if decision is None or not isinstance(decision.decision, TrialSpec):
        raise _invalid(sequence, "proposal has no committed trial decision")
    if state.completed_trial(proposal.trial_id) is not None:
        raise _invalid(sequence, "proposal cannot follow trial completion")
    if state.proposal_for(proposal.trial_id) is not None:
        raise _invalid(sequence, "trial already has a proposal")
    if (
        proposal.parent_ids != decision.decision.parent_ids
        or proposal.operator != decision.decision.operator
    ):
        raise _invalid(sequence, "proposal does not match its trial decision")
    requires_context = decision.decision.context_policy is not None
    requires_experience = state.experience_declaration is not None
    selected = state.selection_for(proposal.trial_id)
    if requires_context and selected is None:
        raise _invalid(sequence, "proposal requires a prior context selection")
    if not requires_context and selected is not None:
        raise _invalid(sequence, "default trial cannot have selected context")
    if (
        requires_context
        and not requires_experience
        and state.version != selected.observed_version + 1
    ):
        raise _invalid(sequence, "proposal must immediately follow its context selection")
    grant = state.grant_for(proposal.trial_id)
    if requires_experience and grant is None:
        raise _invalid(sequence, "proposal requires a prior experience grant")
    if not requires_experience and grant is not None:
        raise _invalid(sequence, "default trial cannot have an experience grant")
    if requires_experience and state.experience_cursor_version != state.version:
        raise _invalid(
            sequence,
            "proposal must immediately follow its experience operations",
        )
    violation = derivation_violation(state, proposal.trial_id, proposal.derived_from)
    if violation is not None:
        raise _invalid(sequence, violation)
    return replace(state, version=sequence, proposals=state.proposals + (body,))


__all__ = ["submit_proposal"]
