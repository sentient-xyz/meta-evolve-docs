"""Versioned deterministic identities for one local run.

Every derivation that more than one module needs lives here. The alternative,
which this module family has already paid for twice, is the same
`stable_id(...)` call spelled out at each site: the completion key was written
in four places plus a fifth in prose, and the per-trial correlation id in six.
A derivation with N homes is N places to notice when the domain string or the
part order changes -- and a mismatch is not a crash, it is two facts that
should have shared a key and silently do not.
"""

from __future__ import annotations

from hashlib import sha256
from typing import TypeVar

from meta_evolve.domain import CorrelationId, DecisionId, RunId, TrialId
from meta_evolve.domain.values import canonical_payload_bytes


_Id = TypeVar("_Id")


def stable_id(id_type: type[_Id], domain: str, *parts: object) -> _Id:
    digest = sha256(
        canonical_payload_bytes(
            {"domain": f"meta-evolve/{domain}/v1", "parts": tuple(parts)}
        )
    ).hexdigest()
    return id_type(f"{domain}-{digest}")


def completion_key_for(trial_id: TrialId) -> str:
    """The idempotency key a work item's completion is keyed by.

    The record defines it as stable from the work item and as an idempotency
    key, never a credential. It was derived at four call sites and described in
    prose at a fifth, and `check_completion_key` then recomputed it to compare
    against a value every in-repo caller had derived exactly this way.
    """

    return stable_id(DecisionId, "completion", trial_id.value).value


def correlation_for_trial(trial_id: TrialId) -> CorrelationId:
    """The correlation every fact about one trial shares. Six call sites."""

    return stable_id(CorrelationId, "correlation", trial_id.value)


def correlation_for_run(run_id: RunId) -> CorrelationId:
    """The correlation for facts about the run itself. Four call sites."""

    return stable_id(CorrelationId, "correlation", run_id.value)


def correlation_for_work(item_value: str) -> CorrelationId:
    """Keyed on the work ITEM, not the trial.

    The item is what the broker made at-most-once, so a redrive of the same
    item lands under the same correlation and a reader can tie the facts back
    to the unit of work that authorized them. Distinct from
    `correlation_for_trial` by the extra "work" part, which is exactly why both
    belong here rather than being spelled out and hoped to stay different.
    """

    return stable_id(CorrelationId, "correlation", "work", item_value)


__all__ = [
    "completion_key_for",
    "correlation_for_run",
    "correlation_for_trial",
    "correlation_for_work",
    "stable_id",
]
