"""Compatibility normalization for the public synchronous run call."""

from __future__ import annotations

from typing import overload

from meta_evolve.domain import Budget, SearchProgram, Task
from meta_evolve.errors import RunNotFound
from meta_evolve.policies.context import ContextPolicy
from meta_evolve.ports.experience import ExperienceAccess
from meta_evolve.registry import Registry

from .comparisons import RunComparison, RunSummary
from .experience_usage import RunExperienceUsage
from .experiment import Experiment, _UNSET, _normalize_experiment
from .inspection import (
    ArchiveDecisionView,
    DecisionView,
    RunDeclaration,
    RunInspection,
    RunOverview,
    StopDecisionView,
    TrialDecisionView,
)
from .results import ArtifactView, EvidenceView, Run, Storage, TrialView
from .resume import resume
from .run_support import ExecutionMode, ProposerLike
from .session import Session


@overload
def run(
    experiment: Experiment,
    /,
    *,
    storage: Storage | None = None,
    budget: Budget | None = None,
    mode: ExecutionMode = "local",
) -> Run: ...


@overload
def run(
    *,
    task: Task,
    seed: object,
    proposer: ProposerLike,
    search: SearchProgram | None = None,
    context: ContextPolicy | None = None,
    experience: ExperienceAccess | None = None,
    storage: Storage | None = None,
    budget: Budget | None = None,
    random_seed: int = 0,
    mode: ExecutionMode = "local",
    registry: Registry | None = None,
) -> Run: ...


def run(
    experiment: Experiment | object = _UNSET,
    /,
    *,
    task: Task | object = _UNSET,
    seed: object = _UNSET,
    proposer: ProposerLike | object = _UNSET,
    search: SearchProgram | None | object = _UNSET,
    context: ContextPolicy | None | object = _UNSET,
    experience: ExperienceAccess | None | object = _UNSET,
    storage: Storage | None = None,
    budget: Budget | None = None,
    random_seed: int | object = _UNSET,
    mode: ExecutionMode = "local",
    registry: Registry | None | object = _UNSET,
) -> Run:
    """Run one evaluated improvement search and return its inspectable history.

    Pass an [Experiment][meta_evolve.Experiment] as the positional argument.
    The source-compatible keyword form accepts its declaration fields instead;
    supplying both forms raises ``TypeError``.
    The keyword form retains the effective defaults ``search=None``,
    ``context=None``, ``experience=None``, ``random_seed=0``, and
    ``registry=None``. The default ``Greedy()`` inherits finite trial allowance,
    falling back to 20 when unbounded. Both forms use the same
    [Session][meta_evolve.Session] as paced and resumed execution.

    ``storage=None`` creates separate in-memory storage. A durable storage
    handle preserves local history; resumability additionally requires
    registered, reconstructible components and a supported execution mode.

    ``budget=None`` uses the task budget, or an unrestricted resource allowance
    if the task has none. In a supplied [Budget][meta_evolve.Budget], omitted or
    ``None`` dimensions inherit task ceilings. Finite values may tighten or
    introduce ceilings; exceeding a finite task ceiling raises ``ValueError``
    before work starts. ``Budget()`` preserves all task ceilings.

    ``mode="local"`` accepts live Python callables and provides no isolation.
    ``"durable-local"`` adds reconstructible execution and recovery.
    ``"distributed"`` uses the durable dispatcher and currently executes
    serially, one worker at a time; it does not provide multiprocess concurrency.
    The latter two modes require durable storage, registered components, and
    their declared capabilities. See the programming model's execution profiles.

    Invalid proposals and ordinary proposer or evaluator failures are recorded as
    typed trial outcomes; they are not converted to low scores. Capability and
    infrastructure exceptions can abort execution instead of producing a Run.

    :param experiment: Typed declaration. It cannot be combined with declaration
        keywords.
    :param task: See [Experiment][meta_evolve.Experiment].
    :param seed: See [Experiment][meta_evolve.Experiment].
    :param proposer: See [Experiment][meta_evolve.Experiment].
    :param search: See [Experiment][meta_evolve.Experiment].
    :param context: See [Experiment][meta_evolve.Experiment].
    :param experience: See [Experiment][meta_evolve.Experiment].
    :param storage: Artifact and event storage; defaults to isolated memory storage.
    :param budget: Partial run restriction. Omitted or ``None`` dimensions inherit
        task ceilings; explicit finite widening raises ``ValueError`` before work.
    :param random_seed: See [Experiment][meta_evolve.Experiment].
    :param mode: ``"local"``, ``"durable-local"``, or serial ``"distributed"`` execution.
    :param registry: See [Experiment][meta_evolve.Experiment].
    :returns: A [Run][meta_evolve.Run] for result, history, usage, and comparison
        queries, including when no evaluation succeeded.
    :raises TypeError: If a declared public input has the wrong type.
    :raises ValueError: If a declaration is invalid or the task budget is widened.
    :raises BudgetUnavailable: If the seed cannot be admitted.
    :raises CapabilityError: If the requested execution requirements cannot be satisfied.
    """

    declaration = _normalize_experiment(
        experiment,
        task=task,
        seed=seed,
        proposer=proposer,
        search=search,
        context=context,
        experience=experience,
        random_seed=random_seed,
        registry=registry,
    )
    with Session.start(
        declaration,
        storage=storage,
        budget=budget,
        mode=mode,
    ) as session:
        if mode == "distributed":
            # A distributed run's unit of progress is a work item, not a
            # decision, so it is driven rather than iterated. Same call, same
            # returned `Run` -- the mode is the only thing that differs.
            session.drive()
        else:
            for _decision in session:
                pass
    return session.run


__all__ = [
    "ArchiveDecisionView",
    "ArtifactView",
    "DecisionView",
    "EvidenceView",
    "ExecutionMode",
    "ProposerLike",
    "Run",
    "RunComparison",
    "RunDeclaration",
    "RunExperienceUsage",
    "RunInspection",
    "RunNotFound",
    "RunOverview",
    "RunSummary",
    "Session",
    "Storage",
    "StopDecisionView",
    "TrialDecisionView",
    "TrialView",
    "resume",
    "run",
]
