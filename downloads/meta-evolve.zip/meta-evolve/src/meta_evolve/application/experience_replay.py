"""Build experience views through the validated run replay path."""

from __future__ import annotations

from collections.abc import Iterable

from meta_evolve.domain import (
    ArtifactCreated,
    BootstrapPrepared,
    EvidenceRecorded,
    ExperienceRef,
    PolicyDecisionMade,
    ProposalSubmitted,
    RunId,
    TrialCompleted,
    TrialId,
    TrialSpec,
)
from meta_evolve.domain.context import ContextRecord
from meta_evolve.domain.events import EventEnvelope
from meta_evolve.domain.search import InvalidSearchHistory

from .experience import (
    _KIND_ORDER,
    ExperienceGraph,
    ExperienceNode,
    ExperienceRecord,
)
from .projections import replay_run_projection


def _ref(run_id: RunId, kind: str, occurrence_id: object) -> ExperienceRef:
    value = getattr(occurrence_id, "value", occurrence_id)
    return ExperienceRef(run_id=run_id, kind=kind, occurrence_id=value)


def _active_owner_by_ref(
    run_id: RunId, events: tuple[EventEnvelope, ...]
) -> dict[ExperienceRef, TrialId | None]:
    """Attribute artifacts and evidence to the trial executing at commit time."""

    active: TrialId | None = None
    owners: dict[ExperienceRef, TrialId | None] = {}
    for event in events:
        body = event.body
        if isinstance(body, BootstrapPrepared):
            active = body.trial.id
        elif isinstance(body, PolicyDecisionMade):
            active = body.trial_id if isinstance(body.decision, TrialSpec) else None
        elif isinstance(body, ProposalSubmitted):
            active = body.proposal.trial_id
        elif isinstance(body, TrialCompleted):
            active = None
        elif isinstance(body, ArtifactCreated):
            owners[_ref(run_id, "artifact", body.artifact_id)] = active
        elif isinstance(body, EvidenceRecorded):
            owners[_ref(run_id, "evidence", body.evidence.id)] = active
    return owners


def replay_experience_graph(
    run_id: RunId,
    events: Iterable[EventEnvelope],
    *,
    _hidden_refs: Iterable[ExperienceRef] = (),
    _retracted_refs: Iterable[ExperienceRef] = (),
    _non_local_refs: Iterable[ExperienceRef] = (),
) -> ExperienceGraph:
    """Project validated committed facts without introducing another lifecycle.

    Record existence, steps, and values come from the run projection's single
    experience-record derivation; this module only adds graph topology.
    """

    retained = tuple(events)
    projection = replay_run_projection(run_id, retained)
    if projection.start is None:
        raise InvalidSearchHistory("experience history has no started run")
    task_id = projection.start.task_id

    evidence_owners: dict[object, TrialId] = {}
    artifact_owners: dict[object, TrialId] = {}
    for completed in projection.completed_trials:
        for evidence_id in completed.outcome.evidence_ids:
            evidence_owners[evidence_id] = completed.trial.id
        for artifact_id in completed.outcome.artifact_ids:
            artifact_owners[artifact_id] = completed.trial.id
    for completed in projection.completed_evaluations:
        evaluation = completed.evaluation
        for evidence_id in evaluation.evidence_ids:
            evidence_owners[evidence_id] = evaluation.trial_id

    node_steps: dict[TrialId, int] = {}
    specs: dict[TrialId, object] = {}
    if projection.bootstrap is not None:
        bootstrap_trial = projection.bootstrap.trial
        node_steps[bootstrap_trial.id] = bootstrap_trial.logical_step
        specs[bootstrap_trial.id] = bootstrap_trial.spec
    decision_owners: dict[object, TrialId | None] = {}
    for decision in projection.decisions:
        owner = decision.trial_id if isinstance(decision.decision, TrialSpec) else None
        decision_owners[decision.decision_id] = owner
        if owner is not None:
            node_steps[owner] = decision.logical_step
            specs[owner] = decision.decision

    commit_owners = _active_owner_by_ref(run_id, retained)

    def owner_of(item: ContextRecord) -> TrialId | None:
        kind = item.ref.kind
        if kind in {"trial", "outcome"}:
            return TrialId(item.ref.occurrence_id)
        if kind in {"proposal", "evaluation", "context_selection"}:
            return item.value.trial_id
        if kind == "experience_grant":
            return item.value.grant.trial_id
        if kind in {
            "experience_attempt",
            "experience_success",
            "experience_denial",
            "experience_exhaustion",
        }:
            return item.value.trial_id
        if kind == "decision":
            body = item.value
            return body.trial_id if isinstance(body.decision, TrialSpec) else None
        if kind == "decision_explanation":
            return decision_owners.get(item.value.decision_id)
        if kind == "artifact":
            return artifact_owners.get(
                item.value.artifact_id, commit_owners.get(item.ref)
            )
        if kind == "evidence":
            return evidence_owners.get(item.value.id, commit_owners.get(item.ref))
        return None

    records: list[ExperienceRecord] = []
    owners: list[tuple[ExperienceRef, ExperienceRef | None]] = []
    seen_refs: set[ExperienceRef] = set()
    for item in projection.experience_records:
        if item.ref in seen_refs:
            # Write-side validation rejects a recommitted occurrence whose
            # value differs, so keeping the first committed value is lossless.
            continue
        seen_refs.add(item.ref)
        records.append(
            ExperienceRecord(
                ref=item.ref,
                task_id=task_id,
                logical_step=item.logical_step,
                event_sequence=item.event_sequence,
                value=item.value,
            )
        )
        owner = owner_of(item)
        owner_ref = _ref(run_id, "trial", owner) if owner is not None else None
        owners.append((item.ref, owner_ref))

    records.sort(key=lambda item: (item.event_sequence, _KIND_ORDER[item.kind]))
    records_by_owner: dict[ExperienceRef, list[ExperienceRecord]] = {}
    owner_by_ref = dict(owners)
    for record in records:
        owner = owner_by_ref[record.ref]
        if owner is not None:
            records_by_owner.setdefault(owner, []).append(record)

    nodes = []
    parents = []
    for trial_id, logical_step in node_steps.items():
        node_ref = _ref(run_id, "trial", trial_id)
        proposal = projection.proposal_for(trial_id)
        nodes.append(
            ExperienceNode(
                ref=node_ref,
                task_id=task_id,
                trial_id=trial_id,
                logical_step=logical_step,
                records=tuple(records_by_owner.get(node_ref, ())),
                derived_from=proposal.derived_from if proposal is not None else (),
            )
        )
        parent_refs = []
        for artifact_id in specs[trial_id].parent_ids:
            parent_id = artifact_owners.get(artifact_id)
            parent_ref = (
                _ref(run_id, "trial", parent_id) if parent_id is not None else None
            )
            if parent_ref is not None and parent_ref not in parent_refs:
                parent_refs.append(parent_ref)
        parents.append((node_ref, tuple(parent_refs)))

    nodes.sort(key=lambda item: (item.logical_step, item.trial_id.value))
    return ExperienceGraph(
        run_id=run_id,
        task_id=task_id,
        _records=tuple(records),
        _nodes=tuple(nodes),
        _parents=tuple(parents),
        _record_owners=tuple(owners),
        _hidden_refs=frozenset(_hidden_refs),
        _retracted_refs=frozenset(_retracted_refs),
        _non_local_refs=frozenset(_non_local_refs),
    )


__all__ = ["replay_experience_graph"]
