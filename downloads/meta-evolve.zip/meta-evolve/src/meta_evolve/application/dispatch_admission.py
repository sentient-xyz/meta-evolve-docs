"""Workers arriving while a drive runs, and one worker's reconnect.

Declared here, in `application/`, and implemented in `distributed/`: the loop
owns what it needs of a backend, and the transport provides it (design SD5).
`Session.drive` hands the dispatcher a `Workers`, which is the whole of what
the loop knows about listeners, processes or keys -- nothing.

**Two phases, and the order is a promise** (PD2). `Execution.open` spawns and
admits every worker a run needs BEFORE the epoch rolls over, so a handshake
that fails leaves a genesis-only run that resumes with its epoch unchanged.
Only an open host admits later, one poll at a time, because only an operator's
workers arrive on their own schedule.

**Reattachment keeps acceptances, not work** (PD1). A lease is rebound only
inside the epoch that issued it, to a connection of the same worker, and only
while the binding still exists -- which is to say, only when the worker
reconnected before the loop judged its old connection dead. Everything else it
resends is answered from the store: `Duplicate` when the commit landed,
`Stale` when it did not.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Protocol

from meta_evolve.domain import RunId
from meta_evolve.domain.components import ComponentManifest
from meta_evolve.domain.context import ContextSpec
from meta_evolve.domain.events import RunStarted
from meta_evolve.domain.work import Lease
from meta_evolve.ports.worker_registry import TrustedWorkerReader

from .dispatch_endpoint import Endpoint

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .dispatch_loop import DispatchLoop


@dataclass(frozen=True, slots=True)
class HostTerms:
    """What a run tells its execution backend about itself.

    A listening backend calls `trusted_workers` when opening, before it binds
    a port, and uses the returned reader for live admission checks. A spawned
    backend needs no allow-list and leaves the factory unused.
    """

    run_id: RunId
    started: RunStarted
    context: ContextSpec | None
    manifests: tuple[ComponentManifest, ...]
    fingerprint: str
    heartbeat_seconds: int
    live: Mapping[str, str] = field(default_factory=dict)
    trusted_workers: Callable[[], TrustedWorkerReader] | None = None


@dataclass(frozen=True, slots=True)
class Joining:
    """One admitted connection, and the leases it says it still holds."""

    endpoint: Endpoint
    held: tuple[Lease, ...]
    incarnation: str


class Workers(Protocol):
    """One run's execution backend, as the dispatcher sees it."""

    #: Admitted before the epoch rolled over; empty for a host that listens.
    endpoints: tuple[Endpoint, ...]

    def admit(self) -> tuple[Joining, ...]:
        """Whoever finished a handshake since the last poll. Never blocks."""

    def may_admit(self) -> bool:
        """Whether another worker could still arrive.

        What separates "no workers yet" from "no workers left": an open host
        waits, and a spawned-worker run whose children have all died is
        refused by name rather than waiting for something that cannot come.
        """

    def finish(self, *, completed: bool) -> None:
        """Say goodbye if the run finished, then close everything."""


class Execution(Protocol):
    """What `Session.drive(execution=...)` takes."""

    def open(self, terms: HostTerms) -> Workers:
        """Bind, spawn and admit what this run needs, before its rollover."""


def admit_into(loop: DispatchLoop, admission: Workers | None) -> None:
    """Register whoever was admitted, superseding a worker's own old connection.

    Matching is by WORKER ID, which is what makes this a reconnect rather than
    a new worker: the ids are the run's own slots or an operator's, and the
    handshake has already refused a second live process using one (PD7).
    """

    if admission is None:
        return
    for joining in admission.admit():
        worker = joining.endpoint.registrations[0].worker
        old = next(
            (
                endpoint
                for endpoint in loop.endpoints
                if endpoint.registrations[0].worker == worker
            ),
            None,
        )
        if old is None:
            loop.register(joining.endpoint)
        else:
            loop.supersede(old, joining.endpoint, joining.held)


__all__ = [
    "Execution",
    "HostTerms",
    "Joining",
    "Workers",
    "admit_into",
]
