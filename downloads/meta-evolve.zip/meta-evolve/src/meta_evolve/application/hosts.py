"""Shared coordinator commit contract, inherited by application host protocols."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Protocol

from meta_evolve.domain import Artifact, CorrelationId
from meta_evolve.ports.work_store import WorkIntent

from .run_projection import RunProjection


class CommitBatchHost(Protocol):
    """Commit durable facts, artifact occurrences, and work intents together."""

    def commit_batch(
        self,
        bodies: Sequence[object],
        *,
        occurrences: Sequence[Artifact] = (),
        correlation: CorrelationId,
        work: Sequence[WorkIntent] = (),
    ) -> RunProjection: ...


__all__ = ["CommitBatchHost"]
