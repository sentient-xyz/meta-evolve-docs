"""Whether a stale answer tells a connection that its own worker was revoked.

`Settler._answer` asks this after answering; on yes it releases the item and
fails the connection.
"""

from __future__ import annotations

from meta_evolve.domain.work import Lease, StaleReason
from meta_evolve.domain.workers import WorkerRegistration
from meta_evolve.ports.work_submission import Duplicate, Stale

from .dispatch_messages import Accepted


def holds_a_revoked_credential(
    lease: Lease,
    outcome: Accepted | Duplicate | Stale,
    registrations: tuple[WorkerRegistration, ...],
) -> bool:
    """Whether `outcome` says THIS connection's own worker has been revoked.

    Only for the SAME (id, generation) pair: a worker revoked, re-trusted and
    readmitted at the bumped generation resends its pre-revoke leases, and must
    not be dropped for them. Any other stale reason is the run's ordinary
    business, not a reason to drop the connection.
    """

    if not isinstance(outcome, Stale) or outcome.reason is not StaleReason.STALE_GENERATION:
        return False
    return any(
        registration.worker.value == lease.worker_id
        and registration.generation == lease.generation
        for registration in registrations
    )


__all__ = ["holds_a_revoked_credential"]
