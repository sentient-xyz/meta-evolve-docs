"""Replay validation for context declaration and selection facts."""

from __future__ import annotations

from dataclasses import replace

from meta_evolve.domain import ContextPolicyDeclared, ContextSelected, TrialSpec
from meta_evolve.domain.context import bundle_violation
from meta_evolve.domain.search import InvalidSearchHistory

from .run_projection import RunProjection


def _invalid(sequence: int, reason: str) -> InvalidSearchHistory:
    return InvalidSearchHistory(
        f"invalid search history at sequence {sequence}: {reason}"
    )


def declare_context(
    state: RunProjection,
    body: ContextPolicyDeclared,
    sequence: int,
) -> RunProjection:
    if not state.ready:
        raise _invalid(
            sequence,
            "bootstrap evaluation must precede context policy declaration",
        )
    if state.context_declaration is not None:
        raise _invalid(sequence, "context policy was already declared")
    if state.experience_declaration is not None:
        raise _invalid(
            sequence,
            "context policy must be declared before experience access",
        )
    if state.decisions:
        raise _invalid(sequence, "context policy must precede policy decisions")
    return replace(state, version=sequence, context_declaration=body)


def select_context(
    state: RunProjection,
    body: ContextSelected,
    sequence: int,
) -> RunProjection:
    decision = next(
        (item for item in state.decisions if item.trial_id == body.trial_id),
        None,
    )
    if decision is None or not isinstance(decision.decision, TrialSpec):
        raise _invalid(sequence, "context selection has no trial decision")
    declaration = state.context_declaration
    if declaration is None:
        raise _invalid(sequence, "context selection has no policy declaration")
    if (
        body.policy != declaration.spec.policy
        or decision.decision.context_policy != body.policy
    ):
        raise _invalid(sequence, "context selection policy does not match its trial")
    if state.selection_for(body.trial_id) is not None:
        raise _invalid(sequence, "trial context was already selected")
    if body.observed_version != state.version:
        raise _invalid(sequence, "context selection observed the wrong stream version")
    # The explanation invariant fixes the decision at observed_version + 1 and
    # its explanation at observed_version + 2, so position needs no event log.
    if state.version != decision.observed_version + 2:
        raise _invalid(
            sequence,
            "context selection must immediately follow its decision explanation",
        )
    violation = bundle_violation(
        body.bundle,
        declaration.spec,
        state.experience_records,
        before_step=decision.logical_step,
    )
    if violation is not None:
        raise _invalid(sequence, violation)
    return replace(
        state,
        version=sequence,
        context_selections=state.context_selections + (body,),
    )


__all__ = ["declare_context", "select_context"]
