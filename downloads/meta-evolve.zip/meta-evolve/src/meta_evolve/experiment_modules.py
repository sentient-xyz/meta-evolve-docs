"""Loading an experiment module, and what a worker process builds from one.

Two callers now reach an experiment module by reference: the command line,
which loads it to start or resume a run, and a worker process, which loads it
to build the executors that run one item. The loading half lived in `cli.py`
and moved here unchanged when the second caller appeared -- `cli.py` is at its
length ceiling, and a worker importing the command line to load a module would
make the CLI a library boundary it is not.

`worker_executors` is the worker's half, and it takes the RECORDED start
rather than the module's own declaration. A module supplies the REGISTRY, as
`resume --module` does; the task, the proposer reference and the policy
specification come from what the run recorded, and reach the worker in the
handshake. The difference is not stylistic:

- the policy manifest's configuration digest is computed from a `SearchSpec`
  bound with the RUN's budget, so a run started with a narrowed budget would
  refuse every worker that rebuilt the spec from the module alone;
- `verify_manifests` covers components, never the `Task`, so a module whose
  task declared different objectives would evaluate under them and hand back a
  result whose meaning the run never asked for.
"""

from __future__ import annotations

import importlib
import importlib.util
import sys
import warnings
from pathlib import Path
from types import ModuleType

from meta_evolve.application.executors import (
    LocalEvaluationExecutor,
    LocalProposalExecutor,
)
from meta_evolve.application.run_support import resolve_registered_components
from meta_evolve.application.codecs import CodecIndex
from meta_evolve.domain.components import ComponentManifest
from meta_evolve.domain.context import ContextSpec
from meta_evolve.domain.events import RunStarted
from meta_evolve.errors import CapabilityError
from meta_evolve.registry import Registry

FACTORY = "experiment"

# Exactly the ``meta.run`` keywords an experiment module owns. ``storage`` and
# ``mode`` are the command line's (--storage/--mode) and a budget belongs on
# the Task, so a factory returning any of them is a contract error, not a
# silently ignored value.
FACTORY_KEYWORDS = frozenset(
    {"task", "seed", "proposer", "search", "context", "experience", "registry",
     "random_seed"}
)

MODULE_HELP = (
    f"experiment module exposing {FACTORY}(): a path ending in .py, or an "
    "importable dotted module name"
)


class ExperimentModuleError(Exception):
    """A named module does not satisfy the experiment-module convention."""


def import_experiment_module(reference: str) -> ModuleType:
    """Load ``reference`` as a file when it ends in ``.py``, else import it.

    A file is loaded under its own stem as module name, which is what a dotted
    import of the same file would give it, so ``run`` and ``resume`` record and
    verify the same component import hints either way. Its directory is
    appended to ``sys.path`` so an experiment module can import its siblings —
    appended, not prepended, so a file there can never shadow the standard
    library. Everything else follows ordinary import rules.
    """

    if reference.endswith(".py"):
        path = Path(reference)
        if not path.is_file():
            raise ExperimentModuleError(f"no experiment module at {reference}")
        directory = str(path.resolve().parent)
        if directory not in sys.path:
            sys.path.append(directory)
        spec = importlib.util.spec_from_file_location(path.stem, path)
        if spec is None or spec.loader is None:
            raise ExperimentModuleError(f"{reference} is not an importable module")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    try:
        return importlib.import_module(reference)
    except ImportError as error:
        raise ExperimentModuleError(
            f"cannot import experiment module {reference}: {error}"
        ) from error


def experiment_declaration(reference: str):
    """The typed declaration ``reference``'s factory returns."""

    import meta_evolve as meta

    module = import_experiment_module(reference)
    factory = getattr(module, FACTORY, None)
    if not callable(factory):
        raise ExperimentModuleError(
            f"{reference} defines no callable {FACTORY}() factory"
        )
    declaration = factory()
    if isinstance(declaration, meta.Experiment):
        return declaration
    if not isinstance(declaration, dict):
        raise ExperimentModuleError(
            f"{reference}:{FACTORY}() must return meta.Experiment, got "
            f"{type(declaration).__name__}"
        )
    unknown = sorted(set(declaration) - FACTORY_KEYWORDS)
    if unknown:
        raise ExperimentModuleError(
            f"{reference}:{FACTORY}() returned keywords the command line does "
            f"not pass on: {unknown}. storage and mode are the command line's "
            "own (--storage/--mode) and a budget belongs on the Task"
        )
    warnings.warn(
        f"{reference}:{FACTORY}() returned a dict; return "
        "meta.Experiment(...) instead",
        DeprecationWarning,
        stacklevel=2,
    )
    try:
        return meta.Experiment(**declaration)
    except TypeError as error:
        raise ExperimentModuleError(
            f"{reference}:{FACTORY}() returned an invalid Experiment "
            f"declaration: {error}"
        ) from error


def refuse_main_hints(manifests: tuple[ComponentManifest, ...]) -> None:
    """Refuse a run whose components only exist inside a ``__main__`` script.

    A worker process imports the module by reference, and no reference can
    reach the objects a parent defined in its own ``__main__``. Checked before
    anything is spawned, so the common mistake costs nothing.
    """

    stranded = sorted(
        manifest.name
        for manifest in manifests
        if manifest.import_hint.startswith("__main__:")
    )
    if stranded:
        raise CapabilityError(
            "worker processes cannot import components defined in a __main__ "
            f"script: {stranded}. Put them in an importable module and name it "
            "by reference"
        )


def worker_executors(
    registry: Registry,
    started: RunStarted,
    context: ContextSpec | None,
) -> tuple[LocalEvaluationExecutor, LocalProposalExecutor, tuple[ComponentManifest, ...]]:
    """One worker's executors and the manifests it declares for admission.

    The same calls `prepare_resume` makes, against the recorded start rather
    than a durable store the worker does not have.
    """

    if not isinstance(registry, Registry):
        raise CapabilityError(
            "a worker needs the component registry its experiment module "
            "declares: the module's factory returned none"
        )
    codecs = CodecIndex.with_extras(registry.artifact_types())
    proposer_runner, evaluator = resolve_registered_components(
        registry, started.search.proposer, started.task, codecs
    )
    manifests = registry.manifests_for(
        proposer=started.search.proposer,
        evaluator=started.task.evaluator,
        search=started.search,
        context=context,
    )
    return (
        LocalEvaluationExecutor(evaluator, codecs),
        LocalProposalExecutor(proposer_runner, codecs, started.task),
        manifests,
    )


__all__ = [
    "FACTORY",
    "FACTORY_KEYWORDS",
    "MODULE_HELP",
    "ExperimentModuleError",
    "experiment_declaration",
    "import_experiment_module",
    "refuse_main_hints",
    "worker_executors",
]
