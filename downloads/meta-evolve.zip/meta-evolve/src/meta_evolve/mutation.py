"""Neutral contracts for typed, authority-bounded mutation surfaces."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, Protocol, TypeVar

from meta_evolve.domain import ComponentRef, Failure


MutationT = TypeVar("MutationT", contravariant=True)
SurfaceT = TypeVar("SurfaceT", covariant=True)


@dataclass(frozen=True, slots=True)
class MutationApplication(Generic[SurfaceT]):
    """Exactly one changed surface or typed failure from wrapper validation."""

    surface: SurfaceT | None = None
    failure: Failure | None = None

    def __post_init__(self) -> None:
        if (self.surface is None) == (self.failure is None):
            raise ValueError(
                "a mutation application contains exactly one surface or failure"
            )


class MutationSurface(Protocol[MutationT, SurfaceT]):
    """A declared value that can construct one intended local mutation."""

    name: str
    component: ComponentRef
    interface: str

    def apply(self, mutation: MutationT) -> MutationApplication[SurfaceT]: ...


__all__ = ["MutationApplication", "MutationSurface"]
