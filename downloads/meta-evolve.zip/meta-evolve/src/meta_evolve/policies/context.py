"""Deterministic run-level policies for pushed experience context."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from meta_evolve import serialization
from meta_evolve.application.experience import ExperienceGraph, ExperienceQuery
from meta_evolve.domain import (
    ContextBundle,
    ContextRecord,
    ContextSpec,
    ContextUsage,
    Evaluation,
    ExperienceRef,
    PolicyRef,
    Task,
    rank_evaluations,
)
from meta_evolve.domain.experience import NON_CANDIDATE_EXPERIENCE_KINDS


class ContextPolicy(Protocol):
    """Select the exact bounded context bundle pushed to one proposer call.

    Only records committed strictly before the candidate trial's logical step
    are eligible; context facts themselves are never eligible. The kernel
    rejects a bundle that selects anything else or exceeds the declared bounds.
    """

    policy: PolicyRef
    max_records: int
    max_chars: int

    def select(
        self,
        task: Task,
        candidate: ExperienceRef,
        graph: ExperienceGraph,
        spec: ContextSpec,
    ) -> ContextBundle: ...


def _records(values: object) -> tuple[ContextRecord, ...]:
    return tuple(
        ContextRecord(
            ref=item.ref,
            logical_step=item.logical_step,
            event_sequence=item.event_sequence,
            value=item.value,
        )
        for item in values
        if item.kind not in NON_CANDIDATE_EXPERIENCE_KINDS
    )


def _bundle(
    candidates: tuple[ContextRecord, ...],
    spec: ContextSpec,
    reason: str,
    *,
    recent: bool = False,
) -> ContextBundle:
    if recent:
        records = candidates[-spec.max_records:] if spec.max_records else ()
    else:
        records = candidates[:spec.max_records]
    complete = "\n".join(serialization.dumps(item) for item in records)
    rendered = complete[: spec.max_chars]
    return ContextBundle(
        records=records,
        rendered=rendered,
        reason=reason,
        truncated=len(records) < len(candidates) or len(rendered) < len(complete),
        usage=ContextUsage(records=len(records), chars=len(rendered)),
    )


@dataclass(frozen=True, slots=True)
class NoMemory:
    """Select no pushed feedback; equivalent to ``Experiment(context=None)``.

    This is the default. It does not disable separately declared pull access
    or erase retained history; the proposer simply receives an empty bundle.
    """

    policy = PolicyRef("no-memory", "1")
    max_records = 0
    max_chars = 0

    def select(
        self,
        task: Task,
        candidate: ExperienceRef,
        graph: ExperienceGraph,
        spec: ContextSpec,
    ) -> ContextBundle:
        return ContextBundle.empty()


@dataclass(frozen=True, slots=True)
class AncestorsOnly:
    """Push records from accessible ancestors in graph and commit order.

    Retain the oldest records when the bound fills. For recent feedback, use
    ``RecentAncestors``. A keyword-only ``context`` callback argument exposes
    ``context.evidence.latest(kind)`` and ``context.bundle.rendered``.
    Only authorized prior records qualify; storing evidence alone enables no feedback.

    :param max_records: Maximum selected records, default ``20``; non-negative.
    :param max_chars: Maximum rendered characters, default ``8000``; non-negative.
        Rendered text may be truncated independently of the selected records.
    """

    max_records: int = 20
    max_chars: int = 8_000
    policy = PolicyRef("ancestors-only", "1")

    def __post_init__(self) -> None:
        ContextSpec(
            policy=self.policy, max_records=self.max_records, max_chars=self.max_chars
        )

    def select(
        self,
        task: Task,
        candidate: ExperienceRef,
        graph: ExperienceGraph,
        spec: ContextSpec,
    ) -> ContextBundle:
        return _bundle(
            _ancestor_records(graph, candidate), spec, "accessible ancestor records"
        )


@dataclass(frozen=True, slots=True)
class RecentAncestors:
    """Push the newest accessible ancestor records in canonical order.

    Set ``Experiment(context=RecentAncestors(...))`` for iterative feedback.
    The bounds count all structured records, not just evidence. A small bound
    may omit matching evidence; rejected siblings are outside the ancestry.

    :param max_records: Maximum selected records, default ``20``; non-negative.
    :param max_chars: Maximum rendered characters, default ``8000``; non-negative.
        Text clipping does not remove selected structured records.
    """

    max_records: int = 20
    max_chars: int = 8_000
    policy = PolicyRef("recent-ancestors", "1")

    def __post_init__(self) -> None:
        ContextSpec(
            policy=self.policy, max_records=self.max_records, max_chars=self.max_chars
        )

    def select(
        self, task: Task, candidate: ExperienceRef,
        graph: ExperienceGraph, spec: ContextSpec,
    ) -> ContextBundle:
        return _bundle(
            _ancestor_records(graph, candidate), spec,
            "recent accessible ancestor records", recent=True,
        )


@dataclass(frozen=True, slots=True)
class BestSibling:
    """Push the best successful prior sibling under the primary objective."""

    max_records: int = 20
    max_chars: int = 8_000
    policy = PolicyRef("best-sibling", "1")

    def __post_init__(self) -> None:
        ContextSpec(
            policy=self.policy, max_records=self.max_records, max_chars=self.max_chars
        )

    def select(
        self,
        task: Task,
        candidate: ExperienceRef,
        graph: ExperienceGraph,
        spec: ContextSpec,
    ) -> ContextBundle:
        query = _query(graph, candidate)
        siblings = tuple(
            node for node in graph.siblings(candidate, query) if node.ref != candidate
        )
        evaluations = tuple(
            record.value
            for node in siblings
            for record in node.records
            if record.kind == "evaluation" and isinstance(record.value, Evaluation)
        )
        ranked = rank_evaluations(task.objectives[0], evaluations)
        if not ranked:
            return _bundle((), spec, "no successful prior sibling")
        winner = next(node for node in siblings if node.trial_id == ranked[0].trial_id)
        return _bundle(
            _records(winner.records),
            spec,
            f"best successful sibling {winner.trial_id.value}",
        )


def _ancestor_records(
    graph: ExperienceGraph, candidate: ExperienceRef
) -> tuple[ContextRecord, ...]:
    nodes = graph.ancestors(candidate, _query(graph, candidate))
    return _records(record for node in nodes for record in node.records)


def _query(graph: ExperienceGraph, candidate: ExperienceRef) -> ExperienceQuery:
    unrestricted = ExperienceQuery(task_id=graph.task_id, run_id=graph.run_id)
    node = graph.node(candidate, unrestricted)
    return ExperienceQuery(
        task_id=graph.task_id,
        run_id=graph.run_id,
        as_of=node.logical_step,
    )


__all__ = ["AncestorsOnly", "BestSibling", "ContextPolicy", "NoMemory", "RecentAncestors"]
