"""Immutable history fold and selection for the TreeSearch preset."""

from __future__ import annotations

from dataclasses import dataclass
import math

from meta_evolve.domain import ArtifactId, Evaluation, Maximize
from meta_evolve.domain.search import InvalidSearchHistory, SearchState


@dataclass(frozen=True, slots=True)
class TreeNode:
    artifact_id: ArtifactId
    parent_id: ArtifactId | None
    child_ids: tuple[ArtifactId, ...]
    visits: int
    evaluation: Evaluation
    utility: float | None
    q: float | None

    @property
    def widening_limit(self) -> int:
        return math.ceil(math.sqrt(self.visits))


@dataclass(frozen=True, slots=True)
class TreeEdge:
    parent_id: ArtifactId
    child_id: ArtifactId
    q: float | None
    exploitation: float
    exploration_bonus: float
    parent_visits: int
    child_visits: int

    @property
    def score(self) -> float:
        return self.exploitation + self.exploration_bonus


@dataclass(frozen=True, slots=True)
class TreeSelection:
    node: TreeNode
    path: tuple[TreeEdge, ...]


@dataclass(frozen=True, slots=True)
class SearchTree:
    root_id: ArtifactId
    nodes: tuple[TreeNode, ...]
    minimum_utility: float | None
    maximum_utility: float | None

    def node(self, artifact_id: ArtifactId) -> TreeNode:
        for node in self.nodes:
            if node.artifact_id == artifact_id:
                return node
        raise KeyError(artifact_id)

    def select(self, exploration: float) -> TreeSelection:
        current = self.node(self.root_id)
        path: list[TreeEdge] = []
        while len(current.child_ids) >= current.widening_limit:
            edges = tuple(self._edge(current, self.node(child), exploration)
                          for child in current.child_ids)
            chosen = min(edges, key=lambda edge: (-edge.score, edge.child_id.value))
            path.append(chosen)
            current = self.node(chosen.child_id)
        return TreeSelection(current, tuple(path))

    def _edge(
        self, parent: TreeNode, child: TreeNode, exploration: float
    ) -> TreeEdge:
        exploitation = self._normalize(child.q)
        bonus = exploration * math.sqrt(
            math.log(parent.visits) / child.visits
        )
        return TreeEdge(
            parent_id=parent.artifact_id,
            child_id=child.artifact_id,
            q=child.q,
            exploitation=exploitation,
            exploration_bonus=bonus,
            parent_visits=parent.visits,
            child_visits=child.visits,
        )

    def _normalize(self, q: float | None) -> float:
        if q is None:
            return 0.0
        assert self.minimum_utility is not None
        assert self.maximum_utility is not None
        span = self.maximum_utility - self.minimum_utility
        if span == 0:
            return 0.0
        return (q - self.minimum_utility) / span


def fold_tree(state: SearchState) -> SearchTree:
    """Reconstruct the evaluated occurrence tree and attempt visit counts."""

    start = state.require_start()
    artifact_ids = state.artifact_ids
    if len(set(artifact_ids)) != len(artifact_ids):
        raise InvalidSearchHistory("tree search artifact occurrences must be unique")
    if start.seed_artifact_id not in artifact_ids:
        raise InvalidSearchHistory("tree search seed occurrence is not materialized")

    trials = {}
    materializers = {}
    parents: dict[ArtifactId, ArtifactId | None] = {}
    successor_trials = []
    bootstrap_count = 0
    for completed in state.completed_trials:
        trial = completed.trial
        if trial.id in trials:
            raise InvalidSearchHistory(
                f"tree search trial {trial.id.value} completed more than once"
            )
        trials[trial.id] = completed
        outcome = completed.outcome
        if outcome.failure is None:
            if len(outcome.artifact_ids) != 1:
                raise InvalidSearchHistory(
                    f"tree search trial {trial.id.value} must materialize one occurrence"
                )
            artifact_id = outcome.artifact_ids[0]
            if artifact_id in materializers:
                raise InvalidSearchHistory(
                    f"tree search occurrence {artifact_id.value} has multiple trials"
                )
            materializers[artifact_id] = trial.id
            if trial.logical_step == 0:
                bootstrap_count += 1
                if trial.spec.parent_ids or artifact_id != start.seed_artifact_id:
                    raise InvalidSearchHistory(
                        "tree search bootstrap must materialize the seed without a parent"
                    )
                parents[artifact_id] = None
            else:
                parent_id = _successor_parent(trial.id.value, trial.spec.parent_ids)
                parents[artifact_id] = parent_id
                successor_trials.append(completed)
        elif trial.logical_step != 0:
            _successor_parent(trial.id.value, trial.spec.parent_ids)
            successor_trials.append(completed)
        else:
            raise InvalidSearchHistory("tree search bootstrap cannot fail")

    if bootstrap_count != 1:
        raise InvalidSearchHistory("tree search history must contain one bootstrap")

    if set(materializers) != set(artifact_ids):
        missing = sorted(item.value for item in set(artifact_ids) - set(materializers))
        extra = sorted(item.value for item in set(materializers) - set(artifact_ids))
        raise InvalidSearchHistory(
            f"tree search materialized occurrences disagree with history: "
            f"missing={missing!r}, extra={extra!r}"
        )
    if parents.get(start.seed_artifact_id, object()) is not None:
        raise InvalidSearchHistory("tree search seed must be the only root")

    children: dict[ArtifactId, list[ArtifactId]] = {
        artifact_id: [] for artifact_id in artifact_ids
    }
    for artifact_id, parent_id in parents.items():
        if parent_id is None:
            continue
        if parent_id not in children or parent_id == artifact_id:
            raise InvalidSearchHistory(
                f"tree search occurrence {artifact_id.value} has invalid parent "
                f"{parent_id.value}"
            )
        children[parent_id].append(artifact_id)
    _require_connected(start.seed_artifact_id, children)

    evaluations: dict[ArtifactId, Evaluation] = {}
    for completed in state.completed_evaluations:
        evaluation = completed.evaluation
        if evaluation.artifact_id in evaluations:
            raise InvalidSearchHistory(
                f"tree search occurrence {evaluation.artifact_id.value} "
                "has multiple completed evaluations"
            )
        trial_id = materializers.get(evaluation.artifact_id)
        if trial_id is None or trial_id != evaluation.trial_id:
            raise InvalidSearchHistory(
                f"tree search evaluation {evaluation.id.value} has invalid parentage"
            )
        evaluations[evaluation.artifact_id] = evaluation
    unevaluated = sorted(
        item.value for item in set(artifact_ids) - set(evaluations)
    )
    if unevaluated:
        raise InvalidSearchHistory(
            f"tree search materialized occurrences lack completed evaluations: "
            f"{unevaluated!r}"
        )

    visits = {artifact_id: 1 for artifact_id in artifact_ids}
    for completed in successor_trials:
        parent_id = _successor_parent(
            completed.trial.id.value, completed.trial.spec.parent_ids
        )
        if parent_id not in parents:
            raise InvalidSearchHistory(
                f"tree search trial {completed.trial.id.value} selects unknown parent "
                f"{parent_id.value}"
            )
        cursor: ArtifactId | None = parent_id
        seen: set[ArtifactId] = set()
        while cursor is not None:
            if cursor in seen:
                raise InvalidSearchHistory("tree search parentage contains a cycle")
            seen.add(cursor)
            visits[cursor] += 1
            cursor = parents[cursor]

    objective = state.task.objectives[0]
    utilities: dict[ArtifactId, float | None] = {}
    for artifact_id, evaluation in evaluations.items():
        if evaluation.failure is not None:
            utilities[artifact_id] = None
            continue
        try:
            value = float(evaluation.metrics[objective.metric])
        except KeyError as error:
            raise InvalidSearchHistory(
                f"successful evaluation {evaluation.id.value} is missing primary "
                f"metric {objective.metric!r}"
            ) from error
        utilities[artifact_id] = value if isinstance(objective, Maximize) else -value

    q_values: dict[ArtifactId, float | None] = {}
    def backup(artifact_id: ArtifactId) -> float | None:
        candidates = [utilities[artifact_id]]
        candidates.extend(backup(child) for child in children[artifact_id])
        successful = [item for item in candidates if item is not None]
        result = max(successful) if successful else None
        q_values[artifact_id] = result
        return result

    backup(start.seed_artifact_id)
    successful_utilities = [item for item in utilities.values() if item is not None]
    ordered_ids = sorted(artifact_ids, key=lambda item: item.value)
    nodes = tuple(
        TreeNode(
            artifact_id=artifact_id,
            parent_id=parents[artifact_id],
            child_ids=tuple(sorted(children[artifact_id], key=lambda item: item.value)),
            visits=visits[artifact_id],
            evaluation=evaluations[artifact_id],
            utility=utilities[artifact_id],
            q=q_values[artifact_id],
        )
        for artifact_id in ordered_ids
    )
    return SearchTree(
        root_id=start.seed_artifact_id,
        nodes=nodes,
        minimum_utility=min(successful_utilities) if successful_utilities else None,
        maximum_utility=max(successful_utilities) if successful_utilities else None,
    )


def _successor_parent(trial_id: str, parent_ids: tuple[ArtifactId, ...]) -> ArtifactId:
    if len(parent_ids) != 1:
        raise InvalidSearchHistory(
            f"tree search trial {trial_id} must select exactly one parent"
        )
    return parent_ids[0]


def _require_connected(
    root_id: ArtifactId, children: dict[ArtifactId, list[ArtifactId]]
) -> None:
    visited: set[ArtifactId] = set()
    active: set[ArtifactId] = set()

    def visit(artifact_id: ArtifactId) -> None:
        if artifact_id in active:
            raise InvalidSearchHistory("tree search parentage contains a cycle")
        if artifact_id in visited:
            return
        active.add(artifact_id)
        for child_id in children[artifact_id]:
            visit(child_id)
        active.remove(artifact_id)
        visited.add(artifact_id)

    visit(root_id)
    if visited != set(children):
        disconnected = sorted(item.value for item in set(children) - visited)
        raise InvalidSearchHistory(
            f"tree search occurrences are disconnected from the seed: {disconnected!r}"
        )
