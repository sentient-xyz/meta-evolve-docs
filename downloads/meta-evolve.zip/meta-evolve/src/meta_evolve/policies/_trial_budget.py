"""Shared declaration and bind-time resolution of preset trial limits.

An omitted/``None`` limit inherits the effective finite ``Budget.trials``,
or uses the preset's finite fallback when that resource is unbounded. Resolution happens exactly
once, inside ``bind``, before the application layer reads ``configuration`` and
``identity_key``. Bound programs therefore always carry an integer, and the
resolved integer is what reaches ``SearchSpec``, the run identity, and the
durable record.

Reconstruction never re-resolves: registry factories rebuild from the recorded
``configuration``, which already holds that integer, so replaying a run against
a different budget cannot change its policy limit.
"""

from __future__ import annotations

from meta_evolve.domain import Budget

__all__: list[str] = []


def declared_trial_limit(value: object, label: str) -> int | None:
    """Validate a declared ``max_trials``, passing ``None`` through unresolved."""

    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{label} max_trials must be an integer or None")
    if value < 0:
        raise ValueError(f"{label} max_trials must be non-negative")
    return value


def resolve_trial_limit(
    declared: int | None, budget: Budget, *, fallback: int = 20
) -> int:
    """Resolve a preset allowance once, without widening external authority."""

    if declared is not None:
        return declared
    return fallback if budget.trials is None else budget.trials
