"""Private lowering shared by bounded single-parent search policies."""

from __future__ import annotations

from collections.abc import Callable

from meta_evolve.domain import (
    ArtifactId,
    Budget,
    ComponentRef,
    OperatorSpec,
    PolicyRef,
    SearchDecision,
    Stop,
    TrialSpec,
)
from meta_evolve.domain.search import PolicyMismatch, SearchState
from meta_evolve.errors import UnboundSearchProgram


ParentDecision = Callable[[SearchState], ArtifactId | Stop]


def lower_incumbent_decision(
    state: SearchState,
    *,
    policy: PolicyRef,
    max_trials: int,
    proposer: ComponentRef | None,
    operator: OperatorSpec | None,
    budget: Budget | None,
    unbound_message: str,
    decide_parent: ParentDecision | None = None,
) -> SearchDecision:
    """Apply the common envelope, then authorize one incumbent-shaped trial."""

    if proposer is None or operator is None or budget is None:
        raise UnboundSearchProgram(unbound_message)
    start = state.require_start()
    if start.search.policy != policy:
        raise PolicyMismatch(policy, start.search.policy)
    if state.stop is not None:
        return state.stop
    if state.objective_satisfied:
        return Stop(reason="objective_satisfied")
    if state.usage.trials >= max_trials:
        return Stop(reason="trial_limit_reached")
    if state.budget_exhausted:
        return Stop(reason=state.budget_stop_reason)

    selected = (
        decide_parent(state)
        if decide_parent is not None
        else state.incumbent_id or start.seed_artifact_id
    )
    if isinstance(selected, Stop):
        return selected
    return TrialSpec(
        task_id=start.task_id,
        parent_ids=(selected,),
        proposer=proposer,
        operator=operator,
        budget=budget.narrow(state.remaining_budget),
        random_seed=state.randomness.seed("trial"),
    )


__all__: list[str] = []
