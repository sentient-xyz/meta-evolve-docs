"""Whether a worker can run this run's work, from what its operator declared.

A component declares `work_requirements`; an operator declares a worker's
capabilities when enrolling it. They meet at admission against the run AS A
WHOLE (AD4): every admitted worker runs every item, so one that cannot is
refused before it holds a lease rather than failing each item it cannot run.
Pure functions over values, so the question has one answer everywhere it is
asked.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping

from meta_evolve.domain.components import ComponentManifest
from meta_evolve.domain.values import FrozenMap, canonical_payload_bytes
from meta_evolve.errors import CapabilityError

#: How much of a worker's declared value a refusal quotes. The declaration is
#: the operator's to size, and the refusal has to fit one frame.
QUOTED_DECLARATION_CHARS = 200


def required_capabilities(manifests: Iterable[ComponentManifest]) -> FrozenMap:
    """What a worker must declare to run this run: every component's needs.

    Two components requiring one key at two values is a `CapabilityError`: no
    declaration satisfies both, and a union where one of them won would admit
    workers that fail every item of the other. Only a listening host asks this;
    inline and `--workers N` runs accept the pair (the worker-administration
    plan's PD6).
    """

    required: dict[str, object] = {}
    owners: dict[str, ComponentManifest] = {}
    for manifest in manifests:
        for key, value in manifest.work_requirements.items():
            owner = owners.setdefault(key, manifest)
            if key in required and not _same(required[key], value):
                raise CapabilityError(
                    f"no worker can run this run: {_named(owner)} requires "
                    f"{key}={compact_json(required[key])} and {_named(manifest)} "
                    f"requires {key}={compact_json(value)}"
                )
            required[key] = value
    return FrozenMap(required)


def unmet_requirement(
    required: Mapping[str, object], declared: Mapping[str, object]
) -> str | None:
    """`None` when `declared` satisfies `required`, or the first key it does not.

    Satisfied means every required key is declared at an equal value; a key
    the run does not ask about is the worker's own business. Keys are checked
    in sorted order, so the same pair always names the same key.
    """

    for key in sorted(required):
        wanted = f"{key}={compact_json(required[key])}"
        if key not in declared:
            return (
                f"this run requires the capability {wanted}, which this worker "
                "does not declare"
            )
        if not _same(declared[key], required[key]):
            return (
                f"this run requires the capability {wanted}, and this worker "
                f"declares {key}={_quoted(compact_json(declared[key]))}"
            )
    return None


def _same(left: object, right: object) -> bool:
    """Equal as recorded values, not as Python objects.

    Python's `==` lets `1` satisfy `True` and `1.0` satisfy `1`; the canonical
    encoding tells all three apart, and compares a nested map or array by what
    it holds rather than by which object holds it.
    """

    return canonical_payload_bytes(left) == canonical_payload_bytes(right)


def _quoted(rendered: str) -> str:
    if len(rendered) <= QUOTED_DECLARATION_CHARS:
        return rendered
    return rendered[: QUOTED_DECLARATION_CHARS - 1] + "…"


def _named(manifest: ComponentManifest) -> str:
    return f"the {manifest.role} {manifest.name}@{manifest.version}"


def compact_json(value: object) -> str:
    """A value the way an operator wrote it, as compact JSON in key order.

    The one rendering of a capability or a requirement, in a refusal and in a
    `workers` report alike. Not the canonical bytes, whose tagged form would
    show `{"$tuple":[...]}` for an array and `{"$map":{}}` for a worker that
    declares nothing. `default=dict` is for a nested frozen map, the one value
    `json` does not already know; a frozen array is written as an array.
    """

    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=dict
    )


__all__ = ["compact_json", "required_capabilities", "unmet_requirement"]
