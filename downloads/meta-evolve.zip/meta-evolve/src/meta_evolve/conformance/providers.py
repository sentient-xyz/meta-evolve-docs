"""Provider-neutral proposer conformance, published as subclassable suites.

Every assertion here runs through the ordinary public path — ``meta.run``,
``Run.best``, ``Run.best_trial``, ``Run.experience_usage`` — so a proposer
passes on behavior a user can see, never on an internal record shape.
"""

from __future__ import annotations

from collections.abc import Callable

import pytest

import meta_evolve as meta


def _required(suite: str, name: str) -> str:
    return (
        f"{suite} needs a {name!r} fixture: override it in your subclass to "
        "point the suite at your proposer."
    )


def _task_reaching(expected: meta.SourceTree, seen: list[meta.SourceTree]) -> meta.Task:
    """One trial, scored purely on whether the proposer produced ``expected``.

    Deliberately free of any file-content convention: the seed scores 0 and a
    correct candidate scores 1, so any repository proposer can be measured
    without adopting this suite's idea of what a good tree looks like.
    """

    def evaluator(tree: meta.SourceTree) -> float:
        seen.append(tree)
        return 1.0 if tree == expected else 0.0

    return meta.Task(
        evaluator=evaluator,
        artifact=meta.SourceTree,
        objectives=(meta.Maximize("score"),),
        budget=meta.Budget(evaluations=2, trials=1),
    )


def _pull_access(max_operations: int) -> meta.PullAccess:
    return meta.PullAccess(
        max_operations=max_operations,
        max_results=10,
        max_records=20,
        max_chars=100_000,
    )


class RepositoryProposerTests:
    """What every repository-editing proposer owes a user of ``meta.run``.

    Subclass it, name the subclass ``Test...``, and override the fixtures::

        class TestMyProposer(RepositoryProposerTests):
            @pytest.fixture
            def proposer(self):
                return MyProposer(...)

            @pytest.fixture
            def seed(self):
                return meta.SourceTree({"value.txt": "1\\n"})

            @pytest.fixture
            def expected(self):
                return meta.SourceTree({"value.txt": "2\\n"})

            @pytest.fixture
            def expected_tokens(self):
                return 17
    """

    @pytest.fixture
    def proposer(self) -> Callable[..., object]:
        """A proposer that turns ``seed`` into ``expected`` in one trial."""

        raise NotImplementedError(_required("RepositoryProposerTests", "proposer"))

    @pytest.fixture
    def seed(self) -> meta.SourceTree:
        raise NotImplementedError(_required("RepositoryProposerTests", "seed"))

    @pytest.fixture
    def expected(self) -> meta.SourceTree:
        raise NotImplementedError(_required("RepositoryProposerTests", "expected"))

    @pytest.fixture
    def expected_tokens(self) -> int:
        """Tokens the provider reports for that one trial."""

        raise NotImplementedError(
            _required("RepositoryProposerTests", "expected_tokens")
        )

    @pytest.fixture
    def expected_spend_micros(self) -> int:
        """Charged spend the provider reports for that one trial; 0 when free."""

        return 0

    def test_edit_reaches_evaluation_and_reports_its_usage(
        self, proposer, seed, expected, expected_tokens, expected_spend_micros
    ) -> None:
        """The happy path, twice over on the same instance.

        One run proves nothing about the next: a proposer that works only on
        its first call — a consumed generator, a one-shot cache — passes any
        single-run law and dies in production on trial two. Two identical
        runs are the sample, not proof of unlimited reuse; a proposer that
        breaks from call three on is out of this law's reach.
        """

        for attempt in ("first", "second"):
            seen: list[meta.SourceTree] = []
            run = meta.run(
                task=_task_reaching(expected, seen),
                seed=seed,
                proposer=proposer,
                search=meta.Greedy(max_trials=1),
            )
            # Value first: a proposer that failed leaves the seed as the best
            # artifact, so every later assertion is only meaningful once the
            # winning artifact is known to be the proposed one.
            best = run.best()
            assert best.value == expected, (
                f"the proposed tree never reached storage on the {attempt} "
                "identical run; a proposer that only answers once dies on "
                "trial two"
            )
            assert seen[-1] == expected, (
                "the proposed tree never reached the evaluator"
            )
            assert best.parent_ids, "a proposed artifact must record its parent"

            trial = run.best_trial()
            assert trial.failure is None
            assert trial.usage.tokens == expected_tokens, (
                f"reported usage changed on the {attempt} identical run"
            )
            assert trial.usage.spend_micros == expected_spend_micros, (
                f"reported spend changed on the {attempt} identical run"
            )


class PullRepositoryProposerTests:
    """The same, for a proposer that reads prior experience under audit.

    Two proposers, because the two laws need different behavior from the same
    provider: one spends a read and declares what it derived from, the other
    spends the whole read budget first and declares anyway.
    """

    @pytest.fixture
    def proposer(self) -> Callable[..., object]:
        """Reads experience, declares its derivation, then edits the tree."""

        raise NotImplementedError(_required("PullRepositoryProposerTests", "proposer"))

    @pytest.fixture
    def read_exhausting_proposer(self) -> Callable[..., object]:
        """Spends its one granted read, is refused a second, declares anyway.

        The refusal is the point: it must arrive as a typed error on the read
        call rather than as a failed trial, and the derivation declared from
        the read it did get must still stand.
        """

        raise NotImplementedError(
            _required("PullRepositoryProposerTests", "read_exhausting_proposer")
        )

    @pytest.fixture
    def seed(self) -> meta.SourceTree:
        raise NotImplementedError(_required("PullRepositoryProposerTests", "seed"))

    @pytest.fixture
    def expected(self) -> meta.SourceTree:
        raise NotImplementedError(_required("PullRepositoryProposerTests", "expected"))

    @pytest.fixture
    def expected_tokens(self) -> int:
        raise NotImplementedError(
            _required("PullRepositoryProposerTests", "expected_tokens")
        )

    @pytest.fixture
    def expected_spend_micros(self) -> int:
        """Charged spend the provider reports for that one trial; 0 when free."""

        return 0

    def test_audited_pull_reaches_evaluation_and_records_the_derivation(
        self, proposer, seed, expected, expected_tokens, expected_spend_micros
    ) -> None:
        """The audited happy path, twice over on the same instance."""

        for attempt in ("first", "second"):
            seen: list[meta.SourceTree] = []
            run = meta.run(
                task=_task_reaching(expected, seen),
                seed=seed,
                proposer=proposer,
                search=meta.Greedy(max_trials=1),
                experience=_pull_access(2),
            )
            assert run.best().value == expected, (
                f"the proposed tree never reached storage on the {attempt} "
                "identical run; a proposer that only answers once dies on "
                "trial two"
            )
            assert seen[-1] == expected

            trial = run.best_trial()
            assert trial.failure is None
            assert trial.derived_from, (
                "a pulled read must be declared as a derivation"
            )
            assert trial.usage.tokens == expected_tokens
            assert trial.usage.spend_micros == expected_spend_micros
            assert run.experience_usage().pull.operations == 1, (
                "the one granted read must be accounted as exactly one operation"
            )

    def test_declaration_survives_a_spent_read_budget(
        self, read_exhausting_proposer, seed, expected
    ) -> None:
        seen: list[meta.SourceTree] = []
        run = meta.run(
            task=_task_reaching(expected, seen),
            seed=seed,
            proposer=read_exhausting_proposer,
            search=meta.Greedy(max_trials=1),
            experience=_pull_access(1),
        )
        assert run.best().value == expected, (
            "an exhausted read budget must refuse the read, not the candidate"
        )
        assert seen[-1] == expected

        trial = run.best_trial()
        assert trial.failure is None, "the refusal must not fail the trial"
        assert trial.derived_from, "the declaration must outlive the read budget"
        usage = run.experience_usage().pull
        # Two attempts are accounted for — the refusal is recorded, not
        # silently dropped — while only the one granted read returned records.
        assert usage.operations == 2, (
            "the refused second read must be accounted, not silently dropped"
        )
        assert usage.results == 1, (
            "only the one granted read returned records"
        )


__all__ = ["PullRepositoryProposerTests", "RepositoryProposerTests"]
