"""Executable ``WorkspaceProvider`` checks published as a subclassable suite.

*On length.* This module exceeds the repository's usual 300-line guideline
and is kept whole deliberately: it is one published class whose entire
interface is the fixtures and hooks its laws call, and the available split
would put a subclass author's overrides in a different file from the laws
that consume them.
"""

from __future__ import annotations

import pytest

from meta_evolve import SourceTree
from meta_evolve.ports import WorkspaceProvider
from meta_evolve.domain.values import canonical_payload_bytes


def _apply_edits(root, probe, edited_bytes, added_path, added_bytes, deleted_path):
    """The three edit kinds every capture law exercises together."""

    (root / probe).write_bytes(edited_bytes)
    added = root / added_path
    added.parent.mkdir(parents=True, exist_ok=True)
    added.write_bytes(added_bytes)
    (root / deleted_path).unlink()


def _required(name: str) -> str:
    return (
        f"WorkspaceProviderTests needs a {name!r} fixture: override it in your "
        "subclass to point the suite at your provider."
    )


class WorkspaceProviderTests:
    """What every workspace provider owes the code that runs inside it.

    Subclass it, name the subclass ``Test...``, and override one fixture::

        class TestMyWorkspaces(WorkspaceProviderTests):
            @pytest.fixture
            def provider(self, tmp_path):
                return MyWorkspaces(tmp_path)

    The remaining fixtures describe a tiny artifact and one edit to it. They
    default to a :class:`~meta_evolve.SourceTree`, which is the artifact type
    every shipped provider materializes; override them for a provider that
    materializes something else.
    """

    # --- what a subclass supplies ------------------------------------------

    @pytest.fixture
    def provider(self) -> WorkspaceProvider:
        """The provider under test."""

        raise NotImplementedError(_required("provider"))

    @pytest.fixture
    def artifact(self) -> object:
        """The artifact the suite materializes."""

        return SourceTree(
            {"pkg/value.py": "VALUE = 1\n", "pkg/doomed.py": "DOOMED = 1\n"}
        )

    @pytest.fixture
    def probe(self) -> str:
        """A path inside the workspace, relative to its root."""

        return "pkg/value.py"

    @pytest.fixture
    def probe_bytes(self) -> bytes:
        """What ``probe`` must contain once ``artifact`` is materialized."""

        return b"VALUE = 1\n"

    @pytest.fixture
    def edited_bytes(self) -> bytes:
        """Bytes the suite writes over ``probe`` to test capture."""

        return b"VALUE = 2\n"

    @pytest.fixture
    def added_path(self) -> str:
        """A path the suite creates inside the workspace, relative to root.

        Deliberately under a directory the artifact never declared: a capture
        that scans only directories present at materialization reports the
        replacement and misses everything created somewhere new.
        """

        return "generated/added.py"

    @pytest.fixture
    def added_bytes(self) -> bytes:
        """What the suite writes at ``added_path``."""

        return b"ADDED = 1\n"

    @pytest.fixture
    def deleted_path(self) -> str:
        """A declared path the suite deletes to test capture. It must exist
        in ``artifact`` and differ from ``probe``."""

        return "pkg/doomed.py"

    @pytest.fixture
    def edited_artifact(self) -> object:
        """What ``capture`` must return after the replace + add + delete.

        All three edit kinds in one artifact, because each is a distinct way
        for a capture to lose work: a capture that re-reads only the paths it
        materialized reports the replacement perfectly while dropping every
        new file and resurrecting every deleted one.
        """

        return SourceTree(
            {"pkg/value.py": "VALUE = 2\n", "generated/added.py": "ADDED = 1\n"}
        )

    @pytest.fixture
    def expected_paths(self) -> frozenset[str]:
        """Every path the materialized workspace may contain, relative to root.

        The default is the two files the default ``artifact`` declares. A
        provider that adds anything else — a config, a credential, a cache —
        is giving the code that runs inside authority nobody declared, and
        ``capture`` filtering it out again does not undo that.

        Scope: the law walks the ``workspace.root`` subtree only. Files a
        provider plants *beside* the root are outside what a workspace can
        promise about itself and are not observed here.
        """

        return frozenset({"pkg/value.py", "pkg/doomed.py"})

    # --- how the laws observe a captured artifact ---------------------------

    def artifact_state(self, artifact: object) -> bytes:
        """An inert projection of an artifact the capture laws compare.

        A captured object's own ``__eq__`` is the provider's to fake — even a
        correct-type artifact can lie with it. The default projects an exact
        :class:`~meta_evolve.SourceTree` to canonical payload bytes; any other
        artifact type must override this with its own inert projection.
        """

        if type(artifact) is SourceTree:
            return canonical_payload_bytes(artifact.to_payload())
        raise NotImplementedError(
            f"the default artifact_state() only knows exact SourceTree, not "
            f"{type(artifact).__name__}. Override artifact_state() to return "
            "canonical bytes of your artifact's content."
        )

    # --- the laws ----------------------------------------------------------

    def test_materialize_writes_the_artifact_under_an_absolute_root(
        self, provider, artifact, probe, probe_bytes
    ) -> None:
        workspace = provider.materialize(artifact)
        try:
            assert workspace.root.is_absolute()
            assert (workspace.root / probe).read_bytes() == probe_bytes
        finally:
            provider.dispose(workspace)

    def test_the_workspace_contains_only_what_the_artifact_declared(
        self, provider, artifact, expected_paths
    ) -> None:
        """Nothing arrives that the artifact did not ask for.

        Checked on disk rather than through ``capture``, because a provider
        that plants an extra file and filters it back out of ``capture`` still
        put it where the code inside can read it.
        """

        workspace = provider.materialize(artifact)
        try:
            root_is_link = workspace.root.is_symlink()
            resolved_root = workspace.root.resolve()
            entries = {
                path.relative_to(workspace.root).as_posix(): path
                for path in workspace.root.rglob("*")
                if path.is_file() or path.is_symlink()
            }
            links = sorted(
                relative
                for relative, path in entries.items()
                if path.is_symlink()
            )
            escapes = sorted(
                relative
                for relative, path in entries.items()
                if not path.resolve().is_relative_to(resolved_root)
            )
        finally:
            provider.dispose(workspace)

        assert not root_is_link, (
            "the workspace root is itself a symlink: the content lives "
            "wherever it points, and disposing the link is not disposing "
            "the workspace. (A symlinked ancestor directory is not checked "
            "— resolve your provider's base path before materializing.)"
        )
        found = frozenset(entries)
        undeclared = sorted(found - expected_paths)
        assert not undeclared, (
            f"the workspace holds files the artifact never declared: "
            f"{undeclared}. Code running inside can read them, whether or not "
            "capture() reports them."
        )
        assert not sorted(expected_paths - found), (
            f"the artifact declared paths the workspace does not hold: "
            f"{sorted(expected_paths - found)}"
        )
        assert not links, (
            f"the workspace holds symlinks: {links}. The suite refuses them "
            "outright — a link makes capture, containment, and disposal "
            "depend on what it points at (inside the root or out) rather "
            "than on what the workspace holds."
        )
        assert not escapes, (
            f"paths resolve outside the workspace root: {escapes}"
        )

    def test_round_trip_returns_an_unedited_artifact_unchanged(
        self, provider, artifact
    ) -> None:
        workspace = provider.materialize(artifact)
        try:
            captured = provider.capture(workspace)
            assert type(captured) is type(artifact), (
                f"capture() returned {type(captured).__name__}, not the "
                f"{type(artifact).__name__} it was given"
            )
            assert self.artifact_state(captured) == self.artifact_state(artifact), (
                "capture() of an unedited workspace does not reproduce the "
                "artifact that was materialized"
            )
        finally:
            provider.dispose(workspace)

    def test_two_workspaces_from_one_artifact_are_isolated(
        self,
        provider,
        artifact,
        probe,
        probe_bytes,
        edited_bytes,
        edited_artifact,
        added_path,
        added_bytes,
        deleted_path,
    ) -> None:
        """The law that makes parallel trials safe: no shared mutable ground.

        Editing one workspace must be invisible to the other, in the captured
        artifact as well as on disk — a provider that handed out the same
        directory twice would pass a content check and fail here.
        """

        first = provider.materialize(artifact)
        second = provider.materialize(artifact)
        try:
            assert first.root != second.root, (
                "two materializations shared one directory; concurrent trials "
                "would overwrite each other"
            )
            assert (first.root / probe).read_bytes() == probe_bytes
            assert (second.root / probe).read_bytes() == probe_bytes

            _apply_edits(
                first.root, probe, edited_bytes, added_path, added_bytes, deleted_path
            )

            captured_first = provider.capture(first)
            captured_second = provider.capture(second)
            assert type(captured_first) is type(edited_artifact), (
                f"capture() returned {type(captured_first).__name__}, not the "
                f"artifact type {type(edited_artifact).__name__}"
            )
            assert self.artifact_state(captured_first) == self.artifact_state(
                edited_artifact
            ), "capture() does not reflect the edit made in this workspace"
            assert type(captured_second) is type(artifact), (
                f"capture() returned {type(captured_second).__name__}, not the "
                f"artifact type {type(artifact).__name__}"
            )
            assert self.artifact_state(captured_second) == self.artifact_state(
                artifact
            ), (
                "the unedited workspace no longer captures its own artifact — "
                "either an edit leaked between the two directories, or "
                "capture() itself carries state shared across live workspaces"
            )
            assert (second.root / probe).read_bytes() == probe_bytes
        finally:
            # Disposal is checked here, not only in the single-workspace law
            # below: a provider can clean up correctly while it owns one
            # workspace and leak once two are live at the same time.
            provider.dispose(first)
            provider.dispose(second)
        assert not first.root.exists(), "a concurrently held workspace leaked"
        assert not second.root.exists(), "a concurrently held workspace leaked"

    def test_capture_sees_an_edit_made_inside_the_workspace(
        self,
        provider,
        artifact,
        probe,
        edited_bytes,
        edited_artifact,
        added_path,
        added_bytes,
        deleted_path,
    ) -> None:
        """One capture over all three edit kinds: replace, add, delete.

        Each is a distinct way to lose work. A capture that re-reads only the
        paths it materialized reports the replacement perfectly while
        dropping every file the code created and resurrecting every file it
        deleted.
        """

        workspace = provider.materialize(artifact)
        try:
            _apply_edits(
                workspace.root,
                probe,
                edited_bytes,
                added_path,
                added_bytes,
                deleted_path,
            )
            captured = provider.capture(workspace)
            assert type(captured) is type(edited_artifact), (
                f"capture() returned {type(captured).__name__}, not the "
                f"artifact type {type(edited_artifact).__name__}"
            )
            assert self.artifact_state(captured) == self.artifact_state(
                edited_artifact
            ), (
                "capture() does not reflect the edits made on disk — a "
                "replaced file, an added file, and a deleted file must all "
                "arrive in the captured artifact"
            )
        finally:
            provider.dispose(workspace)

    def test_dispose_removes_the_root_and_repeats_without_error(
        self, provider, artifact
    ) -> None:
        """Disposal is idempotent: cleanup runs on paths that already failed."""

        workspace = provider.materialize(artifact)
        provider.dispose(workspace)
        assert not workspace.root.exists()
        provider.dispose(workspace)
        assert not workspace.root.exists()


__all__ = ["WorkspaceProviderTests"]
