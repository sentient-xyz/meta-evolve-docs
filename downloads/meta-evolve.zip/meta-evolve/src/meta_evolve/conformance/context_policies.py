"""Executable ``ContextPolicy`` checks published as a subclassable suite.

A context policy decides what a proposer is allowed to see. The kernel already
refuses a bundle that breaks its bounds or reaches experience the candidate
could not have had — so a policy that violates those laws fails the run rather
than the assertion. What this suite adds is the part a raised error cannot
show: that the policy *did* select something, that what it selected is what the
proposer actually received and what replay reconstructs, and that it decides
the same way twice.

``NoMemory`` is not a subject here. It is the explicit spelling of the empty
default and ``meta.run`` normalizes it away before any policy runs, so there is
no declaration, no selection, and nothing for these laws to hold against.

``ContextPolicy.select`` receives the root-exported, read-only
``ExperienceGraph``. Policies form access-checked queries with the root-exported
``ExperienceQuery``; nodes, records, and historical state returned by the graph
are public read-only values as well.
"""

from __future__ import annotations

from collections.abc import Callable

import pytest

import meta_evolve as meta
from meta_evolve import domain
from meta_evolve import serialization
from meta_evolve.application import replay_run_projection
from meta_evolve.policies import ContextPolicy


def _required(name: str) -> str:
    return (
        f"ContextPolicyTests needs a {name!r} fixture: override it in your "
        "subclass to point the suite at your policy."
    )


def _evaluator(candidate):
    return candidate


class ContextPolicyTests:
    """What every context policy owes the proposer it feeds and the replay.

    Subclass it, name the subclass ``Test...``, and override one fixture::

        class TestAncestorsOnly(ContextPolicyTests):
            @pytest.fixture
            def policy(self):
                return meta.AncestorsOnly()

    The suite drives a three-trial integer search so there is prior experience
    to select from. A policy that needs a different shape of history can
    override ``search_factory``, ``budget``, and ``seed``.

    **What these laws do not cover.** Whether the selection matches the
    policy's *name* — a policy called "best-sibling" that returns ancestors
    selects lawfully and lies about everything else. Ranking and preference
    are semantics; test them directly with a history whose candidates differ,
    the way the shipped policies do in their own behavior tests.
    """

    # --- what a subclass supplies ------------------------------------------

    @pytest.fixture
    def policy(self) -> ContextPolicy:
        """The context policy under test."""

        raise NotImplementedError(_required("policy"))

    @pytest.fixture
    def seed(self) -> object:
        return 0

    @pytest.fixture
    def budget(self) -> meta.Budget:
        return meta.Budget(evaluations=4, trials=3)

    @pytest.fixture
    def expects_records(self) -> bool:
        """Whether this policy should select records under the run below.

        ``False`` declares that it honestly selects nothing here — legitimate,
        and recorded rather than passing silently.
        """

        return True

    @pytest.fixture
    def search_factory(self) -> Callable[..., object]:
        """``callable(proposer) -> SearchProgram``, invoked once per run.

        Named like :class:`SearchProgramTests`' fixture because it is the
        same shape: a factory, since a custom search must reference the same
        proposer the run authorized. Override it with a branching search for
        a policy that selects among siblings — the default is a linear chain,
        where a sibling policy has nothing to find.
        """

        return lambda proposer: meta.Greedy(max_trials=3)

    # --- shaping the run, for a policy that is not about integers -----------
    #
    # Methods rather than fixtures so that overriding them does not change any
    # law's signature, the same way ``ArtifactCodecTests.normalized`` works.

    def edit(self, parent: object) -> object:
        """Produce a child artifact from a parent. Default: the next integer."""

        return parent + 1

    def task(self, budget: meta.Budget) -> meta.Task:
        """The task the search runs. Override for a custom artifact type."""

        return meta.Task(evaluator=_evaluator, budget=budget)

    def registry(self) -> meta.Registry | None:
        """A ``Registry`` when ``task`` declares a custom artifact type."""

        return None

    # --- running the search -------------------------------------------------

    def execute(self, policy, seed, budget, search_factory):
        """One run, returned with its events and everything the proposer saw."""

        observed = []

        def propose(parent, *, context):
            observed.append(context)
            return self.edit(parent)

        registry = self.registry()
        storage = meta.Storage.in_memory()
        run = meta.run(
            task=self.task(budget),
            seed=seed,
            proposer=propose,
            search=search_factory(propose),
            context=policy,
            storage=storage,
            random_seed=7,
            **({} if registry is None else {"registry": registry}),
        )
        return run, storage.events.read(run.id), tuple(observed)

    def selections(self, events) -> tuple:
        return tuple(
            event.body
            for event in events
            if isinstance(event.body, domain.ContextSelected)
        )

    # --- the laws ----------------------------------------------------------

    def test_declares_a_policy_reference_and_its_bounds(self, policy) -> None:
        assert isinstance(policy.policy, domain.PolicyRef)
        assert isinstance(policy.max_records, int) and policy.max_records >= 0
        assert isinstance(policy.max_chars, int) and policy.max_chars >= 0

    def test_the_declaration_records_the_bounds_it_will_be_held_to(
        self, policy, seed, budget, search_factory
    ) -> None:
        run, events, _ = self.execute(policy, seed, budget, search_factory)
        projection = replay_run_projection(run.id, events)
        declaration = projection.context_declaration
        assert declaration is not None, "a non-default policy declares itself"
        assert declaration.spec.max_records == policy.max_records
        assert declaration.spec.max_chars == policy.max_chars

    def test_the_policy_is_asked_to_select(self, policy, seed, budget, search_factory) -> None:
        """A declared policy is consulted for every trial, and that is recorded."""

        run, events, _ = self.execute(policy, seed, budget, search_factory)
        selections = self.selections(events)
        assert selections, "the policy never ran: no selection was recorded"
        assert len(selections) == len(
            [trial for trial in run.trials() if not trial.metadata.get("bootstrap")]
        ), "a selection is recorded for every proposed trial"

    def test_the_policy_selects_records_when_it_says_it_will(
        self, policy, seed, budget, search_factory, expects_records
    ) -> None:
        """The vacuity guard, and why it is a declaration rather than a law.

        A policy that always returns an empty bundle satisfies "stays inside
        its bounds", "is strictly prior", and "selects identically twice"
        without ever selecting anything — every other law here holds
        vacuously. But an empty bundle is *legitimate*: the kernel accepts one,
        and a policy may honestly find nothing.

        So the suite asks you to say which you are. Leave ``expects_records``
        at its default and the run must produce something the proposer could
        use; set it to ``False`` and you have declared that this policy selects
        nothing under this history, which is recorded rather than assumed.

        If the failure surprises you, the usual cause is the scenario, not the
        policy: a sibling policy under the default linear search has no
        siblings to find. Override ``search`` to give it history it can use.
        """

        _, events, _ = self.execute(policy, seed, budget, search_factory)
        selected_records = any(
            selected.bundle.records for selected in self.selections(events)
        )
        if not expects_records:
            assert not selected_records, (
                "'expects_records' is False but the policy selected records; "
                "the declaration no longer matches the policy"
            )
            return
        assert selected_records, (
            "every bundle was empty, so every other law here holds vacuously. "
            "Either give the policy usable history through 'search_factory', "
            "or set "
            "'expects_records' to False to declare that it selects nothing."
        )

    def test_every_bundle_stays_inside_the_declared_bounds(
        self, policy, seed, budget, search_factory
    ) -> None:
        """Largely a kernel regression guard, and said so: ``ContextBundle``
        and the selection path validate bounds before anything commits, so a
        violating policy dies before these asserts see it. They keep the
        end-to-end failure and pin the committed usage numbers."""

        _, events, _ = self.execute(policy, seed, budget, search_factory)
        for selected in self.selections(events):
            usage = selected.bundle.usage
            assert usage.records <= policy.max_records
            assert usage.chars <= policy.max_chars
            assert usage.records == len(selected.bundle.records)
            assert usage.chars == len(selected.bundle.rendered)

    def test_every_selected_record_precedes_the_trial_it_was_selected_for(
        self, policy, seed, budget, search_factory
    ) -> None:
        """A proposer may not be shown its own trial, or anything after it."""

        run, events, _ = self.execute(policy, seed, budget, search_factory)
        steps = {trial.id: trial.logical_step for trial in run.trials()}
        for selected in self.selections(events):
            limit = steps[selected.trial_id]
            for record in selected.bundle.records:
                assert record.logical_step < limit, (
                    "selected context is not strictly prior to its trial"
                )

    def test_the_bundle_the_proposer_saw_is_the_bundle_that_was_committed(
        self, policy, seed, budget, search_factory
    ) -> None:
        """The one law a kernel rejection cannot cover: no divergence between
        what was recorded for the audit and what the proposer was handed."""

        _, events, observed = self.execute(policy, seed, budget, search_factory)
        committed = [selected.bundle for selected in self.selections(events)]
        assert [context.bundle for context in observed] == committed

    def test_two_runs_of_the_same_policy_select_identically(
        self, policy, seed, budget, search_factory
    ) -> None:
        """Two whole runs of one policy instance record identical events.

        The shared instance is what makes this bite: state accumulating
        *across* runs makes the second run record differently. What it cannot
        see is a per-call cycle that repeats identically in both runs, and
        per-call purity is deliberately out of scope — replay loads committed
        bundles and never re-invokes ``select()``, so the committed record,
        not re-selection, is the durable truth. Events are compared as
        canonical serialized bytes, which are exact-type: a lying subclass of
        a durable record fails to serialize rather than slipping through its
        own ``__eq__``.
        """

        first_run, first_events, _ = self.execute(policy, seed, budget, search_factory)
        second_run, second_events, _ = self.execute(policy, seed, budget, search_factory)
        assert first_run.id == second_run.id, (
            "two runs of the same policy produced different run identities"
        )
        assert serialization.dumps(first_events) == serialization.dumps(
            second_events
        ), (
            "two runs of the same policy recorded different events; the "
            "usual cause is selection state accumulating across runs"
        )

    def test_replay_reconstructs_every_committed_bundle(
        self, policy, seed, budget, search_factory
    ) -> None:
        run, events, _ = self.execute(policy, seed, budget, search_factory)
        projection = replay_run_projection(run.id, events)
        for selected in self.selections(events):
            assert projection.context_for(selected.trial_id) == selected.bundle


__all__ = ["ContextPolicyTests"]
