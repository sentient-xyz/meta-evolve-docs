"""Published executable checks for typed mutation surfaces.

A mutation surface applies exactly the change it was asked for, refuses
everything else with a typed ``InvalidOutput``, and never edits itself — it
returns a successor. The laws observe successors through
:meth:`MutationSurfaceTests.surface_state`, an inert canonical-bytes
projection, rather than the surface's own ``__eq__``, which the surface could
lie with.
"""

from __future__ import annotations

import dataclasses
from typing import Any

import pytest

from meta_evolve.conformance._inert import inert_projection
from meta_evolve.domain import ComponentRef, InvalidOutput
from meta_evolve.domain.values import canonical_payload_bytes
from meta_evolve.mutation import MutationApplication, MutationSurface


def _required(fixture: str, what: str) -> str:
    return (
        f"MutationSurfaceTests needs a {fixture!r} fixture: override it in "
        f"your subclass to supply {what}."
    )


class MutationSurfaceTests:
    """Conformance laws shared by all schema-owned mutation surfaces.

    Subclass it, name the subclass ``Test...``, and override the fixtures::

        class TestMySurface(MutationSurfaceTests):
            @pytest.fixture
            def surface(self):
                return MyParam(value="old")

            @pytest.fixture
            def mutations(self):
                return (
                    (MyMutation("my_param", "first new value"),
                     MyParam(value="first new value")),
                    (MyMutation("my_param", "second new value"),
                     MyParam(value="second new value")),
                )

            @pytest.fixture
            def no_op_mutation(self):
                return MyMutation("my_param", "old")       # the current value

            @pytest.fixture
            def foreign_mutation(self):
                return MyMutation("someone-else", "value")  # not this surface

            @pytest.fixture
            def invalid_mutations(self):
                return (MyMutation("my_param", 123),)       # values it refuses

    ``mutations`` pairs each mutation with the exact successor it must
    produce. Give one pair per distinct accepted value **where the domain
    allows** — a surface that special-cases one value and substitutes its own
    for the rest passes a single pair; only variety exposes it. A two-value
    domain (``ParentSelection``) has exactly one valid change from any state,
    and one pair is then complete, not lazy.

    ``invalid_mutations`` holds representative invalid *values* that must be
    refused with a typed ``InvalidOutput``. Mutations of the wrong Python
    type are out of scope: the mutation records themselves reject those with
    ``TypeError`` at construction, before any surface is consulted.

    **What these laws do not cover.** ``no_op_mutation`` and
    ``foreign_mutation`` are samples of one; a surface that mishandles only
    some no-op or foreign requests can pass. ``surface_state`` observes what
    the surface's dataclass fields hold — state kept outside fields (class
    attributes, external stores) is invisible to it.
    """

    # --- what a subclass supplies ------------------------------------------

    @pytest.fixture
    def surface(self) -> MutationSurface[Any, Any]:
        """The surface under test, in its starting state."""

        raise NotImplementedError(_required("surface", "the surface under test"))

    @pytest.fixture
    def mutations(self) -> tuple[tuple[Any, MutationSurface[Any, Any]], ...]:
        """Non-empty tuple of ``(mutation, expected_successor)`` pairs."""

        raise NotImplementedError(
            _required(
                "mutations",
                "(mutation, expected successor) pairs — one per distinct "
                "accepted value where the domain allows",
            )
        )

    @pytest.fixture
    def no_op_mutation(self) -> Any:
        """A mutation carrying the surface's current value."""

        raise NotImplementedError(
            _required("no_op_mutation", "a mutation carrying the current value")
        )

    @pytest.fixture
    def foreign_mutation(self) -> Any:
        """A mutation addressed to a different surface name."""

        raise NotImplementedError(
            _required("foreign_mutation", "a mutation naming another surface")
        )

    @pytest.fixture
    def invalid_mutations(self) -> tuple[Any, ...]:
        """Non-empty tuple of mutations whose values the surface refuses."""

        raise NotImplementedError(
            _required(
                "invalid_mutations",
                "representative invalid values the surface must refuse",
            )
        )

    # --- how the laws observe a surface ------------------------------------

    def surface_state(self, surface: MutationSurface[Any, Any]) -> bytes:
        """An inert projection of ``surface`` the laws compare instead of eq.

        Canonical bytes of the surface's dataclass fields, read directly with
        ``getattr`` — never through ``dataclasses.asdict``, whose deepcopy
        would consult a field's own ``__deepcopy__`` and let the field choose
        its projection. Only exact canonical and kernel value types are
        accepted; anything else raises and asks for an override rather than
        being trusted.
        """

        if not dataclasses.is_dataclass(surface):
            raise NotImplementedError(
                f"{type(surface).__name__} is not a dataclass, so the default "
                "surface_state() cannot observe it. Override surface_state() "
                "to return canonical bytes of your surface's value."
            )
        try:
            return canonical_payload_bytes(inert_projection(surface))
        except (TypeError, ValueError) as error:
            raise NotImplementedError(
                f"{type(surface).__name__} holds a field the inert projection "
                "refuses ({error}); the default surface_state() will not "
                "trust that field's own copy or equality. Override "
                "surface_state() with an inert projection.".format(error=error)
            ) from error

    # --- the laws ----------------------------------------------------------

    def test_declares_stable_name_component_and_interface(self, surface) -> None:
        assert (
            isinstance(surface.name, str)
            and surface.name
            and surface.name == surface.name.strip()
        ), "a surface declares a non-blank, unpadded name"
        assert type(surface.component) is ComponentRef, (
            f"surface.component is {type(surface.component).__name__}; resume "
            "rebuilds the implementation from this reference, so it must be "
            "exactly a ComponentRef"
        )
        assert (
            isinstance(surface.interface, str)
            and surface.interface
            and surface.interface == surface.interface.strip()
        ), "a surface declares a non-blank, unpadded interface"

    def test_valid_change_preserves_authority(self, surface, mutations) -> None:
        assert mutations, "the suite proves nothing against an empty 'mutations'"
        before = self.surface_state(surface)
        for mutation, expected in mutations:
            result = surface.apply(mutation)
            assert isinstance(result, MutationApplication)
            assert result.failure is None, (
                f"a valid mutation was refused: {result.failure}"
            )
            assert result.surface is not None
            assert type(result.surface) is type(surface), (
                "the successor changed type; a surface's schema is fixed"
            )
            assert result.surface.name == surface.name
            assert result.surface.component == surface.component
            assert result.surface.interface == surface.interface
            state = self.surface_state(result.surface)
            assert state == self.surface_state(expected), (
                "the successor does not hold the value this mutation should "
                "produce; a mutation surface applies what it is given, it "
                "does not choose"
            )
            assert state != before, "a successor equal to its parent is a no-op"
            assert self.surface_state(surface) == before, (
                "apply() changed the surface it was called on; a mutation "
                "surface returns a successor and leaves itself alone"
            )

    def test_repeated_application_is_deterministic(self, surface, mutations) -> None:
        assert mutations, "the suite proves nothing against an empty 'mutations'"
        before = self.surface_state(surface)

        def observed(application):
            if application.surface is None:
                return (None, application.failure)
            return (self.surface_state(application.surface), application.failure)

        for mutation, _expected in mutations:
            assert observed(surface.apply(mutation)) == observed(
                surface.apply(mutation)
            ), (
                "applying the same mutation twice gave two different results; "
                "a surface may not carry state across applications"
            )
            assert self.surface_state(surface) == before, (
                "apply() changed the surface it was called on"
            )

    def test_no_op_is_typed_invalid_output(self, surface, no_op_mutation) -> None:
        before = self.surface_state(surface)
        result = surface.apply(no_op_mutation)
        assert isinstance(result.failure, InvalidOutput), (
            f"a no-op mutation produced {type(result.failure).__name__}; "
            "refusals are typed InvalidOutput, never another failure kind"
        )
        assert result.surface is None, "a refusal carries no successor"
        assert self.surface_state(surface) == before, (
            "apply() changed the surface it was called on"
        )

    def test_foreign_surface_is_typed_invalid_output(
        self, surface, foreign_mutation
    ) -> None:
        before = self.surface_state(surface)
        result = surface.apply(foreign_mutation)
        assert isinstance(result.failure, InvalidOutput), (
            f"a mutation for another surface produced "
            f"{type(result.failure).__name__}; refusals are typed InvalidOutput"
        )
        assert result.surface is None, "a refusal carries no successor"
        assert self.surface_state(surface) == before, (
            "apply() changed the surface it was called on"
        )

    def test_invalid_value_is_typed_invalid_output(
        self, surface, invalid_mutations
    ) -> None:
        assert invalid_mutations, (
            "the suite proves nothing against an empty 'invalid_mutations'"
        )
        before = self.surface_state(surface)
        for mutation in invalid_mutations:
            result = surface.apply(mutation)
            assert isinstance(result.failure, InvalidOutput), (
                f"an invalid value produced {type(result.failure).__name__}; "
                "refusals are typed InvalidOutput, never another failure kind"
            )
            assert result.surface is None, "a refusal carries no successor"
            assert self.surface_state(surface) == before, (
                "apply() changed the surface it was called on"
            )


__all__ = ["MutationSurfaceTests"]
