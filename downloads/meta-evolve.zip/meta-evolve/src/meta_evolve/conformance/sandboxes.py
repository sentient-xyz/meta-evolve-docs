"""Executable ``SandboxProvider`` checks published as a subclassable suite.

The laws are about *confinement*, not convenience: a process sees the working
directory it asked for, the environment it declared and nothing else, its
arguments uninterpreted, and its two output streams kept apart. A provider that
leaked the ambient environment or handed argv to a shell would still run a test
command successfully — these checks are what tell the two apart.

*On length.* Slightly over the usual 300-line guideline and kept whole: one
published class whose interface is the fixtures and hooks its laws call.
"""

from __future__ import annotations

import os
import sys
from collections.abc import Iterator

import pytest

from meta_evolve import SourceTree
from meta_evolve.domain import ResourceExhausted, TimeoutFailure
from meta_evolve.ports import ProcessSpec, SandboxProvider, Workspace, WorkspaceProvider


_REPORT = (
    "import os, sys\n"
    "print(os.getcwd())\n"
    "print(os.environ.get('DECLARED'))\n"
    "print(sys.argv[1])\n"
    "print('separate', file=sys.stderr)\n"
    # Written into the declared cwd: the disk-read of this file is the one
    # positive observation of execution that does not come from the
    # sandbox's own ProcessResult.
    "with open('executed.txt', 'w') as proof:\n"
    "    proof.write(os.environ.get('DECLARED', ''))\n"
)

# Prints the whole environment the process was given, one NAME=value per line.
# A Python probe rather than /usr/bin/env so the suite runs anywhere the
# interpreter does, and so every command really is ``sys.executable``.
_ENVIRONMENT = (
    "import os\n"
    "for name in sorted(os.environ):\n"
    "    print(f'{name}={os.environ[name]}')\n"
)

# Portable interpreter probes: no shell, platform-specific executable, signal,
# or filesystem timing assumption.  The sleep duration is passed by the suite
# so container and remote providers can widen the timing separation.
_TIMEOUT = (
    "import sys, time\n"
    "print('stdout-before-timeout', flush=True)\n"
    "print('stderr-before-timeout', file=sys.stderr, flush=True)\n"
    "time.sleep(float(sys.argv[1]))\n"
)

_OUTPUT = (
    "import sys\n"
    "stream, payload = sys.argv[1:]\n"
    "target = getattr(sys, stream).buffer\n"
    "target.write(payload.encode('ascii'))\n"
    "target.flush()\n"
)

_OUTPUT_PAYLOAD = "bounded-output"
_OUTPUT_LIMIT = 6

# A single argument that a shell would expand three ways: command
# substitution, statement separation, and globbing.
_SHELL_BAIT = "$(touch escaped); *.py"

# Set only in the running test process, so its appearance in a child proves
# the sandbox forwarded the ambient environment.
_AMBIENT = "META_EVOLVE_CONFORMANCE_AMBIENT"

# Default for the ``interpreter_added`` fixture: what CPython adds to a child
# it launches. Not evidence of a leaking sandbox.
_INTERPRETER_ADDED = frozenset({"LC_CTYPE", "__CF_USER_TEXT_ENCODING"})


def _required(name: str) -> str:
    return (
        f"SandboxProviderTests needs a {name!r} fixture: override it in your "
        "subclass to point the suite at your sandbox."
    )


class SandboxProviderTests:
    """What every sandbox owes the process it runs and the run that reads it.

    Subclass it, name the subclass ``Test...``, and override two fixtures::

        class TestMySandbox(SandboxProviderTests):
            @pytest.fixture
            def sandbox(self):
                return MySandbox()

            @pytest.fixture
            def workspaces(self, tmp_path):
                return DirectoryWorkspaces(tmp_path)

    The suite needs a workspace provider because a sandbox is only meaningful
    against a materialized workspace; that provider is assumed to satisfy
    :class:`~meta_evolve.conformance.workspaces.WorkspaceProviderTests`
    already. Every command runs ``interpreter`` against a script the suite
    wrote, so nothing here depends on the host's shell or PATH.

    The resource-boundary laws require enforcement of timeout and independent
    raw-byte stdout/stderr limits, retain the bounded output observed before a
    timeout or overflow, and reserve sandbox usage for non-negative wall time.
    ``timeout_seconds`` and ``sleep_seconds`` are overridable fixtures because
    process startup costs differ for local, container, and remote providers.

    **What these laws do not cover.** There is **no filesystem
    confinement law**: a passing sandbox is not proof the process cannot read
    or write outside the workspace root (the shipped development sandbox reads
    the host filesystem freely and passes the suite). Execution evidence
    is one disk-read of a probe-written file — it refutes report-only
    fabrication, not simulation: a sandbox that parses the spec and writes
    the expected file without spawning anything stays indistinguishable. The
    suite also does not prescribe CPU, memory, network, syscall, or process-tree
    isolation beyond the declared timeout and captured-output boundaries.
    """

    #: How to invoke Python *inside* the sandbox. The host's ``sys.executable``
    #: only works for a sandbox that shares this filesystem; override it for a
    #: container or remote provider, e.g. ``("python3",)``.
    interpreter: tuple[str, ...] = (sys.executable,)

    # --- what a subclass supplies ------------------------------------------

    @pytest.fixture(scope="class", autouse=True)
    @classmethod
    def ambient_canary(cls):
        """Put the canary in the environment before anything else is built.

        Class-scoped and autouse so it is set up before the function-scoped
        ``sandbox`` fixture: a provider that snapshots ``os.environ`` in its
        constructor and forwards that snapshot has to capture the canary too,
        which is exactly the leak the environment law looks for.
        """

        previous = os.environ.get(_AMBIENT)
        os.environ[_AMBIENT] = "leaked"
        yield
        if previous is None:
            os.environ.pop(_AMBIENT, None)
        else:
            os.environ[_AMBIENT] = previous

    @pytest.fixture
    def sandbox(self) -> SandboxProvider:
        """The sandbox under test."""

        raise NotImplementedError(_required("sandbox"))

    @pytest.fixture
    def workspaces(self) -> WorkspaceProvider:
        """A conforming workspace provider to run inside."""

        raise NotImplementedError(_required("workspaces"))

    @pytest.fixture
    def interpreter_added(self) -> frozenset[str]:
        """Variable names your ``interpreter`` adds to a child on its own.

        These are not evidence of a leaking sandbox. CPython adds ``LC_CTYPE``
        and, on macOS, ``__CF_USER_TEXT_ENCODING``. Narrow or widen it for a
        different interpreter — but every name here is one the environment law
        stops checking, so add only what you have confirmed.

        The exemption is by name, not by value: a sandbox that forwards the
        parent's ``LC_CTYPE`` rather than letting the interpreter set its own
        is indistinguishable here. Keep the set as small as your interpreter
        actually requires.
        """

        return _INTERPRETER_ADDED

    @pytest.fixture
    def timeout_seconds(self) -> float:
        """Timeout used by the enforcement probe.

        One second leaves ordinary local startup comfortably outside the
        scheduling-noise range. Remote providers may override it upward.
        """

        return 1.0

    @pytest.fixture
    def sleep_seconds(self) -> float:
        """Probe sleep, deliberately well beyond ``timeout_seconds``."""

        return 5.0

    @pytest.fixture
    def workspace(self, workspaces: WorkspaceProvider) -> Iterator[Workspace]:
        """One materialized workspace holding the suite's probe scripts."""

        source = SourceTree(
            {
                "nested/check.py": _REPORT,
                "environment.py": _ENVIRONMENT,
                "exit.py": "import sys\nsys.exit(7)\n",
                "timeout.py": _TIMEOUT,
                "output.py": _OUTPUT,
            }
        )
        materialized = workspaces.materialize(source)
        yield materialized
        workspaces.dispose(materialized)

    # --- the laws ----------------------------------------------------------

    def test_process_sees_its_declared_directory_environment_and_arguments(
        self, sandbox, workspace
    ) -> None:
        """The spec's three promises, plus independent evidence of execution.

        Every field of ``ProcessResult`` is the sandbox's own report, so the
        law also reads a file the probe wrote from disk — a report-only
        fabrication fails there. Stated plainly: this verifies the declared
        *observable effects*, not execution itself. A sandbox that simulates
        the probe — parses the spec and writes the nonce file without
        spawning anything — is indistinguishable in-process, and writing one
        file is cheap. What the law buys is that fabrication must now track
        the probe's behavior, so it breaks the moment the probe does more.
        """

        nonce = os.urandom(8).hex()
        result = sandbox.run(
            ProcessSpec(
                argv=(*self.interpreter, "check.py", _SHELL_BAIT),
                cwd="nested",
                environment={"DECLARED": nonce},
            ),
            workspace,
        )

        assert result.failure is None, (
            f"a plain command failed at the boundary: {result.failure}"
        )
        assert result.exit_code == 0
        assert result.stdout.splitlines() == [
            str(workspace.root / "nested"),
            nonce,
            _SHELL_BAIT,
        ], (
            "the process did not see its declared cwd, environment value, and "
            "verbatim argument — the three things a spec promises it"
        )
        proof = workspace.root / "nested" / "executed.txt"
        assert proof.exists() and proof.read_text() == nonce, (
            "no independent evidence the process ran: the probe writes its "
            "DECLARED value into the workspace, and this law reads that file "
            "from disk rather than trusting the sandbox's own report"
        )

    def test_arguments_are_never_interpreted_by_a_shell(
        self, sandbox, workspace
    ) -> None:
        """The bait argument arrives verbatim and its side effect never happens."""

        sandbox.run(
            ProcessSpec(
                argv=(*self.interpreter, "check.py", _SHELL_BAIT),
                cwd="nested",
                environment={"DECLARED": "exact"},
            ),
            workspace,
        )
        assert not (workspace.root / "nested" / "escaped").exists(), (
            "the argument reached a shell: its command substitution ran"
        )

    def test_output_streams_stay_separate(self, sandbox, workspace) -> None:
        result = sandbox.run(
            ProcessSpec(
                argv=(*self.interpreter, "check.py", _SHELL_BAIT),
                cwd="nested",
                environment={"DECLARED": "exact"},
            ),
            workspace,
        )
        assert result.stderr == "separate\n", (
            "stderr did not arrive on its own stream"
        )
        assert "separate" not in result.stdout, (
            "stderr leaked into stdout; merged streams corrupt what an "
            "evaluator reads"
        )

    def test_a_nonzero_exit_is_reported_as_an_exit_code_not_a_failure(
        self, sandbox, workspace
    ) -> None:
        """A failing command is a result to evaluate, not a broken sandbox."""

        result = sandbox.run(
            ProcessSpec(argv=(*self.interpreter, "exit.py")),
            workspace,
        )
        assert result.exit_code == 7
        assert result.failure is None, (
            "a nonzero exit is a result to evaluate, not a boundary failure: "
            f"{result.failure}"
        )

    def test_no_ambient_environment_variable_reaches_the_process(
        self, sandbox, workspace, interpreter_added
    ) -> None:
        """The declared environment is the whole environment.

        An exact boundary, not "no parent name reached the child". Comparing
        against the parent's *names* leaves two holes: a provider can copy a
        parent value under a different name, and a remote or container host has
        ambient variables whose names do not exist here at all. So the child's
        keys must be exactly what was declared, plus whatever ``interpreter``
        itself adds — which is why that set is a fixture you can correct rather
        than a constant baked in here.
        """

        result = sandbox.run(
            ProcessSpec(
                argv=(*self.interpreter, "environment.py"),
                environment={"ONLY_DECLARED": "yes"},
            ),
            workspace,
        )
        assert result.exit_code == 0
        assert result.stderr == ""

        reported = dict(
            line.split("=", 1) for line in result.stdout.splitlines() if "=" in line
        )
        assert reported.get("ONLY_DECLARED") == "yes", "the declared value did not arrive"

        undeclared = sorted(set(reported) - {"ONLY_DECLARED"} - set(interpreter_added))
        assert not undeclared, (
            f"the child was given variables the spec never declared: {undeclared}. "
            "The declared environment is the whole environment. If your "
            "interpreter legitimately adds one of these, name it in the "
            "'interpreter_added' fixture instead of letting it pass unnoticed."
        )
        # Redundant once the boundary above holds, and deliberately kept: it
        # names the ambient-forwarding failure directly, and it is the check
        # that still bites if a subclass widens 'interpreter_added' too far.
        assert _AMBIENT not in reported, (
            f"{_AMBIENT} was set only in the parent and reached the child; the "
            "sandbox is passing the ambient environment through"
        )

    def test_timeout_is_enforced_and_preserves_bounded_partial_output(
        self, sandbox, workspace, timeout_seconds, sleep_seconds
    ) -> None:
        """A deadline is a typed boundary outcome, with prior output retained."""

        assert sleep_seconds > timeout_seconds, (
            "'sleep_seconds' must exceed 'timeout_seconds' so the timeout law "
            "actually reaches the declared deadline"
        )
        result = sandbox.run(
            ProcessSpec(
                argv=(*self.interpreter, "timeout.py", str(sleep_seconds)),
                timeout_seconds=timeout_seconds,
                stdout_limit=100,
                stderr_limit=100,
            ),
            workspace,
        )

        assert isinstance(result.failure, TimeoutFailure), (
            "a process that outlived its declared timeout did not return a "
            f"TimeoutFailure: {result.failure}"
        )
        assert result.exit_code is None
        assert result.stdout == "stdout-before-timeout\n", (
            "stdout observed before the deadline was not preserved exactly"
        )
        assert result.stderr == "stderr-before-timeout\n", (
            "stderr observed before the deadline was not preserved exactly"
        )

    @pytest.mark.parametrize(
        ("stream", "other"), (("stdout", "stderr"), ("stderr", "stdout"))
    )
    def test_stream_byte_limits_are_independent_and_preserve_bounded_output(
        self, sandbox, workspace, stream, other
    ) -> None:
        """Each stream has its own byte ceiling and retains only its prefix."""

        limits = {"stdout_limit": 100, "stderr_limit": 100}
        limits[f"{stream}_limit"] = _OUTPUT_LIMIT
        result = sandbox.run(
            ProcessSpec(
                argv=(*self.interpreter, "output.py", stream, _OUTPUT_PAYLOAD),
                **limits,
            ),
            workspace,
        )

        assert isinstance(result.failure, ResourceExhausted), (
            f"overflowing {stream} did not return ResourceExhausted: "
            f"{result.failure}"
        )
        assert result.exit_code is None
        retained = getattr(result, stream)
        assert retained == _OUTPUT_PAYLOAD[:_OUTPUT_LIMIT], (
            f"{stream} did not preserve exactly the bounded prefix"
        )
        assert len(retained.encode("utf-8")) <= _OUTPUT_LIMIT
        assert getattr(result, other) == "", (
            f"overflowing {stream} contaminated or consumed the independent "
            f"{other} stream"
        )

    def test_usage_reports_only_non_negative_wall_time(
        self, sandbox, workspace
    ) -> None:
        """A sandbox measures occurrence time, not kernel-owned work counts."""

        result = sandbox.run(
            ProcessSpec(argv=(*self.interpreter, "exit.py")),
            workspace,
        )
        assert result.usage.evaluations == 0
        assert result.usage.trials == 0
        assert result.usage.tokens == 0
        assert result.usage.spend_micros == 0
        assert result.usage.wall_seconds >= 0


__all__ = ["SandboxProviderTests"]
