"""One inert projection shared by the suites that refuse subject equality.

``inert_projection`` reads a value into canonical primitives without running
any code the subject could have supplied: exact canonical types pass through,
exact kernel value types project through kernel code, dataclasses recurse
field by field with ``getattr``. Anything else raises ``TypeError`` — each
caller converts that into a ``NotImplementedError`` asking the author for an
override, so an unrecognized type is never silently trusted.

Exact types only, everywhere: a subclass of ``str`` or ``tuple`` could route
the projection through its own ``__eq__``/``__deepcopy__``; a subclass of
``SourceTree`` or ``Text`` could override the kernel methods used here.
"""

from __future__ import annotations

import dataclasses
import inspect
import types

from meta_evolve.domain.source_tree import SourceTree
from meta_evolve.domain.text import Text


def _field(value: object, name: str) -> object:
    """Read one dataclass field without running the subject's code.

    ``inspect.getattr_static`` never invokes ``__getattribute__`` or a
    descriptor: it hands back the instance-dict value, or for a slots class
    the member descriptor, whose ``__get__`` is C code the subject cannot
    override. Anything else backing the field — a property, a shadowing
    class attribute with ``__get__`` — is refused.
    """

    static = inspect.getattr_static(value, name)
    if type(static) is types.MemberDescriptorType:
        return static.__get__(value, type(value))
    if inspect.isdatadescriptor(static) or inspect.isfunction(static):
        raise TypeError(f"field {name!r} is backed by a descriptor")
    return static


def inert_projection(value: object) -> object:
    if type(value) in (type(None), bool, int, float, str, bytes):
        return value
    if type(value) is tuple:
        return tuple(inert_projection(item) for item in value)
    if type(value) is dict:
        return {
            key: inert_projection(item)
            for key, item in value.items()
            if type(key) is str or _reject_key(key)
        }
    if type(value) is SourceTree:
        return ("SourceTree", value.to_payload())
    if type(value) is Text:
        return ("Text", str.__str__(value))
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return (
            type(value).__qualname__,
            {
                field.name: inert_projection(_field(value, field.name))
                for field in dataclasses.fields(value)
            },
        )
    raise TypeError(f"non-canonical value of type {type(value).__name__}")


def _reject_key(key: object) -> bool:
    raise TypeError(f"non-string mapping key of type {type(key).__name__}")


__all__ = ["inert_projection"]
