"""The cohort oracle, driven through a dispatcher: inline, or over a socketpair.

`cohorts.barrier_view` completes a generation's members by calling the
builders directly. This drives the same generation through the production
path instead -- a distributed run, a `Dispatcher`, a lease per item, the one
completion path -- with its completions claimed in `order` by the
dispatcher's `claim_order` hook (design SD3). One item at a time, the earliest
remaining `(member, kind)` in `order` is always claimable when it is owed, and
one that is not owed never appears as a row, so every interleaving the direct
path reaches is reached here, with the same skips.

`backend="inline"` runs each call on the inline endpoint; `"socketpair"` runs
it on a `distributed.worker.serve` thread across a real socketpair, so every
input and result crosses the wire codec. The two streams must be byte-equal:
that is the proof the wire loses nothing (T14, first half).

A distributed run needs durable storage, so `storage` must build one.
"""

from __future__ import annotations

import socket
import threading
from collections.abc import Callable, Sequence

import meta_evolve as meta
from meta_evolve import domain
from meta_evolve.adapters import (
    CallableEvaluator,
    CallableProposer,
    DecodedValueProposerRunner,
)
from meta_evolve.application.bootstrap import start_run
from meta_evolve.application.codecs import CodecIndex
from meta_evolve.application.coordinator import SequentialCoordinator
from meta_evolve.application.decisions import commit_cohort
from meta_evolve.application.dispatcher import Dispatcher, ManualClock
from meta_evolve.application.executors import (
    LocalEvaluationExecutor,
    LocalProposalExecutor,
)
from meta_evolve.application.search_preparation import prepare_search
from meta_evolve.domain.search import rank_evaluations
from meta_evolve.domain.work import WorkKind
from meta_evolve.domain.workers import WorkerId, WorkerRegistration

BACKENDS = ("inline", "socketpair")

#: A fixed fingerprint: the run records one, and nothing here compares it.
_FINGERPRINT = "meta-evolve/environment/v1:" + "0" * 64


def dispatched_barrier_view(
    program,
    width: int,
    order: Sequence[tuple[int, str]],
    *,
    backend: str,
    storage: Callable[[], meta.Storage],
    budget: meta.Budget | None = None,
    propose: Callable | None = None,
    evaluate: Callable | None = None,
):
    """`barrier_view`'s answer, reached through a dispatcher on `backend`."""

    from .cohorts import _evaluate, _propose

    if backend not in BACKENDS:
        raise ValueError(f"backend must be one of {BACKENDS}, not {backend!r}")
    built_storage = storage()
    if not built_storage.is_durable:
        raise ValueError("a dispatched barrier needs durable storage: pass a durable factory")
    propose = propose or _propose
    evaluate = evaluate or _evaluate
    coordinator, prepared = _distributed(program, budget, built_storage, propose, evaluate)
    if prepared.cohort_width != width:
        raise ValueError(
            f"the program declares cohort width {prepared.cohort_width}, not {width}"
        )

    return barrier_through(
        coordinator,
        prepared,
        order,
        dispatcher_for=lambda claim_order: _dispatcher(
            coordinator, backend, claim_order=claim_order
        ),
    )


def barrier_through(coordinator, prepared, order, *, dispatcher_for):
    """One generation, driven to its barrier by whatever dispatcher is given.

    Shared by every backend, because the BARRIER is the thing under test: the
    order completions are claimed in, the generation the policy asks for next,
    and the ranking. What differs between backends is only where the component
    ran, which is exactly what `dispatcher_for` decides.
    """

    from .cohorts import EVALUATION, PROPOSAL, BarrierView

    rank: dict[tuple[str, WorkKind], int] = {}
    kinds = {PROPOSAL: WorkKind.PROPOSAL, EVALUATION: WorkKind.EVALUATION}
    dispatcher, closing = dispatcher_for(
        lambda row: rank.get((row.trial_id.value, row.kind), -1)
    )
    try:
        _drain(dispatcher)  # the bootstrap evaluation
        committed = commit_cohort(
            coordinator,
            prepared.program,
            prepared.program.next_cohort(coordinator.projection.search_state),
        )
        trials = [
            item.record.trial_id.value
            for item in committed
            if isinstance(item.record.decision, domain.TrialSpec)
        ]
        for position, (member, kind) in enumerate(order):
            if member < len(trials):
                rank.setdefault((trials[member], kinds[kind]), position)
        _drain(dispatcher)
    finally:
        closing()

    state = coordinator.projection.search_state
    if coordinator.projection.stop is not None:
        following, recorded = (), ()
    else:
        following = prepared.program.next_cohort(state)
        recorded = commit_cohort(coordinator, prepared.program, following)
    objective = coordinator.task.objectives[0]
    ranked = rank_evaluations(
        objective, [item.evaluation for item in coordinator.projection.completed_evaluations]
    )
    return BarrierView(
        state=state,
        next_cohort=tuple(following),
        recorded=tuple(item.record.decision for item in recorded),
        ranking=tuple(item.artifact_id for item in ranked),
        winner=ranked[0].artifact_id if ranked else None,
        run_id=coordinator.run_id,
        events=tuple(coordinator.events.read(coordinator.run_id)),
    )


def _drain(dispatcher: Dispatcher) -> None:
    while dispatcher.drain_once() or dispatcher.reclaim():
        pass


def _distributed(program, budget, storage, propose, evaluate):
    proposer = CallableProposer(propose)
    codecs = CodecIndex.builtin()
    task = domain.Task(
        evaluator=evaluate, budget=budget or meta.Budget(evaluations=12, trials=12)
    )
    if not hasattr(program, "next") and callable(program):
        program = program(propose)
    prepared = prepare_search(program, proposer=proposer.component, budget=task.budget)
    coordinator = SequentialCoordinator(
        run_id=domain.RunId("run-cohort-conformance"),
        task_id=domain.TaskId("task-cohort-conformance"),
        task=task,
        run_budget=task.budget,
        random_seed=13,
        search=prepared.spec,
        proposer_runner=DecodedValueProposerRunner(proposer, proposer.component, codecs),
        proposer_ref=proposer.component,
        evaluator=CallableEvaluator(evaluate, task.objectives),
        storage=storage,
        codecs=codecs,
        capabilities=domain.RunCapabilities(
            mode="distributed",
            resumable=False,
            component_manifests=tuple(
                domain.ComponentManifest(
                    role=role, name=f"conformance:{role}", version="1",
                    import_hint="conformance", implementation_digest="d",
                    configuration_digest="", deterministic=True, retry_safe=True,
                )
                for role in ("proposer", "evaluator", "policy")
            ),
            environment_fingerprint=_FINGERPRINT,
        ),
    )
    start_run(coordinator, 0, context_spec=None, experience_spec=None)
    return coordinator, prepared


def _dispatcher(coordinator, backend: str, *, claim_order):
    broker = coordinator.work_broker()
    coordinator.fence.install(broker.rollover(coordinator.run_id))
    clock = ManualClock(1_000)
    if backend == "inline":
        dispatcher = Dispatcher(coordinator, broker, clock=clock, claim_order=claim_order)
        return dispatcher, dispatcher.close

    from meta_evolve.distributed.wire import WireEndpoint
    from meta_evolve.distributed.worker import serve

    host, peer = socket.socketpair()
    endpoint = WireEndpoint(
        host,
        registration=WorkerRegistration(
            worker=WorkerId.for_slot(coordinator.run_id, 0),
            generation=1,
            max_concurrent_leases=1,
            environment_fingerprint=_FINGERPRINT,
        ),
        clock=clock,
    )
    worker = threading.Thread(
        target=serve,
        args=(peer,),
        kwargs=dict(
            evaluation=LocalEvaluationExecutor(coordinator.evaluator, coordinator.codecs),
            proposal=LocalProposalExecutor(
                coordinator.proposer_runner, coordinator.codecs, coordinator.task
            ),
        ),
        name="meta-evolve-conformance-worker",
        daemon=True,
    )
    worker.start()
    dispatcher = Dispatcher(
        coordinator, broker, clock=clock, claim_order=claim_order, endpoints=(endpoint,)
    )

    def closing() -> None:
        dispatcher.close()
        worker.join(timeout=5)
        peer.close()

    return dispatcher, closing


__all__ = ["BACKENDS", "dispatched_barrier_view"]
