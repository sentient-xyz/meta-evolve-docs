"""Executable ``ArtifactCodec`` checks published as a subclassable suite.

*On length.* This module exceeds the repository's usual 300-line guideline
and is kept whole deliberately: it is one published class whose entire
interface is the fixtures and hooks its laws call, and the available split
would put a subclass author's overrides in a different file from the laws
that consume them.
"""

from __future__ import annotations

import builtins
import io
import socket

import pytest

from meta_evolve.application.codecs import CodecIndex
from meta_evolve.conformance._inert import inert_projection
from meta_evolve.domain.identity import ArtifactId
from meta_evolve.domain.trial import Artifact
from meta_evolve.domain.values import canonical_payload_bytes
from meta_evolve.ports.codecs import ArtifactCodec
from meta_evolve.registry_support import validate_artifact_codec


def _required(name: str) -> str:
    return (
        f"ArtifactCodecTests needs a {name!r} fixture: override it in your "
        "subclass to point the suite at your codec."
    )


class ArtifactCodecTests:
    """Executable checks for :class:`~meta_evolve.ports.codecs.ArtifactCodec`.

    Subclass it, name the subclass ``Test...``, and override five fixtures —
    plus the ``mutate`` method if any of your values is mutable, and the
    ``value_state`` method if your values are types the default inert
    projection refuses::

        class TestRecipeCodec(ArtifactCodecTests):
            @pytest.fixture
            def codec(self):
                return RecipeCodec()

            @pytest.fixture
            def values(self):
                return (Recipe(("preheat",)), Recipe(()))

            @pytest.fixture
            def rejected_values(self):
                return ("not a recipe", 7)

            @pytest.fixture
            def rejected_payloads(self):
                return (("not", "steps"), 7)   # malformed stored payloads

            @pytest.fixture
            def mutable_values(self):
                return ()          # Recipe is frozen; nothing to alias

    ``rejected_values``, ``rejected_payloads``, and ``mutable_values`` have no
    defaults on purpose. Refusing a foreign value with ``TypeError``/
    ``ValueError`` is a law, and a codec that never demonstrates a refusal has
    not been checked against it; decode is validation, so a codec that never
    demonstrates refusing a malformed payload has not been checked against
    corruption; whether a decoded value can be edited in place decides whether
    handing the same instance back is harmless or a corruption path, and only
    its author knows. ``()`` is an answer, and it is a claim.
    """

    # --- what a subclass supplies ------------------------------------------

    @pytest.fixture
    def codec(self) -> ArtifactCodec:
        """The codec under test."""

        raise NotImplementedError(_required("codec"))

    @pytest.fixture
    def values(self) -> tuple[object, ...]:
        """Representative values the codec accepts, including the edge cases."""

        raise NotImplementedError(_required("values"))

    @pytest.fixture
    def rejected_values(self) -> tuple[object, ...]:
        """Values the codec must refuse, one per reason it refuses."""

        raise NotImplementedError(_required("rejected_values"))

    @pytest.fixture
    def rejected_payloads(self) -> tuple[object, ...]:
        """Malformed stored payloads ``decode`` must refuse — ``()`` if none.

        "Decode is validation": payloads arrive from storage, not from this
        process's ``encode``, and corruption is a data-integrity event the
        codec is the last to see. Like ``rejected_values`` this has no
        default; ``()`` is a positive claim that every payload decodes.
        """

        raise NotImplementedError(_required("rejected_payloads"))

    @pytest.fixture
    def mutable_values(self) -> tuple[object, ...]:
        """Accepted values that can be modified in place — ``()`` if none can.

        Like ``rejected_values``, this has no default on purpose. Whether your
        decoded values can be edited by whoever receives them decides whether
        aliasing them is harmless or a corruption path, and the suite cannot
        work that out for you. Returning ``()`` is a claim that your values are
        immutable, not a way to skip the question.

        The law cannot simply be applied to everything: the built-in
        python-value codec decodes a small integer to the very same interned
        object, and for an immutable value sharing is both harmless and
        unavoidable.
        """

        raise NotImplementedError(_required("mutable_values"))

    def value_state(self, value: object) -> object:
        """An inert projection of a value — how every value law observes.

        No law compares values with ``==``: for a third-party codec the value
        type usually ships with the codec, so its ``__eq__`` is the subject's
        own code and could certify a collapse (every value equal to every
        other). The laws also never observe through ``encode`` — the codec
        could special-case the objects being watched.

        The default reads exact canonical types, exact kernel value types
        (``SourceTree``, ``Text``, ``FrozenMap``), and dataclass fields via
        ``getattr``; any other type raises and asks for an override the codec
        has no hand in::

            def value_state(self, value):
                return tuple(value.steps)
        """

        try:
            return inert_projection(value)
        except TypeError as error:
            raise NotImplementedError(
                f"{type(value).__name__} holds state the inert projection "
                f"refuses ({error}); the laws will not trust the value's own "
                "equality. Override value_state() with an inert projection."
            ) from error

    def mutate(self, value: object) -> None:
        """Edit ``value`` in place. Only called for ``mutable_values``.

        Outer identity is not independence: a codec can wrap the very list it
        was handed in a fresh object and pass every identity check. Editing a
        decoded value and looking at what else changed is the only way to see
        that, and only you know how to edit your type::

            def mutate(self, value):
                value.steps.append("extra")
        """

        raise NotImplementedError(
            "ArtifactCodecTests needs a 'mutate' method whenever "
            "'mutable_values' is non-empty: override it to edit a decoded "
            "value in place, so the suite can check that nothing else changed."
        )

    def normalized(self, value: object) -> object:
        """What ``decode(encode(value))`` must equal, and the type it must be.

        Defaults to the value itself — the exact round trip. Override it only
        for a codec whose decode returns a normalized form: ``python-value``
        returns ``freeze(value)``, so a plain ``dict`` comes back as a
        ``FrozenMap``, and ``text`` returns a ``Text`` for any ``str``.
        """

        return value

    # --- the laws ----------------------------------------------------------

    def test_declares_kind_representation_and_interfaces(self, codec) -> None:
        validate_artifact_codec(codec)
        assert codec.kind, "kind must name the schema, not be blank"
        assert codec.representation, "representation must name the bytes"
        # "decode is validation — there is no separate validate method": a
        # second entry point for the same question is a second authority.
        assert not hasattr(codec, "validate")

    def test_value_round_trip_holds_up_to_normalization(self, codec, values) -> None:
        assert values, "the suite proves nothing against an empty 'values'"
        for value in values:
            decoded = codec.decode(codec.encode(value))
            expected = self.normalized(value)
            # Type, not only equality: ``Text`` is a ``str`` subclass with
            # plain string equality, so a codec that returned the raw payload
            # would satisfy ``==`` while dropping the declared type.
            assert type(decoded) is type(expected), (
                f"decode returned {type(decoded).__name__}, expected "
                f"{type(expected).__name__} for {value!r}"
            )
            assert self.value_state(decoded) == self.value_state(expected), (
                f"decode(encode({value!r})) does not hold the expected state; "
                "observed through value_state(), never the value's own "
                "equality, which the codec's value type could lie with"
            )

    def test_payload_round_trip_is_exact(self, codec, values) -> None:
        # Canonical bytes on both sides: every storable payload must already
        # serialize (the digest is payload-derived), and payload equality
        # itself would run whatever __eq__ the payload objects carry.
        for value in values:
            payload = codec.encode(value)
            assert canonical_payload_bytes(
                codec.encode(codec.decode(payload))
            ) == canonical_payload_bytes(payload)

    def test_repeated_calls_are_stable_within_one_process(self, codec, values) -> None:
        for value in values:
            first = codec.encode(value)
            second = codec.encode(value)
            assert canonical_payload_bytes(first) == canonical_payload_bytes(
                second
            ), f"encode is not stable for {value!r}"
            assert self.value_state(codec.decode(first)) == self.value_state(
                codec.decode(second)
            ), f"decode is not stable for {value!r}"

    def test_common_file_and_socket_entry_points_are_not_used(
        self, codec, values, monkeypatch
    ) -> None:
        def forbidden(*arguments: object, **keywords: object) -> object:
            pytest.fail("a codec used a common file or socket I/O entry point")

        # These are tripwires for common I/O paths, not a proof that arbitrary
        # code is pure. ``pytest.fail`` raises a ``BaseException`` so a codec's
        # own ``except Exception`` cannot swallow the report.
        monkeypatch.setattr(builtins, "open", forbidden)
        monkeypatch.setattr(io, "open", forbidden)
        monkeypatch.setattr(socket, "socket", forbidden)
        for value in values:
            codec.decode(codec.encode(value))

    def test_rejection_is_signalled_by_type_or_value_error(
        self, codec, rejected_values
    ) -> None:
        assert rejected_values, "a codec must demonstrate what it refuses"
        for value in rejected_values:
            try:
                codec.encode(value)
            except (TypeError, ValueError):
                continue
            except Exception as error:  # noqa: BLE001 - the point of the law
                pytest.fail(
                    f"encode({value!r}) raised {type(error).__name__}. A codec "
                    "signals rejection with TypeError or ValueError; any other "
                    "exception is a codec bug and propagates as a real error."
                )
            pytest.fail(f"encode({value!r}) returned instead of refusing the value")

    def test_a_malformed_payload_is_rejected_by_decode(
        self, codec, rejected_payloads
    ) -> None:
        """Decode is validation — a corrupt payload is refused, not repaired.

        Every other law hands ``decode`` a payload this process's ``encode``
        just produced; this is the only one that feeds it what storage
        corruption or a foreign writer would.
        """

        if not rejected_payloads:
            pytest.skip(
                "no 'rejected_payloads': decode validation was not exercised. "
                "Declaring () is a claim that every payload decodes."
            )
        for payload in rejected_payloads:
            try:
                codec.decode(payload)
            except (TypeError, ValueError):
                continue
            except Exception as error:  # noqa: BLE001 - the point of the law
                pytest.fail(
                    f"decode({payload!r}) raised {type(error).__name__}. A "
                    "codec signals a malformed payload with TypeError or "
                    "ValueError; any other exception is a codec bug."
                )
            pytest.fail(
                f"decode({payload!r}) returned instead of refusing a payload "
                "this codec's encode could never have produced"
            )

    def test_decoding_a_mutable_value_does_not_hand_back_the_original(
        self, codec, mutable_values
    ) -> None:
        """A codec must not retain what it encoded and return it later.

        Nothing stops a codec from keeping the object it was given and handing
        that same instance to ``decode``. Every other law here still passes:
        they check that ``decode`` returns an *equal* value, never an
        independent one. The consequence is not local — the evaluator then
        receives the caller's own object and can edit an artifact nobody
        proposed, which is why
        :class:`~meta_evolve.conformance.evaluators.EvaluatorTests` keeps a
        mutation law that looks redundant under the built-in codecs.
        """

        if not mutable_values:
            pytest.skip(
                "no 'mutable_values': the aliasing law was not exercised. "
                "Declaring () is a claim that your decoded values are "
                "immutable."
            )
        for value in mutable_values:
            payload = codec.encode(value)
            decoded = codec.decode(payload)
            assert decoded is not value, (
                f"decode handed back the object it encoded for {value!r}; the "
                "caller still holds it, so whatever edits the decoded value "
                "edits the caller's artifact too"
            )
            other = codec.decode(payload)
            assert other is not decoded, (
                f"two decodes of {value!r} share one object; editing an "
                "artifact would change every other decode of that payload"
            )

            # Outer identity proves nothing about what is inside: a codec can
            # wrap the caller's own list in a fresh object and pass both
            # checks above. Editing is the only way to see it, so the
            # subclass performs one. Observations go through the author's
            # value_state(), never through encode(): the codec is the subject
            # under test, and an encode that special-cases the watched
            # objects could certify the very aliasing this law exists to
            # catch.
            before_mutation = self.value_state(decoded)
            before_original = self.value_state(value)
            before_other = self.value_state(other)
            self.mutate(decoded)
            assert self.value_state(decoded) != before_mutation, (
                "mutate() did not change the value's state; a no-op mutate "
                "would disable this law. Edit a field value_state() observes."
            )
            assert self.value_state(value) == before_original, (
                f"editing a decoded value changed the caller's {value!r}; "
                "decode shares mutable state with what it was handed"
            )
            assert self.value_state(other) == before_other, (
                f"editing one decode of {value!r} changed another; two decodes "
                "of the same payload share mutable state"
            )

    def test_payload_is_identity_free_and_decodes_through_the_index(
        self, codec, values
    ) -> None:
        """The payload decodes through the index the kernel actually uses.

        ``CodecIndex`` is where the kernel reaches a codec. Note that built-in
        ``(kind, representation)`` keys are not overridable, so a codec that
        collides with one is resolved to the built-in and fails here.

        The digest comparison below is weaker than it looks and is kept as a
        regression guard, not as evidence about your codec: ``encode`` is
        called once and the one payload is placed in two artifacts, so equal
        digests are a fact about ``Artifact``. A codec is never handed an
        identity in the first place — that exclusion is structural to the
        ``encode``/``decode`` signatures, not something this test could catch.
        """

        index = CodecIndex.with_extras({(codec.kind, codec.representation): codec})
        for value in values:
            payload = codec.encode(value)
            common = {
                "payload": payload,
                "kind": codec.kind,
                "representation": codec.representation,
            }
            first = Artifact(
                id=ArtifactId("conformance-first"),
                provenance={"trial": "first"},
                **common,
            )
            second = Artifact(
                id=ArtifactId("conformance-second"),
                parent_ids=(first.id,),
                provenance={"trial": "second"},
                **common,
            )
            assert first.digest == second.digest, (
                "kernel regression guard, not a codec property: Artifact "
                "derives digests from the payload alone, and a codec is "
                "never handed an identity to vary with"
            )
            decoded = index.decode(first)
            expected = self.normalized(value)
            assert type(decoded) is type(expected)
            assert self.value_state(decoded) == self.value_state(expected), (
                f"decoding {value!r} through the CodecIndex the kernel uses "
                "does not reproduce the expected state"
            )


__all__ = ["ArtifactCodecTests"]
