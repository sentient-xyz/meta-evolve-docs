"""Decoded-value proposer and evaluator contracts for local execution."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Protocol

from meta_evolve.domain.evaluation import (
    Failure,
    _FAILURE_TYPES,
    _validate_evidence_fields,
    _validate_metrics,
    _validate_uncertainty,
)
from meta_evolve.domain.experience import ExperienceRef
from meta_evolve.domain.resources import Resources
from meta_evolve.domain.values import (
    FrozenMap,
    _freeze_map_field,
    _require_text,
)

from .proposers import Proposer


_MISSING = object()


def _validate_failure(value: object) -> Failure | None:
    if value is not None and type(value) not in _FAILURE_TYPES:
        raise TypeError("result failure must be a typed Failure")
    return value


def _validate_evidence(values: object) -> tuple[EvidenceDraft, ...]:
    try:
        evidence = tuple(values)  # type: ignore[arg-type]
    except TypeError as error:
        raise TypeError("result evidence must contain EvidenceDraft values") from error
    if not all(isinstance(item, EvidenceDraft) for item in evidence):
        raise TypeError("result evidence must contain EvidenceDraft values")
    return evidence


@dataclass(frozen=True, slots=True, kw_only=True)
class EvidenceDraft:
    """An observation attached to a proposal or evaluation before commitment.

    Attach these to result records. Recording evidence does not automatically
    show it to a proposer; configure experiment feedback explicitly.

    :param kind: Non-empty label, such as ``"test-case"``.
    :param data: JSON-like observation fields, copied into an immutable mapping.
    :param uri: Optional non-empty reference string; it is not fetched or verified.
    """

    kind: str
    data: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    uri: str | None = None

    def __post_init__(self) -> None:
        kind, data, uri = _validate_evidence_fields(self.kind, self.data, self.uri)
        object.__setattr__(self, "kind", kind)
        object.__setattr__(self, "data", data)
        object.__setattr__(self, "uri", uri)


@dataclass(frozen=True, slots=True, kw_only=True)
class ProposalResult:
    """A normalized candidate or typed proposer failure.

    ``candidate`` is a value in the task's artifact type, not a durable
    payload: the registered codec is the one authority for that translation,
    and it runs where the task's kind and representation are known.

    Plain proposers can return the candidate directly. Use this record when
    reporting usage, observations, or a failure from ``meta_evolve.domain``.

    Malformed records raise ``TypeError`` or ``ValueError`` on construction.
    During a run, ordinary exceptions raised inside a proposer become typed
    proposer failures; capability and infrastructure errors can abort the run.

    :param candidate: Required for success; even ``None`` can be a valid value.
        The displayed ``_MISSING`` default means omitted. Omit this argument
        entirely when supplying ``failure``.
    :param failure: Typed proposer or shared failure, such as ``ProposerFailure``
        or ``InvalidOutput``. A failure cannot also carry a candidate.
    :param hypothesis: Optional non-empty explanation of the proposed change.
    :param predicted_outcomes: Optional JSON-like predictions, not evaluator scores.
    :param metadata: Optional JSON-like proposal metadata, frozen on construction.
    :param evidence: Tuple of [EvidenceDraft][meta_evolve.EvidenceDraft] observations.
    :param usage: [Resources][meta_evolve.Resources], defaulting to known free work. Report unknown
        bills explicitly with ``Resources(spend_micros=None)``. Engine-owned trial and evaluation
        fields are not accepted.
    :param derived_from: Unique authorized prior ``ExperienceRef`` values, in
        declared order; empty by default. Recording a reference grants no access.
    """

    candidate: object = field(default=_MISSING)
    failure: Failure | None = None
    hypothesis: str | None = None
    predicted_outcomes: FrozenMap | Mapping[str, object] = field(
        default_factory=FrozenMap
    )
    metadata: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    evidence: tuple[EvidenceDraft, ...] = ()
    usage: Resources = Resources()
    derived_from: tuple[ExperienceRef, ...] = ()

    def __post_init__(self) -> None:
        failure = _validate_failure(self.failure)
        if failure is None:
            if self.candidate is _MISSING:
                raise ValueError("a successful proposal result requires a candidate")
        else:
            if self.candidate is not _MISSING:
                raise ValueError("a failed proposal result cannot carry a candidate")
            object.__setattr__(self, "candidate", None)
        if self.hypothesis is not None:
            _require_text(self.hypothesis, "proposal hypothesis")
        _freeze_map_field(self, "predicted_outcomes")
        _freeze_map_field(self, "metadata")
        object.__setattr__(self, "evidence", _validate_evidence(self.evidence))
        if not isinstance(self.usage, Resources):
            raise TypeError("proposal result usage must be Resources")
        if not isinstance(self.derived_from, tuple) or any(
            not isinstance(item, ExperienceRef) for item in self.derived_from
        ):
            raise TypeError("proposal result derivation must contain ExperienceRefs")
        if len(set(self.derived_from)) != len(self.derived_from):
            raise ValueError("proposal result derivation references must be unique")


@dataclass(frozen=True, slots=True, kw_only=True)
class EvaluationResult:
    """Independent measurements or a typed failure, plus evidence and usage.

    Successful metrics must cover the task objectives. A failed measurement
    has no rankable metrics. Return this explicitly to attach evidence,
    uncertainty, tokens, monetary spend, or elapsed usage; plain evaluators may
    return a scalar or metric mapping when no extra observations are needed.

    Invalid field shapes raise ``TypeError`` or ``ValueError`` on construction.
    Missing task metrics are detected during execution as ``InvalidOutput``.
    Ordinary exceptions inside the evaluator become typed evaluator failures;
    capability and infrastructure exceptions can abort execution. Inspect
    [Run.trials()][meta_evolve.Run.trials] for measurements and failure records.

    :param metrics: Non-empty mapping of metric names to finite real numbers
        for success. Booleans, NaN, and infinity are rejected. Every task
        objective must be present; extra metrics are retained. Omit on failure.
    :param failure: Typed evaluator or shared failure from ``meta_evolve.domain``.
        Supplying both a failure and metrics raises ``ValueError``.
    :param uncertainty: Optional named non-negative finite numeric estimates;
        retained as observations, not used automatically for ranking.
    :param evidence: Tuple of [EvidenceDraft][meta_evolve.EvidenceDraft] observations.
    :param usage: Action resources; defaults to [Resources()][meta_evolve.Resources],
        meaning known free work. Components report tokens, spend, and elapsed
        time. Failure usage still counts; trial/evaluation fields are not accepted.
    """

    metrics: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    failure: Failure | None = None
    uncertainty: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)
    evidence: tuple[EvidenceDraft, ...] = ()
    usage: Resources = Resources()

    def __post_init__(self) -> None:
        metrics = _validate_metrics(self.metrics)
        failure = _validate_failure(self.failure)
        if failure is None and not metrics:
            raise ValueError("a successful evaluation result requires metrics")
        if failure is not None and metrics:
            raise ValueError("a failed evaluation result cannot carry rankable metrics")
        object.__setattr__(self, "metrics", metrics)
        object.__setattr__(self, "uncertainty", _validate_uncertainty(self.uncertainty))
        object.__setattr__(self, "evidence", _validate_evidence(self.evidence))
        if not isinstance(self.usage, Resources):
            raise TypeError("evaluation result usage must be Resources")


class Evaluator(Protocol):
    def evaluate(self, candidate: object) -> EvaluationResult: ...


__all__ = [
    "EvaluationResult",
    "Evaluator",
    "EvidenceDraft",
    "ProposalResult",
    "Proposer",
]
