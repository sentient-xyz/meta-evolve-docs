"""Worker enrolment ports and the decisions shared by their adapters.

Readers expose get/all; operator authority adds trust/revoke. Adapters read
the existing row, apply the decision, and store its result atomically.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import replace
from typing import Protocol, runtime_checkable

from meta_evolve.domain.values import canonical_payload_bytes
from meta_evolve.domain.workers import (
    MALFORMED_WORKER_ID,
    RESERVED_WORKER_ID,
    TrustedWorker,
    TrustStatus,
    WorkerId,
    WorkerRegistration,
    is_valid_worker_id,
)
from meta_evolve.errors import WorkerNotTrusted


class InvalidTrustedWorker(ValueError):
    """An operator's command that violates the registry's rules."""

    def __init__(self, worker: WorkerId, reason: str) -> None:
        self.worker = worker
        self.reason = reason
        super().__init__(f"invalid registry command for worker {worker}: {reason}")


class TrustedWorkerReader(Protocol):
    """Reading the allow-list: one worker's row, or every row."""

    def get(self, worker: WorkerId) -> TrustedWorker | None: ...

    def all(self) -> tuple[TrustedWorker, ...]:
        """Every row, trusted and revoked, ordered by worker id in every adapter."""
        ...


class TrustedWorkers(TrustedWorkerReader, Protocol):
    """The allow-list an operator writes. One row per worker per store (AD1)."""

    def trust(
        self, worker: WorkerId, capabilities: Mapping[str, object]
    ) -> TrustedWorker: ...

    def revoke(self, worker: WorkerId) -> TrustedWorker: ...


@runtime_checkable
class TrustedWorkerSource(Protocol):
    """Optional storage capability providing an enrolment reader."""

    def trusted_workers(self) -> TrustedWorkerReader:
        """This store's allow-list, readable and no more, whatever the store may do."""
        ...


@runtime_checkable
class TrustedWorkerAuthority(Protocol):
    """Optional storage capability providing enrolment write authority."""

    def trusted_worker_authority(self) -> TrustedWorkers:
        """Return the operator's writable registry."""
        ...


#: What a host is handed: a lookup through a reader, never the port (PD5). Where
#: it reads from is pinned by `test_trust_lookup_handoff.py`, not by this type.
TrustLookup = Callable[[WorkerId], TrustedWorker | None]

#: The answer to every narrowing: dropping a key and changing a value share it.
REVOKE_FIRST = (
    "a trusted worker's declaration is only widened; revoke it first to drop or "
    "change one"
)


def decide_trust(
    existing: TrustedWorker | None,
    worker: WorkerId,
    capabilities: Mapping[str, object],
) -> TrustedWorker:
    """Enrol at generation 1, re-trust at the revoked generation, or widen.

    Trusted rows may only gain keys; revoking first permits replacement of the
    whole declaration.
    """

    _refuse_malformed(worker)
    _refuse_reserved(worker)
    if existing is None:
        return TrustedWorker(
            worker=worker,
            generation=1,
            status=TrustStatus.TRUSTED,
            capabilities=capabilities,
        )
    if existing.status is not TrustStatus.TRUSTED:
        return existing.retrusted(capabilities)
    _refuse_narrowing(existing, worker, capabilities)
    return replace(existing, capabilities=capabilities)


def _refuse_narrowing(
    existing: TrustedWorker,
    worker: WorkerId,
    capabilities: Mapping[str, object],
) -> None:
    """Require every existing key at the same canonical value.

    Canonical equality distinguishes booleans from numbers and compares stored
    arrays with the tuples accepted in declarations.
    """

    dropped = sorted(key for key in existing.capabilities if key not in capabilities)
    if dropped:
        raise InvalidTrustedWorker(
            worker, f"the declaration drops {', '.join(dropped)}; {REVOKE_FIRST}"
        )
    changed = sorted(
        key
        for key, value in existing.capabilities.items()
        if canonical_payload_bytes(capabilities[key]) != canonical_payload_bytes(value)
    )
    if changed:
        raise InvalidTrustedWorker(
            worker, f"the declaration changes {', '.join(changed)}; {REVOKE_FIRST}"
        )


def decide_revocation(
    existing: TrustedWorker | None, worker: WorkerId
) -> TrustedWorker:
    """Revoke an existing row; repeated revocation keeps its generation."""

    _refuse_malformed(worker)
    _refuse_reserved(worker)
    if existing is None:
        raise InvalidTrustedWorker(
            worker, "nothing is enrolled under that id, so nothing is revocable"
        )
    return existing.revoked()


def refuse_untrusted(registration: WorkerRegistration, honoured: int | None) -> None:
    """Refuse a claim whose generation the store no longer honours.

    The broker supplies the generation read inside its transaction. None covers
    both absent and revoked enrolments.
    """

    worker = registration.worker.value
    if honoured is None:
        raise WorkerNotTrusted(
            worker,
            reason="this store trusts no such worker -- never enrolled, or revoked",
        )
    if registration.generation != honoured:
        raise WorkerNotTrusted(
            worker,
            reason=(
                f"it presented generation {registration.generation}, and this "
                f"store honours generation {honoured}"
            ),
        )


def _refuse_malformed(worker: WorkerId) -> None:
    """An id outside the grammar: `WorkerId(...)` does not check it, and one
    row the SQLite decoder rejects would break `all()` for the whole store."""

    if not is_valid_worker_id(worker.value):
        raise InvalidTrustedWorker(worker, MALFORMED_WORKER_ID)


def _refuse_reserved(worker: WorkerId) -> None:
    """An id a dispatcher mints has no row to write and none to revoke (AD3).

    Refused here, typed, because `revoke` reaches no `TrustedWorker` constructor.
    """

    if worker.is_dispatcher_minted:
        raise InvalidTrustedWorker(worker, RESERVED_WORKER_ID)


__all__ = [
    "REVOKE_FIRST",
    "InvalidTrustedWorker",
    "TrustLookup",
    "TrustedWorkerAuthority",
    "TrustedWorkerReader",
    "TrustedWorkerSource",
    "TrustedWorkers",
    "decide_revocation",
    "decide_trust",
    "refuse_untrusted",
]
