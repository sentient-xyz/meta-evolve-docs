"""Public declaration and scoped reader protocols for pull experience."""

from __future__ import annotations

from typing import Protocol

from meta_evolve.domain.experience import ExperienceRef
from meta_evolve.domain.experience_access import (
    ExperienceComparison,
    ExperienceObservation,
    ExperienceSpec,
)
from meta_evolve.domain.source_access import SourceDiff, SourcePathListing, SourceRead


class ExperienceAccess(Protocol):
    """A run-level declaration that normalizes to one durable access spec."""

    def experience_spec(self) -> ExperienceSpec: ...


class ExperienceReader(Protocol):
    """A bounded read capability supplied to successor proposers.

    History queries and exact source listing, reads, and diffs observe only
    authorized prior occurrences. Operations are recorded and charged against
    the grant. Denied access and exhausted bounds raise typed exceptions;
    reading a record grants no authority to change it.
    """

    def search(
        self,
        *,
        record_kinds: object = (),
        failure_kinds: object = (),
        as_of: int | None = None,
        limit: int | None = None,
    ) -> ExperienceObservation: ...

    def open(
        self, ref: ExperienceRef, *, as_of: int | None = None
    ) -> ExperienceObservation: ...

    def ancestors(
        self,
        trial_ref: ExperienceRef,
        *,
        as_of: int | None = None,
        limit: int | None = None,
    ) -> ExperienceObservation: ...

    def siblings(
        self,
        trial_ref: ExperienceRef,
        *,
        as_of: int | None = None,
        limit: int | None = None,
    ) -> ExperienceObservation: ...

    def compare(
        self,
        left_trial_ref: ExperienceRef,
        right_trial_ref: ExperienceRef,
        *,
        as_of: int | None = None,
    ) -> ExperienceComparison: ...

    def list_source_paths(
        self,
        artifact_ref: ExperienceRef,
        *,
        as_of: int | None = None,
        limit: int | None = None,
    ) -> SourcePathListing: ...

    def read_source(
        self,
        artifact_ref: ExperienceRef,
        *,
        paths: tuple[str, ...],
        as_of: int | None = None,
    ) -> SourceRead: ...

    def diff_source(
        self,
        older_artifact_ref: ExperienceRef,
        newer_artifact_ref: ExperienceRef,
        *,
        paths: tuple[str, ...] = (),
        as_of: int | None = None,
    ) -> SourceDiff: ...


__all__ = ["ExperienceAccess", "ExperienceReader"]
