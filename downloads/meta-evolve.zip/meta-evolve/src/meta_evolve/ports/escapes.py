"""Which raises abort a run instead of becoming a typed failure.

Stated at the port level because two layers need the same answer and neither
may read it from the other. The callable adapters use it to decide what NOT to
convert into a logical trial outcome; the scheduler uses it to decide what not
to retry. The application layer imports no concrete adapter (`test_application
_purity.py` enforces that), so a scheduler reaching into `adapters/normalization
.py` for this list would either break that rule or dilute its wiring allowlist
with something that is not wiring.

Each type states a fact about durable state, accounting, or a capability the
environment does not have -- facts that are true for every candidate, not for
the one being evaluated. Absorbing one would re-run an impossible preflight
against the whole budget and then report the search as `NoSuccessfulEvaluation`
rather than its real cause.
"""

from __future__ import annotations

from meta_evolve.domain.search import InvalidSearchHistory
from meta_evolve.errors import (
    CapabilityError,
    DispatcherSuperseded,
    DurableStoreError,
    ExecutionAccountingUnknown,
    ExperienceStoreUnavailable,
)

from .event_store import EventStreamConflict
from .work_submission import StaleCompletion

# The infrastructure faults no local callable adapter may convert into a
# logical trial outcome.
INFRASTRUCTURE_ESCAPES: tuple[type[BaseException], ...] = (
    EventStreamConflict,
    DurableStoreError,
    InvalidSearchHistory,
    ExperienceStoreUnavailable,
    ExecutionAccountingUnknown,
)

# Those plus the abort control flow every role adds. `CapabilityError` is a
# `RunError` is a `RuntimeError`, so an adapter's broad conversion must be
# ordered after this set or it would swallow one.
ESCAPING_EXCEPTIONS: tuple[type[BaseException], ...] = (
    *INFRASTRUCTURE_ESCAPES,
    CapabilityError,
    # Not infrastructure: a fact about who drives the run. Absorbed as a failed
    # attempt, two dispatchers would spend one run's retry bound against each
    # other.
    DispatcherSuperseded,
    # A submission whose lease no longer authorises it. Absorbed as an attempt
    # failure mid-call, a step longer than the lease would recur identically on
    # every retry and end as "exhausted N attempts" over a lease-length problem.
    StaleCompletion,
)


def escapes_normalization(error: BaseException) -> bool:
    """Whether this raise passes the adapters uncaught instead of being typed.

    Takes an instance, never a class: every caller holds a caught exception.
    """

    return isinstance(error, ESCAPING_EXCEPTIONS)


__all__ = [
    "ESCAPING_EXCEPTIONS",
    "INFRASTRUCTURE_ESCAPES",
    "escapes_normalization",
]
