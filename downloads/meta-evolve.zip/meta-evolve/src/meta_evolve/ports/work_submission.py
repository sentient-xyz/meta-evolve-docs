"""Typed completion refusals and the already-accepted renewal outcome.

DuplicateCompletion carries the stored acknowledgment; StaleCompletion names
why a lease no longer authorizes acceptance. Both unwind the whole commit.
An item absent from the run remains an InvalidWorkAppend contract violation.

`submission_status` answers the same question WITHOUT acting on it -- `Live`,
`Duplicate(acknowledgment)` or `Stale(reason)` -- as the advisory pre-check a
worker's result gets before anything is built. The in-transaction acceptance
still decides; a status can be overtaken by the time the commit lands.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from meta_evolve.domain.work import StaleReason, WorkItemId
from meta_evolve.errors import RunError

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .work_store import Acknowledgment


class StaleCompletion(RunError):
    """A lease no longer authorizes this completion.

    This RunError reaches CLI callers and escapes attempt normalization. Inline
    execution aborts the drive; a later resume may retry under a valid lease.
    """

    def __init__(self, item: WorkItemId, reason: StaleReason) -> None:
        if not isinstance(reason, StaleReason):
            raise TypeError("a stale completion carries a StaleReason")
        self.item = item
        self.reason = reason
        super().__init__(
            f"work item {item.value} was not accepted: its lease no longer "
            f"authorises the submission ({reason.value})"
        )


class DuplicateCompletion(Exception):
    """Replay the stored acknowledgment while rolling back the whole commit.

    The event append and work intents share one transaction. Raising prevents
    duplicate events or unrelated writes from committing beside a duplicate result.
    """

    def __init__(
        self, item: WorkItemId, acknowledgment: Acknowledgment | None = None
    ) -> None:
        super().__init__(item.value)
        self.item = item
        # The stored bytes, replayed rather than recomputed. This is what makes
        # `acknowledgment_json` a column production code READS.
        self.acknowledgment = acknowledgment


class AlreadyAccepted:
    """The renewal's lease already has an accepted result.

    The inline dispatcher expects that result to be uncommitted, so its renewal
    check treats this answer as DurableCorruption.
    """

    __slots__ = ()

    def __repr__(self) -> str:  # pragma: no cover - diagnostics only
        return "ALREADY_ACCEPTED"


#: Named outcome returned by both broker adapters.
ALREADY_ACCEPTED = AlreadyAccepted()


@dataclass(frozen=True, slots=True)
class Live:
    """The lease still authorises its submission: build it and commit."""


@dataclass(frozen=True, slots=True)
class Duplicate:
    """The accepted attempt again, proving its token: replay this acknowledgment."""

    acknowledgment: Acknowledgment


@dataclass(frozen=True, slots=True)
class Stale:
    """The lease no longer authorises its submission, for this ONE reason."""

    reason: StaleReason


#: What `WorkBroker.submission_status` answers.
SubmissionStatus = Live | Duplicate | Stale


def status_of(reason, completed: bool, acknowledgment) -> SubmissionStatus:
    """A classification as the status it answers: the one mapping both brokers use.

    `acknowledgment` is called only for the accepted lease at a completed row,
    so an adapter reads -- and may refuse as corrupt -- only what it answers.
    """

    if reason is not None:
        return Stale(reason)
    if completed:
        return Duplicate(acknowledgment())
    return Live()


__all__ = [
    "ALREADY_ACCEPTED",
    "AlreadyAccepted",
    "Duplicate",
    "DuplicateCompletion",
    "Live",
    "Stale",
    "StaleCompletion",
    "SubmissionStatus",
    "status_of",
]
