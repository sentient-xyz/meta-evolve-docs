"""Run event-stream storage contract and typed failures."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Protocol, runtime_checkable

from meta_evolve.domain import EventEnvelope, RunId


class EventStreamConflict(RuntimeError):
    def __init__(
        self,
        run_id: RunId,
        expected_version: int,
        actual_version: int,
    ) -> None:
        self.run_id = run_id
        self.expected_version = expected_version
        self.actual_version = actual_version
        super().__init__(
            f"event stream {run_id} is at version {actual_version}, "
            f"not {expected_version}"
        )


class InvalidEventAppend(ValueError):
    def __init__(self, run_id: RunId, reason: str) -> None:
        self.run_id = run_id
        self.reason = reason
        super().__init__(f"invalid append for event stream {run_id}: {reason}")


class EventStore(Protocol):
    def append(
        self,
        run_id: RunId,
        expected_version: int,
        events: Iterable[EventEnvelope],
    ) -> int: ...

    def read(
        self,
        run_id: RunId,
        after: int = 0,
    ) -> tuple[EventEnvelope, ...]: ...


@runtime_checkable
class RunIndex(Protocol):
    """An OPTIONAL event-store capability: enumerate the runs it holds.

    Deliberately separate from :class:`EventStore` rather than a method on
    it. Both required methods are run-scoped — they take a ``RunId`` and
    answer about one stream — so a store can be *addressable without being
    enumerable*: one stream handed in at construction, a backend exposing
    only ``GET /runs/{id}/events``, a sharded store whose "all runs" spans
    shards. Those remain conforming event stores; they simply do not offer
    this capability, and ``Storage.runs()`` refuses explicitly for them.

    The capability is the method, so implementing it *is* the declaration —
    unlike durability, which is invisible in a commit strategy's method set
    and therefore needs the separate ``is_durable`` flag. Callers check with
    ``isinstance(store, RunIndex)``, never against a concrete store type.
    """

    def runs(self) -> tuple[RunId, ...]:
        """Every run with at least one committed event, sorted by id.

        Ids are content-derived, so this order is stable and identical
        across implementations but carries no chronological meaning.
        """
        ...


@runtime_checkable
class RunVersionReader(Protocol):
    """An OPTIONAL event-store capability: read a stream's committed version.

    The version is the maximum committed event sequence, or ``0`` when the
    well-formed run id has no events. It is a cheap change-detection query,
    not a substitute for :meth:`EventStore.read` and its integrity checks.
    """

    def run_version(self, run_id: RunId) -> int: ...


__all__ = [
    "EventStore",
    "EventStreamConflict",
    "InvalidEventAppend",
    "RunIndex",
    "RunVersionReader",
]
