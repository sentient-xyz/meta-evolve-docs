"""Replaceable synchronous workspace materialization."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from meta_evolve.domain.source_history import SourceHistoryManifest
from meta_evolve.domain.values import FrozenMap


@dataclass(frozen=True, slots=True)
class Workspace:
    """A private writable filesystem view owned by one provider."""

    root: Path

    def __post_init__(self) -> None:
        root = Path(self.root)
        if not root.is_absolute():
            raise ValueError("workspace root must be absolute")
        object.__setattr__(self, "root", root)


@dataclass(frozen=True, slots=True)
class WorkspaceSession:
    """Callback-visible handle for one controlled external workspace view."""

    root: Path
    environment: FrozenMap
    history: SourceHistoryManifest | None = None

    def __post_init__(self) -> None:
        root = Path(self.root)
        if not root.is_absolute():
            raise ValueError("workspace session root must be absolute")
        object.__setattr__(self, "root", root)
        if not isinstance(self.environment, FrozenMap):
            object.__setattr__(self, "environment", FrozenMap(self.environment))
        if any(
            not isinstance(key, str) or not isinstance(value, str)
            for key, value in self.environment.items()
        ):
            raise TypeError("workspace session environment must map strings to strings")
        if self.history is not None and not isinstance(
            self.history, SourceHistoryManifest
        ):
            raise TypeError("workspace session history must be a SourceHistoryManifest")


class WorkspaceProvider(Protocol):
    def materialize(self, artifact: object) -> Workspace: ...

    def capture(self, workspace: Workspace) -> object: ...

    def dispose(self, workspace: Workspace) -> None: ...


__all__ = ["Workspace", "WorkspaceProvider", "WorkspaceSession"]
