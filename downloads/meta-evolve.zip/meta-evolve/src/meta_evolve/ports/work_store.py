"""The work broker port: its operations, its answers and its refusals.

The ``Protocol`` arrives now that it has two implementers -- the in-memory
broker the dispatcher tests drive and the SQLite one a distributed run uses --
rather than when it had one and would have been an abstraction over nothing.

``WorkBroker`` is NOT ``@runtime_checkable``: that is reserved in this repo
for optional capabilities a caller must interrogate, and a broker is required
equipment supplied by construction. A structural check would also be worthless
there, since both implementers satisfy the same method set by definition.

``WorkTransactor`` below IS ``@runtime_checkable``, and for exactly that
reason rather than against it: whether a commit strategy has a work table is
precisely an optional capability a caller must interrogate, and the strategies
do NOT all satisfy it.

Mirrors ``event_store.InvalidEventAppend`` deliberately, down to the message
shape: the two guard the same property of the same transaction, one for events
and one for the work those events authorise, and a reader who has seen one
should recognise the other.

Past the ~300-line guideline: the port, its intents and the refusals both adapters share are the contract. The refusals live here precisely because they were duplicated in the two adapters and drifted; moving them out again would recreate the distance that let them drift.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from meta_evolve.domain import RunId
from meta_evolve.domain.values import (
    FrozenMap,
    _freeze_map_field,
    canonical_payload_bytes,
    decode_payload_bytes,
)
from meta_evolve.domain.work import (
    DEFAULT_LEASE_SECONDS,
    Lease,
    StaleReason,
    WorkItemId,
    WorkRow,
    WorkState,
)
from meta_evolve.domain.workers import WorkerRegistration
from meta_evolve.errors import DispatcherSuperseded


class InvalidWorkAppend(ValueError):
    def __init__(self, run_id: RunId, reason: str) -> None:
        self.run_id = run_id
        self.reason = reason
        super().__init__(f"invalid work append for run {run_id}: {reason}")


def refuse_superseded(run_id, held: int | None, current: int) -> None:
    """Refuse a caller holding an epoch the run has moved past. One statement.

    Read by both brokers' writes and by `RequireEpoch` inside a commit, so the
    fence says one thing wherever it is met. `held=None` is an unfenced caller:
    one that never rolled the epoch over itself holds nothing to compare.
    Compared with the STORED epoch, never a lease's -- a lease's epoch says when
    it was issued, and this asks who is driving the run now.
    """

    if held is not None and held != current:
        raise DispatcherSuperseded(run_id, held=held, current=current)


def refuse_multiple_acceptances(run_id, work) -> None:
    """At most one `AcceptCompletion` per logical batch.

    `work` is an unbounded `Iterable[WorkIntent]` and the dispatch paths
    already commit multi-intent tuples, so nothing structurally stopped two
    acceptances riding one batch. Two would mean one transaction claiming two
    different items' results, with no way for a caller to learn which of them
    the answer belonged to.
    """

    accepted = [intent for intent in work if isinstance(intent, AcceptCompletion)]
    if len(accepted) > 1:
        raise InvalidWorkAppend(
            run_id,
            f"a batch carries {len(accepted)} completions "
            f"({', '.join(sorted(i.item.value for i in accepted))}); one "
            "logical batch accepts at most one item's result",
        )


def refuse_inadmissible_enqueue(run_id, row) -> None:
    """Every reason an enqueue may refuse a row, in one place.

    The type guard, the allowlist and the run-id check were written out
    identically in both adapters -- `memory/work_ledger.py:87-98` and
    `sqlite/work_rows.py:87-98` were TWELVE consecutive identical lines at
    identical line numbers, comment block included, wrapped around the shared
    `refuse_unenqueuable_state` call they both already made. That is the shape
    of a half-finished migration, and it is the shape this module family has
    twice paid for: `work_rows.py` records that the two adapters disagreed on
    what an idempotent re-enqueue compares, and the in-memory broker records a
    reordering divergence "the differential oracle could not see".

    The IDEMPOTENCY comparison stays with each adapter, because only they can
    read back what is already stored -- one from a dict, one from a SELECT.
    What is shared is every rule that needs nothing but the row.
    """

    if not isinstance(row, WorkRow):
        raise TypeError("work row must be a WorkRow")
    # M11.2 ships no `prepare`, so a PREPARING row is one nothing can move --
    # and the record is explicit that "Rows are never left unclaimable".
    # Refused at the door rather than stored and stuck. The state stays in the
    # enum because the record is normative about it; what is absent is a
    # producer, and a row is how that absence would become a wedged run.
    refuse_unenqueuable_state(run_id, row)
    # ... and it produces the one ATTEMPT COUNT enqueue produces. The state
    # allowlist above is only half the rule: a row admitted as `READY` with
    # attempts already spent is born closer to its retry limit than anything
    # tried it, and at `attempts == max_attempts` is born dead -- `READY` and
    # unclaimable at once, which is the state the record forbids outright when
    # it says "Rows are never left unclaimable".
    if row.attempts != 0:
        raise InvalidWorkAppend(
            run_id,
            f"work row {row.item.value} is enqueued with {row.attempts} "
            "attempts already spent; enqueue creates rows nothing has tried",
        )
    if row.run_id != run_id:
        raise InvalidWorkAppend(
            run_id, f"work row {row.item.value} belongs to another run"
        )


def refuse_unenqueuable_state(run_id, row) -> None:
    """Enqueue creates the one state enqueue produces, and no other.

    An ALLOWLIST. Both adapters refused only `PREPARING`, so a row handed in
    already `LEASED`, `COMPLETED` or `CANCELLED` was inserted as-is -- and the
    four columns that make a terminal row meaningful (the accepted attempt, its
    token digest, the acknowledgment) are written only by acceptance, so an
    enqueued `COMPLETED` row is precisely what the record forbids when it says
    "COMPLETED does not exist without the accepted attempt, its token and the
    acknowledgment". Every other state is reached by the operation that owns
    that transition.
    """

    if row.state is not WorkState.READY:
        raise InvalidWorkAppend(
            run_id,
            f"work row {row.item.value} is {row.state.value}, and enqueue "
            "creates only READY rows; every other state is reached by the "
            "operation that owns that transition",
        )


@dataclass(frozen=True, slots=True)
class Acknowledgment:
    """What a completed item stores, and replays to a duplicate submission.

    Opaque to the broker: it records and returns the bytes without reading them,
    because what a worker needs to hear back is the dispatcher's business.
    """

    payload: FrozenMap | Mapping[str, object] = field(default_factory=FrozenMap)

    def __post_init__(self) -> None:
        _freeze_map_field(self, "payload")
        # Encoded ONCE, here, through the same canonical encoder every durable
        # payload in this repository uses. The constructor stays ergonomic and
        # the type becomes genuinely opaque: adapters store and return `content`
        # without reading it, so there is no structure left for two writers to
        # encode differently -- and two did, one shallowly, which raised
        # `TypeError` on a nested payload the other accepted.
        object.__setattr__(
            self, "content", canonical_payload_bytes(self.payload)
        )

    content: bytes = field(default=b"", compare=False, repr=False)

    @classmethod
    def from_content(cls, content: bytes | str | None) -> "Acknowledgment | None":
        """Rebuild one from the bytes an adapter stored.

        The write side encoded once, canonically; this is the read side that
        makes `acknowledgment_json` a column production code actually reads
        rather than only writes. `None` in, `None` out: a row that never
        completed has nothing to replay.

        SQLite returns `bytes` for the value it was handed and `str` if a
        column was ever written as text, so both are accepted rather than
        assumed. `decode_payload_bytes` is the exact inverse of the encoder the
        constructor uses -- plain `json.loads` is NOT, because the canonical
        form wraps a mapping as `{"$map": ...}` and would rebuild one level too
        deep.
        """

        if content is None:
            return None
        if isinstance(content, str):
            content = content.encode()
        return cls(decode_payload_bytes(content))


@dataclass(frozen=True, slots=True)
class EnqueueWork:
    """Insert a row that is absent. Idempotent for an identical submission."""

    row: WorkRow


@dataclass(frozen=True, slots=True)
class AcceptCompletion:
    """Move a leased item to COMPLETED, fenced on the lease that earned it.

    Carries the LEASE, which is the whole fence. The design record requires
    this transition to check "Exact worker, attempt, fence and token; before
    the deadline", and three of those were prose until the intent could carry
    them: moving acceptance off the broker bought atomicity with the logical
    batch and dropped the preconditions on the way.

    Carrying the lease rather than copying its fields out is deliberate. A
    first version listed `attempt`, `token`, `epoch`, `worker_id` and
    `generation` separately -- six of eight fields that were `Lease`'s, copied
    at both call sites and compared back one at a time, with `WorkerId`
    downgraded to `str` in transit. The clump had a type already.

    `now` rides along for the same reason every broker operation takes its
    clock as an argument -- the deadline is decided in the broker's clock
    domain, and an adapter reading a clock of its own would be a second
    authority over expiry. The dispatcher samples it after the component
    returns and after the facts are built, immediately before committing, so
    the window the check covers is the one the write actually happens in.
    """

    lease: Lease
    now: int
    acknowledgment: Acknowledgment

    @property
    def item(self) -> WorkItemId:
        """The item being completed, which is the lease's."""

        return self.lease.item


@dataclass(frozen=True, slots=True)
class TerminateWork:
    """Cancel a row that ran out of attempts, alongside its terminal fact."""

    item: WorkItemId
    reason: str


@dataclass(frozen=True, slots=True)
class AbortWork:
    """Cancel a row its own diagnosis has already answered for, with its fact.

    `TerminateWork`'s row spent every attempt; this one still has some and will
    never use them, because the attempt it did spend came back with a cause a
    re-run cannot clear. Two intents rather than one with a looser
    precondition: the shapes are opposite -- exhausted with any diagnosis or
    none, against diagnosed with attempts to spare -- and a single applier
    would check their disjunction, which the wrong half satisfies.

    Carries only the item and a reason, like its sibling. The state, the stored
    cause and the attempt that cause belongs to are read inside the writing
    transaction, because reading them anywhere else is a TOCTOU on the property
    the record wants serialized.
    """

    item: WorkItemId
    reason: str


@dataclass(frozen=True, slots=True)
class RequireEpoch:
    """This commit was made under ``epoch``; refuse it if the run has moved on.

    Not a transition -- it changes no row -- but an intent all the same,
    because the check has to run inside the transaction that writes the events,
    against the epoch the store holds, and intents are what reach that
    transaction. A fenced coordinator attaches it to every commit it makes.
    """

    epoch: int


# The closed set of work-table changes a logical commit may carry, and the
# reason the commit takes intents rather than rows: a row says what should
# EXIST, an intent says what is CHANGING, and only the second can express a
# transition. Each validates its own fenced preconditions inside the writing
# transaction, which is what makes the transition serializable -- a check made
# before the commit would be a TOCTOU on exactly the property the record wants
# fenced.
#
# Deliberately NOT here: release and renew. Both are fact-free, so they have
# nothing to be atomic with, and the record forbids a renewal reaching the
# stream at all.
WorkIntent = EnqueueWork | AcceptCompletion | TerminateWork | AbortWork | RequireEpoch


@runtime_checkable
class WorkTransactor(Protocol):
    """An OPTIONAL commit-strategy capability: it has a work table.

    Declared here rather than beside `RunIndex` / `RunVersionReader` in
    `event_store.py`, though it follows exactly their rule -- this module owns
    `WorkBroker`, which is what the capability returns, and putting it there
    would make the event-store port import work vocabulary for a Protocol that
    is not about events.

    The capability is the METHOD, so implementing it *is* the declaration, and
    callers check with `isinstance(strategy, WorkTransactor)` rather than
    against a concrete type or a private field. `is_durable` cannot answer
    this question: `ReadOnlyUnitOfWork` declares itself durable and has no work
    table at all, so durability and work-capability are independent.

    A Protocol over the members every strategy already has -- `is_durable` and
    `commit` -- would match all of them, since `runtime_checkable` tests
    attribute PRESENCE. That is why the capability had to become a method
    before it could be declared.
    """

    def work_broker(
        self, *, lease_seconds: int = DEFAULT_LEASE_SECONDS
    ) -> WorkBroker:
        """This store's broker, leasing for ``lease_seconds``.

        A duration is per RUN (D9), so the run that drives the broker says it,
        and the one instance built here carries it into both `acquire` and
        `renew` -- two brokers with two durations would give the dispatcher and
        whatever renews its leases two different ideas of when a lease ends.
        """
        ...


class WorkBroker(Protocol):
    """The work operations; every one that reads time takes it as an argument.

    One predicate beside them: ``shares_transaction_with``, which answers
    whether two brokers commit together rather than performing a write.

    ``now`` is a parameter rather than something an implementation reads,
    because the record puts deadlines in a single clock domain the broker owns
    and clamps: an adapter that read a clock itself would be a second authority.

    ``enqueue`` is absent-only; ``acquire`` answers ``None`` for "nothing ready"
    rather than raising, because that is an ordinary result for a dispatcher
    polling a queue.

    Operations the record's state table names that are deliberately absent:

    * ``prepare`` and its failure, because M11.2 ships no producer of PREPARING
      and both brokers refuse such a row at enqueue rather than store one
      nothing can advance.
    * ``complete``. Acceptance is an ``AcceptCompletion`` intent applied inside
      the writing transaction, not a broker call opening its own -- only that
      makes it atomic with the logical batch, which the record requires. A
      broker method could not be, and having both would leave one of them the
      wrong way to do it.
    """

    def shares_transaction_with(self, other: "WorkBroker") -> bool:
        """Whether a transition this broker makes can ride ``other``'s commit.

        Asked of the implementation rather than answered by exporting what
        serialises the writes, the way `CommitStrategy.can_bind` asks a
        strategy instead of inferring from its store. A dispatcher pairs a
        broker with the storage whose commits must be atomic with it, and two
        brokers over one connection are the only pair that is.
        """
        ...

    #: The run's lease duration. A caller renewing a lease reads it here rather
    #: than being told separately -- one source for when a lease ends.
    lease_seconds: int

    def rows(self, run_id: RunId) -> tuple[WorkRow, ...]: ...

    def current_epoch(self, run_id: RunId) -> int: ...

    def enqueue(self, run_id: RunId, rows: Iterable[WorkRow]) -> None: ...

    def acquire(
        self,
        run_id: RunId,
        worker: WorkerRegistration,
        *,
        now: int,
        item: WorkItemId | None = None,
        epoch: int | None = None,
    ) -> Lease | None:
        """Claim one ready item; ``item`` names WHICH one.

        ``epoch``, on this and every other write: the epoch a fenced caller
        holds, refused with `DispatcherSuperseded` once the run has moved past
        it (`refuse_superseded`). ``None`` is an unfenced caller.

        A dispatcher resolves an item's inputs before claiming it, so that a
        store it cannot read costs no attempt. Between resolving and claiming,
        an expiry sweep can make an earlier row claimable, and a bare claim
        would then lease an item whose inputs were never resolved. Naming the
        item closes that, and answering ``None`` when it is no longer claimable
        is an ordinary result, like having nothing ready at all.
        """
        ...

    def renew(
        self, run_id: RunId, lease: Lease, *, now: int, epoch: int | None = None
    ) -> Lease | None: ...

    def renew_or_stale(
        self, run_id: RunId, lease: Lease, *, now: int, epoch: int | None = None
    ) -> "Lease | StaleReason | AlreadyAccepted":
        """Renew a live lease, or answer why it cannot be renewed.

        Three answers, each named. One transaction, so the reason is the
        precondition the refusing transaction saw. Fenced like every write.
        `ALREADY_ACCEPTED` only for the accepted lease at a `COMPLETED` row;
        an item the run does not hold raises `InvalidWorkAppend`. `renew` is
        this with everything but a renewed lease reported `None`.
        """
        ...

    def submission_status(
        self, run_id: RunId, lease: Lease, *, now: int
    ) -> "SubmissionStatus":
        """Classify a submission without acting on it: a read, never a write.

        No renewal, no expiry sweep, no clock-floor write, and no fence -- the
        record keeps fencing off reads. Compared at the later of `now` and the
        stored floor. Advisory: the in-transaction acceptance decides. An item
        the run does not hold raises `InvalidWorkAppend`.
        """
        ...

    def release(
        self,
        run_id: RunId,
        lease: Lease,
        *,
        now: int,
        failure: tuple[str, str] | None = None,
        epoch: int | None = None,
    ) -> bool: ...

    def record_failure(
        self,
        run_id: RunId,
        lease: Lease,
        *,
        now: int,
        cause: tuple[str, str],
        epoch: int | None = None,
    ) -> bool:
        """A completion failure's cause, under `release`'s diagnosis rule; no state moves."""
        ...

    def cancel(
        self, run_id: RunId, item: WorkItemId, *, now: int, epoch: int | None = None
    ) -> None: ...

    def rollover(self, run_id: RunId) -> int: ...


# The answers a submission gets when it is not accepted. Defined in their own
# port module and re-exported here, where every other work vocabulary lives.
from .work_submission import (  # noqa: E402
    AlreadyAccepted,
    DuplicateCompletion,
    StaleCompletion,
    SubmissionStatus,
)

__all__ = [
    "AbortWork",
    "AcceptCompletion",
    "Acknowledgment",
    "DuplicateCompletion",
    "EnqueueWork",
    "InvalidWorkAppend",
    "RequireEpoch",
    "StaleCompletion",
    "SubmissionStatus",
    "TerminateWork",
    "WorkIntent",
    "WorkBroker",
    "WorkTransactor",
    # The refusals. Both adapters and the unit of work import these, and two of
    # them were absent from this list -- an export list that omits what other
    # modules already import documents a smaller surface than the one that
    # exists, which is how a shared rule reads as private and gets copied.
    "refuse_inadmissible_enqueue",
    "refuse_multiple_acceptances",
    "refuse_superseded",
    "refuse_unenqueuable_state",
]
