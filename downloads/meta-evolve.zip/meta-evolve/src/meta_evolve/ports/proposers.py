"""Producer-neutral context pushed to one proposer invocation."""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

from meta_evolve.domain.context import ContextBundle
from meta_evolve.domain.components import PolicyRef
from meta_evolve.domain.task import Objective

from .evidence import EvidenceSelection
from .experience import ExperienceReader
from .workspaces import WorkspaceSession

if TYPE_CHECKING:
    from .callables import ProposalResult


@dataclass(frozen=True, slots=True, kw_only=True)
class ProposerContext:
    """The candidate-facing state authorized for one proposal.

    A plain callback requests this with ``def propose(parent, *, context)``.
    A default on that keyword does not disable delivery. Ordinary optional
    arguments keep their Python defaults; variadics alone do not request context.
    Structural objects retain their explicit ``propose(parent, context)`` port.

    ``rng`` supplies recorded per-attempt randomness. ``step`` is the successor's
    logical step, starting at one; ``objectives`` is the task's ordered tuple.
    ``bundle.records`` contains pushed feedback and ``bundle.rendered`` its
    bounded text. ``evidence.latest(kind)`` reads its last matching evidence;
    ``evidence.enabled`` distinguishes disabled context from a missing match.
    With no context policy the bundle is empty. ``experience``
    is an audited reader only when pull access is enabled; otherwise ``None``.
    Repository adapters may supply ``workspace`` with controlled execution and
    history information; ordinary callables receive ``None`` there.
    """

    rng: random.Random
    step: int
    objectives: tuple[Objective, ...]
    bundle: ContextBundle
    experience: ExperienceReader | None = None
    workspace: WorkspaceSession | None = None
    context_policy: PolicyRef | None = None

    @property
    def evidence(self) -> EvidenceSelection:
        """Evidence in this bundle, with explicit enabled/truncated status.

        Manually constructed contexts must supply ``context_policy`` to enable
        lookup; neither an empty bundle nor its reason proves policy status.
        """

        return EvidenceSelection(
            _bundle=self.bundle, enabled=self.context_policy is not None,
        )


class Proposer(Protocol):
    def propose(
        self, parent: object, context: ProposerContext
    ) -> ProposalResult: ...


__all__ = ["Proposer", "ProposerContext"]
