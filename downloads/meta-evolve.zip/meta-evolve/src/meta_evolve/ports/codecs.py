"""The artifact-codec contract: one authority for payload translation."""

from __future__ import annotations

from typing import Protocol

from meta_evolve.domain.evaluation import Failure
from meta_evolve.domain.values import FrozenValue


class ArtifactCodec(Protocol):
    """Translate between public values and durable payloads for one kind.

    Laws:
    - round trip: ``encode(decode(p)) == p`` for valid payloads, and
      ``decode(encode(v)) == v`` for valid values up to ``freeze``
      normalization (plain containers decode to their frozen form);
    - purity: deterministic, no I/O;
    - decode is validation — there is no separate ``validate`` method;
    - rejection: a codec says "this value is not mine" by raising
      ``TypeError`` or ``ValueError``. Those two are the rejection signal;
      any other exception is a bug in the codec and propagates as a real
      error. The two ends are deliberately asymmetric downstream: a rejected
      candidate fails only its own trial as a typed ``InvalidOutput``, while
      *any* failure to decode an already-committed payload is a
      data-integrity event (``DurableCorruption``) however the codec
      expressed it;
    - codecs never mint or check identity; digests stay payload-derived
      inside ``Artifact``.
    """

    kind: str
    representation: str
    interfaces: tuple[str, ...]

    def encode(self, value: object) -> FrozenValue: ...

    def decode(self, payload: FrozenValue) -> object: ...

    # Codecs may additionally implement SuccessorValidator. It is deliberately
    # a separate protocol so this base contract does not make the hook required.


class SuccessorValidator(Protocol):
    """Optional core-side validation of an encoded artifact transition."""

    def validate_successor(
        self,
        parents: tuple[FrozenValue, ...],
        candidate: FrozenValue,
    ) -> Failure | None: ...


__all__ = ["ArtifactCodec", "SuccessorValidator"]
