"""Immutable evidence views over an already authorized context selection."""

from __future__ import annotations

from dataclasses import dataclass, field

from meta_evolve.domain.context import ContextBundle
from meta_evolve.domain.evaluation import Evidence
from meta_evolve.domain.experience import ExperienceRef
from meta_evolve.domain.values import FrozenMap, _require_text
from meta_evolve.errors import ContextDisabled


@dataclass(frozen=True, slots=True, kw_only=True)
class EvidenceItem:
    """Selected evidence with its exact occurrence and recorded position.

    ``data`` is recursively immutable. ``ref`` can be explicitly cited in a
    proposal's ``derived_from``; reading this view records no derivation itself.
    A label identifies evidence, not whether its producer was an evaluator.
    """

    kind: str
    data: FrozenMap
    uri: str | None
    ref: ExperienceRef
    logical_step: int
    event_sequence: int

    def __post_init__(self) -> None:
        if not isinstance(self.data, FrozenMap):
            object.__setattr__(self, "data", FrozenMap(self.data))


@dataclass(frozen=True, slots=True, kw_only=True)
class EvidenceSelection:
    """Read selected evidence without queries, I/O, or additional authority.

    ``enabled`` describes the pushed-context declaration, not the presence of
    records. Use it to make feedback optional in intentional no-context runs.
    The full selection remains available through ``context.bundle``.
    """

    _bundle: ContextBundle = field(repr=False)
    enabled: bool

    @property
    def truncated(self) -> bool:
        """Whether the policy omitted records or clipped its text rendering.

        This flag cannot distinguish those causes. A text-only truncation does
        not remove structured evidence or bound the contents of ``item.data``.
        """

        return self._bundle.truncated

    def latest(self, kind: str) -> EvidenceItem | None:
        """Return the last matching evidence in the selected canonical order.

        ``kind`` is an exact, nonempty evidence label. Same-step matches follow
        bundle order. The result may describe an older ancestor or sibling;
        it need not describe the current parent or a successful evaluation.
        Proposer and evaluator evidence both qualify. No missing records or
        pull observations are fetched. ``None`` means no selected match, not
        that no evidence exists in the run. Disabled context raises instead.
        """

        _require_text(kind, "evidence kind")
        if not self.enabled:
            raise ContextDisabled(
                "Pushed context is disabled. Set Experiment(context=RecentAncestors(...)) "
                "or check context.evidence.enabled when feedback is optional."
            )
        for record in reversed(self._bundle.records):
            evidence = record.value
            if (
                record.kind == "evidence"
                and isinstance(evidence, Evidence)
                and evidence.kind == kind
            ):
                return EvidenceItem(
                    kind=evidence.kind, data=evidence.data, uri=evidence.uri,
                    ref=record.ref, logical_step=record.logical_step,
                    event_sequence=record.event_sequence,
                )
        return None


__all__ = ["EvidenceItem", "EvidenceSelection"]
