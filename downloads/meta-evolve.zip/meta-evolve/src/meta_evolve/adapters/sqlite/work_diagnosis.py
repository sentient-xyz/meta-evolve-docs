"""The diagnosis precondition for SQLite: who may write a cause onto a row.

`work_leases.py` answers whether a lease is LIVE; this answers the weaker
question of whether an ATTEMPT may still be described, so the two disagree
about an expired lease. The caller already holds the transaction. A SUBMISSION
must present its credential; the revocation sweep holds the lease it describes
and asks only the row rule, `undiagnosed_attempt_in_txn`.
"""

from __future__ import annotations

from meta_evolve.domain import RunId
from meta_evolve.errors import DurableCorruption
from meta_evolve.domain.work import (
    FailureStage,
    Lease,
    LeaseToken,
    WorkState,
    require_lease,
)

from .work_rows import lease_from, stored_cause_type

__all__ = [
    "authorised_to_diagnose_in_txn",
    "record_cause_in_txn",
    "undiagnosed_attempt_in_txn",
]

_SELECT = (
    "SELECT lease_json, attempts, state, last_failure_attempt,"
    " last_lease_token_digest FROM work_items WHERE run_id=? AND item_id=?"
)


def undiagnosed_attempt_in_txn(conn, run_id: RunId, lease: Lease) -> bool:
    """Whether this row is still open and nothing has described this attempt.

    All the sweep may ask: a stored lease carries its token's digest, not its
    secret, so it cannot present a credential. First writer wins per attempt.
    """

    require_lease(lease)
    found = conn.execute(_SELECT, (run_id.value, lease.item.value)).fetchone()
    return found is not None and _open_and_undiagnosed(lease, found)


def authorised_to_diagnose_in_txn(conn, run_id: RunId, lease: Lease) -> bool:
    """Whether this SUBMISSION may write a diagnosis onto the row.

    Weaker than `live_lease_in_txn` on purpose -- the diagnosis describes the
    ATTEMPT and must survive the lease expiring -- but it still needs the
    credential. The row rule above, and then the credential, in two cases,
    because the expiry sweep has already run by the time this is asked:

    * a lease is still HELD -- the presented one must match it, token and all;
    * none is held, because expiry collected it -- only the row's latest
      attempt may diagnose, and its token must prove against the digest that
      attempt was issued (`last_lease_token_digest`, kept through expiry). A
      row with no stored digest refuses.
    """

    require_lease(lease)
    found = conn.execute(_SELECT, (run_id.value, lease.item.value)).fetchone()
    if found is None or not _open_and_undiagnosed(lease, found):
        return False
    stored, attempts, _state, _diagnosed, issued = found
    if stored is not None:
        return lease.credential_mismatch(lease_from(lease.item.value, stored)) is None
    return lease.proves_latest_attempt(
        attempts, LeaseToken(issued) if isinstance(issued, str) else None
    )


def record_cause_in_txn(
    conn, run_id: RunId, lease: Lease, cause: tuple[str, str], stage: FailureStage
) -> None:
    """Write `cause` for `lease`'s attempt. The rule is the caller's to weigh.

    Shared by `release`, `record_failure` and the revocation sweep. The stage
    rides in `last_failure_type` (`stored_cause_type`).
    """

    conn.execute(
        "UPDATE work_items SET last_failure_type=?, last_failure_message=?,"
        " last_failure_attempt=? WHERE run_id=? AND item_id=?",
        (
            stored_cause_type(cause[0], stage),
            cause[1],
            lease.attempt.ordinal,
            run_id.value,
            lease.item.value,
        ),
    )


def _open_and_undiagnosed(lease: Lease, found) -> bool:
    """The row rule, over the columns both questions read in one statement."""

    _stored, attempts, state, diagnosed, _issued = found
    # A terminal row already carries its terminal fact; nothing rewrites it.
    if state in {terminal.value for terminal in WorkState.terminal()}:
        return False
    # Both stored attempts are validated before either decides, so a damaged
    # count is reported whatever the diagnosis says.
    if not isinstance(attempts, int) or attempts < 0:
        raise DurableCorruption(
            f"work item {lease.item.value} stores a malformed attempt count"
        )
    if diagnosed is not None and not isinstance(diagnosed, int):
        raise DurableCorruption(
            f"work item {lease.item.value} stores a non-integer diagnosis attempt"
        )
    return diagnosed is None or diagnosed < lease.attempt.ordinal
