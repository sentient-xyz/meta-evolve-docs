"""What store schema 5 adds: the trusted-worker table and the write guard (AD1).

`schema.py` owns the ladder and the current shapes. The guard: two triggers on
`work_items`, BEFORE INSERT and BEFORE UPDATE, call a no-op SQL function that
every writable connection registers before any schema work. SQLite resolves a
trigger body when it prepares a statement, so a process that opened the store at
v4 cannot write `work_items` once the migration commits, while its reads still
answer. The cost is installation-wide: the `sqlite3` shell cannot write
`work_items` either (the durability guide says so).
"""

from __future__ import annotations

import sqlite3

from meta_evolve.errors import DurableCorruption

# One row per enrolled worker for the whole store (no `run_id`). No CHECK
# constraint, like every other table here: the port validates. `NOT NULL` on the
# key because a TEXT PRIMARY KEY does not imply it.
_TRUSTED_WORKERS_V5 = (
    "CREATE TABLE IF NOT EXISTS trusted_workers ("
    " worker_id TEXT PRIMARY KEY NOT NULL,"
    " generation INTEGER NOT NULL,"
    " status TEXT NOT NULL,"
    " capabilities_json TEXT NOT NULL)"
)

_TRUSTED_WORKERS_COLUMNS = (
    ("worker_id", "TEXT", 1, 1),
    ("generation", "INTEGER", 1, 0),
    ("status", "TEXT", 1, 0),
    ("capabilities_json", "TEXT", 1, 0),
)

GUARD_FUNCTION = "meta_evolve_requires_store_schema_5"

#: The stamped version from which a store holds the table and the guard. Readers
#: compare `>=` this, never `==` the current version, so a later build still
#: reads a v5 store's registry and validates its guard.
SCHEMA_5_FEATURES_SINCE = 5


def _guard_trigger(event: str) -> tuple[str, str]:
    """The name and the DDL of the guard trigger for one kind of write."""

    name = f"work_items_requires_schema_5_before_{event.lower()}"
    return name, (
        f"CREATE TRIGGER IF NOT EXISTS {name} BEFORE {event} ON work_items"
        f" BEGIN SELECT {GUARD_FUNCTION}(); END"
    )


_TRIGGERS = dict(_guard_trigger(event) for event in ("INSERT", "UPDATE"))

# SQLite records a trigger's `sql` verbatim minus `IF NOT EXISTS` (measured on
# 3.49.1 and 3.53.3), so the expected catalog text is derived, not restated.
_RECORDED_SQL = {
    name: statement.replace("IF NOT EXISTS ", "")
    for name, statement in _TRIGGERS.items()
}


def register_write_guard(conn: sqlite3.Connection) -> None:
    """Give ``conn`` the function the guard triggers call; resolving its name is
    the whole check. ``open_store`` calls this before any schema work."""

    conn.create_function(GUARD_FUNCTION, 0, lambda: None)


def create_write_guard(conn: sqlite3.Connection) -> None:
    """Create both triggers, idempotently.

    Called by the rung and by the current-definitions pass, because a fresh store
    runs no rung.
    """

    for statement in _TRIGGERS.values():
        conn.execute(statement)


def require_write_guard(conn: sqlite3.Connection, store: str) -> None:
    """Refuse a store that does not hold exactly both triggers, as written.

    For a stamped store this runs BEFORE the definitions pass, so a dropped
    trigger is corruption rather than quietly recreated.
    """

    recorded = dict(
        conn.execute(
            "SELECT name, sql FROM sqlite_master"
            " WHERE type='trigger' AND tbl_name='work_items'"
        ).fetchall()
    )
    if recorded != _RECORDED_SQL:
        raise DurableCorruption(
            f"{store} has a missing or malformed work_items write guard"
        )


def _migrate_v4_to_v5(conn: sqlite3.Connection) -> None:
    """Add the trusted-worker table and the guard. A migrated store trusts nobody."""

    conn.execute(_TRUSTED_WORKERS_V5)
    create_write_guard(conn)


__all__ = [
    "GUARD_FUNCTION",
    "SCHEMA_5_FEATURES_SINCE",
    "_TRUSTED_WORKERS_COLUMNS",
    "_TRUSTED_WORKERS_V5",
    "_migrate_v4_to_v5",
    "create_write_guard",
    "register_write_guard",
    "require_write_guard",
]
