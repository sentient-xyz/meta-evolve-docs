"""Store-wide worker enrolments in SQLite.

Writes read, decide, and update within one IMMEDIATE transaction. Readers
use DEFERRED transactions. Malformed rows raise DurableCorruption; SQLite
read failures become DurableStoreError before reaching admission.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Iterator, Mapping
from contextlib import contextmanager

from meta_evolve.domain.values import (
    FrozenMap,
    canonical_payload_bytes,
    decode_payload_bytes,
)
from meta_evolve.domain.workers import (
    TrustedWorker,
    TrustStatus,
    WorkerId,
    honoured_generation,
)
from meta_evolve.errors import DurableCorruption, DurableStoreError
from meta_evolve.ports.worker_registry import decide_revocation, decide_trust

from .connection import _read_version, transaction
from .schema_v5 import SCHEMA_5_FEATURES_SINCE

_COLUMNS = "worker_id, generation, status, capabilities_json"

_SELECT_ONE = f"SELECT {_COLUMNS} FROM trusted_workers WHERE worker_id=?"

# Ordered as the in-memory registry's `all()` is: the id grammar is ASCII, which
# SQLite's default BINARY collation sorts the same way.
_SELECT_ALL = f"SELECT {_COLUMNS} FROM trusted_workers ORDER BY worker_id"

# A row is never deleted (AD2): every write after the first updates the same key.
_UPSERT = (
    "INSERT INTO trusted_workers(worker_id, generation, status, capabilities_json)"
    " VALUES(?,?,?,?)"
    " ON CONFLICT(worker_id) DO UPDATE SET"
    " generation=excluded.generation, status=excluded.status,"
    " capabilities_json=excluded.capabilities_json"
)


def _encoded(row: TrustedWorker) -> tuple[str, int, str, str]:
    """One row as its four columns, in declared order.

    The declaration is stored canonically, so it reads back as the same value
    and re-typing an enrolled declaration stays a no-op under PD4.
    """

    return (
        row.worker.value,
        row.generation,
        row.status.value,
        canonical_payload_bytes(row.capabilities).decode("utf-8"),
    )


def _decoded(record) -> TrustedWorker:
    """One stored row as the worker it describes, or `DurableCorruption`.

    The id is decoded from the row, not taken from the lookup key;
    `honoured_generation` guards every (id, row) pair it is given.
    """

    worker_id, generation, status, capabilities = record
    worker = _worker_of(worker_id)
    return TrustedWorker(
        worker=worker,
        generation=_generation_of(worker, generation),
        status=_status_of(worker, status),
        capabilities=_capabilities_of(worker, capabilities),
    )


def _worker_of(stored: object) -> WorkerId:
    """The id this row is for; a reserved-prefix id is damage (AD3)."""

    try:
        return WorkerId.operator_supplied(stored)  # type: ignore[arg-type]
    except (TypeError, ValueError) as error:
        raise DurableCorruption(
            f"a trusted worker row stores an unusable worker_id {stored!r}: {error}"
        ) from error


def _generation_of(worker: WorkerId, stored: object) -> int:
    """A whole number from one up, checked here so the failure is typed."""

    if isinstance(stored, bool) or not isinstance(stored, int) or stored < 1:
        raise DurableCorruption(
            f"trusted worker {worker.value} stores a malformed generation {stored!r}"
        )
    return stored


def _status_of(worker: WorkerId, stored: object) -> TrustStatus:
    try:
        return TrustStatus(stored)
    except ValueError as error:
        raise DurableCorruption(
            f"trusted worker {worker.value} stores an unknown status {stored!r}"
        ) from error


def _capabilities_of(worker: WorkerId, stored: object) -> FrozenMap:
    """The declaration this row carries; a payload that is not an object is damage."""

    try:
        if not isinstance(stored, str):
            raise TypeError(f"the column holds {type(stored).__name__}, not text")
        declared = decode_payload_bytes(stored.encode("utf-8"))
        if not isinstance(declared, FrozenMap):
            raise TypeError(
                f"the declaration is {type(declared).__name__}, not an object"
            )
        return declared
    except Exception as error:
        raise DurableCorruption(
            f"trusted worker {worker.value} stores unreadable capabilities_json: "
            f"{error}"
        ) from error


def _stored_row_in_txn(
    conn: sqlite3.Connection, worker: WorkerId
) -> TrustedWorker | None:
    """The row this store holds for `worker`, or `None`. The caller holds the
    transaction."""

    found = conn.execute(_SELECT_ONE, (worker.value,)).fetchone()
    return None if found is None else _decoded(found)


def _all_rows_in_txn(conn: sqlite3.Connection) -> tuple[TrustedWorker, ...]:
    return tuple(_decoded(record) for record in conn.execute(_SELECT_ALL))


def _table_exists_in_txn(conn: sqlite3.Connection) -> bool:
    """Whether the stamped version has this table, read in the caller's
    transaction so the answer and the rows it gates share one snapshot."""

    stamped = _read_version(conn)
    return stamped is not None and stamped >= SCHEMA_5_FEATURES_SINCE


def _one_row(
    conn: sqlite3.Connection, worker: WorkerId, *, version_gated: bool = False
) -> TrustedWorker | None:
    """One row, in a `DEFERRED` transaction of its own.

    `version_gated` answers `None` for a store stamped below the table, without
    a statement against it.
    """

    with _typed(), transaction(conn, mode="DEFERRED"):
        if version_gated and not _table_exists_in_txn(conn):
            return None
        return _stored_row_in_txn(conn, worker)


def _every_row(
    conn: sqlite3.Connection, *, version_gated: bool = False
) -> tuple[TrustedWorker, ...]:
    """Every row, read the same way as `_one_row`."""

    with _typed(), transaction(conn, mode="DEFERRED"):
        if version_gated and not _table_exists_in_txn(conn):
            return ()
        return _all_rows_in_txn(conn)


@contextmanager
def _typed() -> Iterator[None]:
    """Every `sqlite3` failure of a read as `DurableStoreError`, not only the
    `OperationalError` `transaction` types: the door reads this table, and a
    raw class there is one no dispatch layer names."""

    try:
        yield
    except sqlite3.Error as error:
        raise DurableStoreError(f"sqlite failure reading trusted_workers: {error}") from error


def honoured_generation_in_txn(
    conn: sqlite3.Connection, worker: WorkerId
) -> int | None:
    """Which generation this store honours for `worker`, inside an open transaction.

    Read inside the transaction that acts on the answer, so a revoke cannot land
    between the read and the write. A dispatcher-minted id reads no row (AD3).
    """

    if worker.is_dispatcher_minted:
        return honoured_generation(worker, None)
    return honoured_generation(worker, _stored_row_in_txn(conn, worker))


class SqliteTrustedWorkerReader:
    """Live enrolments over a writable store's connection, exposing only reads."""

    def __init__(self, connection: sqlite3.Connection) -> None:
        self._conn = connection

    def get(self, worker: WorkerId) -> TrustedWorker | None:
        return _one_row(self._conn, worker)

    def all(self) -> tuple[TrustedWorker, ...]:
        return _every_row(self._conn)


class SqliteTrustedWorkers(SqliteTrustedWorkerReader):
    """The reader plus atomic enrolment and revocation for the operator."""

    # -- writes -----------------------------------------------------------

    def trust(
        self, worker: WorkerId, capabilities: Mapping[str, object]
    ) -> TrustedWorker:
        with transaction(self._conn):
            row = decide_trust(
                _stored_row_in_txn(self._conn, worker), worker, capabilities
            )
            self._conn.execute(_UPSERT, _encoded(row))
        return row

    def revoke(self, worker: WorkerId) -> TrustedWorker:
        with transaction(self._conn):
            row = decide_revocation(_stored_row_in_txn(self._conn, worker), worker)
            self._conn.execute(_UPSERT, _encoded(row))
        return row


class ReadOnlySqliteTrustedWorkers(SqliteTrustedWorkerReader):
    """One store's enrolments, over a connection with no write authority.

    Below schema 5 every read answers empty without touching the table. The
    version is read at every call, with the rows, never cached: another
    connection may migrate the file in place under this one.
    """

    def get(self, worker: WorkerId) -> TrustedWorker | None:
        return _one_row(self._conn, worker, version_gated=True)

    def all(self) -> tuple[TrustedWorker, ...]:
        return _every_row(self._conn, version_gated=True)


__all__ = [
    "ReadOnlySqliteTrustedWorkers",
    "SqliteTrustedWorkerReader",
    "SqliteTrustedWorkers",
    "honoured_generation_in_txn",
]
