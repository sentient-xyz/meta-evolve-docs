"""SQLite adapters: event store, artifact occurrence rows, store schema."""

from meta_evolve.durability import STORE_SCHEMA_VERSION

from .connection import open_read_only_store, open_store, transaction
from .event_store import SqliteEventStore
from .read_only_event_store import ReadOnlySqliteEventStore
from .trusted_workers import ReadOnlySqliteTrustedWorkers, SqliteTrustedWorkers

__all__ = [
    "STORE_SCHEMA_VERSION",
    "SqliteEventStore",
    "ReadOnlySqliteEventStore",
    "ReadOnlySqliteTrustedWorkers",
    "SqliteTrustedWorkers",
    "open_read_only_store",
    "open_store",
    "transaction",
]
