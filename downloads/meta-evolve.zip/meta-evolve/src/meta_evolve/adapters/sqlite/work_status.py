"""`submission_status` for SQLite: classify a submission, and write nothing.

Its own module rather than a function in `work_leases.py`, which is at the
length the repository asks for. It needs nothing from there but the one
classifier acceptance and `renew_or_stale` already share, so the rule it reads
is still stated once.
"""

from __future__ import annotations

from meta_evolve.domain import RunId
from meta_evolve.domain.work import Lease, WorkState, require_broker_time
from meta_evolve.errors import DurableCorruption
from meta_evolve.ports.work_store import Acknowledgment
from meta_evolve.ports.work_submission import SubmissionStatus, status_of

from .work_leases import classify_submission_in_txn, epoch_in_txn


def submission_status_in_txn(
    conn, run_id: RunId, lease: Lease, *, now: int
) -> SubmissionStatus:
    """Classify at the later of `now` and the stored floor, writing nothing.

    No floor write, no expiry sweep, no fence: a LEASED row past its deadline
    is still LEASED here, and reports `EXPIRED` against its held deadline
    exactly as acceptance -- which does not sweep either -- reports it.

    It does weigh the operator's allow-list, because the shared classifier reads
    it inside this transaction (PD2). Writing nothing is not the same as knowing
    nothing: this is the answer a dispatcher acts on before it builds a commit,
    and one that called a revoked worker's lease live would send it to assemble a
    commit the acceptance transaction is about to refuse.
    """

    epoch, floor = epoch_in_txn(conn, run_id)
    reason, state, ack = classify_submission_in_txn(
        conn, run_id, lease, epoch=epoch, clock=max(floor, require_broker_time(now))
    )

    def acknowledgment() -> Acknowledgment:
        try:
            return Acknowledgment.from_content(ack)
        except (ValueError, TypeError) as error:
            raise DurableCorruption(
                f"work item {lease.item.value} stores a malformed acknowledgment"
            ) from error

    return status_of(reason, state is WorkState.COMPLETED, acknowledgment)


__all__ = ["submission_status_in_txn"]
