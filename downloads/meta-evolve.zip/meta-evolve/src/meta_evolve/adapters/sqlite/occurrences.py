"""Artifact occurrence rows: identity + provenance, separate from payload
bytes (which live in the filesystem blob CAS).

The occurrence row is the design's 7-column form —
``(artifact_id, digest, kind, representation, parent_ids_json,
provenance_json, schema_version)`` — encoded with plain ``json.dumps``, not
``serialization.dumps``: the tagged encoding (``tagged_values``) only accepts
``FrozenMap``/tuple/registered-dataclass/primitive values, and a plain
``list`` (``parent_ids``) or a mapping straight out of ``FrozenMap.items()``
is neither, so it does not apply here. Everything below is intra-package to
the SQLite adapter: ``_put_occurrence_in_txn`` is a private, no-transaction
helper — it assumes a transaction is already open, so both the standalone
``DurableArtifactStore.put`` (which opens its own transaction) and
``Storage.commit``'s single outer transaction (which also appends events)
can share it without nesting ``BEGIN``.
"""

from __future__ import annotations

import json
import sqlite3

from meta_evolve.domain import Artifact, ArtifactId, ContentDigest, SchemaVersion
from meta_evolve.domain.identity import CURRENT_SCHEMA_VERSION
from meta_evolve.domain.values import FrozenMap
from meta_evolve.errors import SchemaVersionRejected
from meta_evolve.ports import ArtifactConflict, ArtifactNotFound

_OCCURRENCE_COLUMNS = (
    "digest",
    "kind",
    "representation",
    "parent_ids_json",
    "provenance_json",
    "schema_version",
)


def _plain(value: object) -> object:
    """Recursively convert a frozen (``FrozenMap``/tuple) value to plain
    JSON-serializable Python (``dict``/``list``), for canonical JSON dumping."""

    if isinstance(value, FrozenMap):
        return {key: _plain(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_plain(item) for item in value]
    return value


def encode_occurrence_row(artifact: Artifact) -> tuple[str, str, str, str, str, str, int]:
    """Encode ``artifact``'s occurrence metadata (everything but the payload)
    as the 7-column row, keyed by ``artifact_id``."""

    assert artifact.digest is not None
    parent_ids_json = json.dumps(
        [parent.value for parent in artifact.parent_ids], separators=(",", ":")
    )
    provenance_json = json.dumps(
        _plain(artifact.provenance),
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return (
        artifact.id.value,
        artifact.digest.value,
        artifact.kind,
        artifact.representation,
        parent_ids_json,
        provenance_json,
        artifact.schema_version.value,
    )


def _put_occurrence_in_txn(conn: sqlite3.Connection, artifact: Artifact) -> None:
    """Write ``artifact``'s occurrence row. Idempotent for an identical
    resubmission; raises ``ArtifactConflict`` if the id already stores
    different occurrence metadata. Assumes a transaction is already open."""

    if not isinstance(artifact, Artifact):
        raise TypeError("artifact must be an Artifact")
    row = encode_occurrence_row(artifact)
    existing = conn.execute(
        f"SELECT {', '.join(_OCCURRENCE_COLUMNS)} FROM artifact_occurrences "
        "WHERE artifact_id=?",
        (artifact.id.value,),
    ).fetchone()
    if existing is not None:
        if tuple(existing) != row[1:]:
            raise ArtifactConflict(artifact.id)
        return
    conn.execute(
        "INSERT INTO artifact_occurrences VALUES (?, ?, ?, ?, ?, ?, ?)", row
    )


def read_occurrence_row(
    conn: sqlite3.Connection, artifact_id: ArtifactId
) -> tuple[ContentDigest, str, str, tuple[ArtifactId, ...], dict, SchemaVersion]:
    """Read one occurrence row, decoded back into its constituent parts (all
    except the payload, which the caller joins in from the blob store)."""

    row = conn.execute(
        f"SELECT {', '.join(_OCCURRENCE_COLUMNS)} FROM artifact_occurrences "
        "WHERE artifact_id=?",
        (artifact_id.value,),
    ).fetchone()
    if row is None:
        raise ArtifactNotFound(artifact_id)
    digest, kind, representation, parent_ids_json, provenance_json, schema_version = row
    # Mirror the event-decoding schema discipline (serialization.from_data):
    # occurrence rows bypass ``serialization.loads``, so validate the stored
    # occurrence schema version here. An unknown/future version is rejected
    # distinctly (a newer build wrote it) rather than silently trusted.
    if (
        isinstance(schema_version, bool)
        or not isinstance(schema_version, int)
        or schema_version < 1
    ):
        raise SchemaVersionRejected(
            f"invalid occurrence schema version: {schema_version!r}"
        )
    if schema_version > CURRENT_SCHEMA_VERSION.value:
        raise SchemaVersionRejected(
            f"future occurrence schema version {schema_version} > "
            f"{CURRENT_SCHEMA_VERSION.value}"
        )
    parent_ids = tuple(ArtifactId(value) for value in json.loads(parent_ids_json))
    provenance = json.loads(provenance_json)
    return (
        ContentDigest(digest),
        kind,
        representation,
        parent_ids,
        provenance,
        SchemaVersion(schema_version),
    )
