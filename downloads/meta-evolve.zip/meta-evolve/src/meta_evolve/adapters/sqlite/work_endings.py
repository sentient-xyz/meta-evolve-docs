"""Ending a work row, inside the caller's transaction: the two ways it happens.

Split from ``work_intents.py`` once the second ending arrived. That module
answers "which transitions are legal", and its bulk is acceptance -- a live
lease, four fenced preconditions, a duplicate exemption. These are the opposite
direction: no lease at all, a row nobody will attempt again, and a terminal fact
riding the same commit.

They belong together and apart from acceptance because they are ONE decision
read two ways. `application/work.py` chooses which intent a row owes; these
re-validate that choice against the row as it actually is, inside the
transaction that writes it, and each refuses what the other accepts. A reader
checking that the two preconditions are exclusive needs both in view and needs
nothing else.

`cancel_row_in_txn` comes with them: it is the UPDATE all three endings share --
these two and `WorkBroker.cancel` -- and following it from here is following it
to the statement rather than to a module about acceptance.
"""

from __future__ import annotations

from meta_evolve.domain import RunId
from meta_evolve.domain.work import FailureStage, WorkState
from meta_evolve.domain.work_aborts import diagnosed_deterministic
from meta_evolve.ports.work_store import InvalidWorkAppend

from .work_rows import read_cause_type


def cancel_row_in_txn(conn, item, *, run_id: RunId) -> None:
    """`READY`/`LEASED` -> `CANCELLED`, beside its terminal logical fact.

    A terminal row is left alone rather than refused: cancelling something
    already finished is the dispatcher tidying up after a race it lost, and the
    record has terminal states absorb every lease operation.

    Takes the ITEM rather than an intent, so the broker's `cancel` and
    `TerminateWork` share one statement. They were the same UPDATE with the
    same guard written twice -- and the copy in the broker spelled the terminal
    pair through a local `_TERMINAL` while this one inlined the two states, so
    the two ways of saying it could drift apart without either moving.
    """

    conn.execute(
        "UPDATE work_items SET state=?, lease_json=NULL"
        " WHERE run_id=? AND item_id=? AND state NOT IN (?, ?)",
        (
            WorkState.CANCELLED.value,
            run_id.value,
            item.value,
            *[state.value for state in WorkState.terminal()],
        ),
    )


def _ready_row_in_txn(conn, intent, *, run_id: RunId, columns: str):
    """The row this ending is about, proved to exist and to be `READY`.

    The two preconditions both endings share, stated once. They were written
    twice with the same meaning and two different sentences -- "reclaim
    terminates only a READY row" against "an abort ends only a READY row" --
    which is the shape this module family has already paid for twice: one rule,
    two spellings, and nothing that notices when only one of them is fixed.

    `columns` differs because the two endings ask about different things after
    this point, and a SELECT wide enough for both would read columns one of
    them has no business with.

    A terminal row is REFUSED here, not absorbed. `cancel_row_in_txn` absorbs
    one because an operator asking twice is tidying up; an ending is a claim
    that this row owes a terminal fact, and a row that already has one does
    not.
    """

    found = conn.execute(
        f"SELECT state, {columns} FROM work_items WHERE run_id=? AND item_id=?",
        (run_id.value, intent.item.value),
    ).fetchone()
    if found is None:
        raise InvalidWorkAppend(
            run_id, f"work row {intent.item.value} does not exist"
        )
    state, *rest = found
    if state != WorkState.READY.value:
        raise InvalidWorkAppend(
            run_id,
            f"work row {intent.item.value} is {state}, and reclaim ends only a "
            "READY row; a live lease is ended by expiry, not by an intent",
        )
    return rest


def terminate_work_in_txn(conn, intent, *, run_id: RunId) -> None:
    """`READY` + attempts exhausted -> `CANCELLED`, which is reclaim's row.

    Not `cancel_row_in_txn` alone. That statement is shared with
    `WorkBroker.cancel`, whose contract genuinely is "cancel whatever is
    there" -- an operator or the dispatcher asked, and the authority is the
    ask. Reclaim has no such authority: it is the step that gives an exhausted
    row its terminal fact, and the design table gives it the narrower
    transition. Sharing the statement silently dropped both preconditions, so
    an intent could terminate a freshly enqueued row with every attempt intact
    and discard work nothing had tried.

    Validated HERE, inside the writing transaction, because `TerminateWork`
    carries only the item and a reason -- there is nowhere else the state and
    the attempt count can be read without a TOCTOU on exactly the property the
    record wants serialized. The two preconditions this shares with the abort
    below are `_ready_row_in_txn`'s; what stays here is the one that is its own.
    """

    attempts, max_attempts = _ready_row_in_txn(
        conn, intent, run_id=run_id, columns="attempts, max_attempts"
    )
    if attempts < max_attempts:
        raise InvalidWorkAppend(
            run_id,
            f"work row {intent.item.value} has {max_attempts - attempts} of "
            f"{max_attempts} attempts left; reclaim terminates only an "
            "exhausted row",
        )
    cancel_row_in_txn(conn, intent.item, run_id=run_id)


def abort_work_in_txn(conn, intent, *, run_id: RunId) -> None:
    """`READY` + a deterministic diagnosis for the CURRENT attempt -> `CANCELLED`.

    Reclaim's other row. `TerminateWork` asks whether the bound is spent; this
    asks what the last attempt came back with, and ends a row that still has
    attempts it will never use.

    Four preconditions, and the third is the one that is easy to miss. The
    diagnosis must belong to the attempt the row is ON. A completion failure
    leaves the row LEASED, so a lease that expires before the run is resumed
    lets a later attempt claim the row while the older attempt's cause is still
    stored: `last_failure_attempt` is then behind `attempts`, and aborting on it
    would end an item on the strength of a diagnosis that is not the current
    attempt's. The dispatcher asks the same question (`work_aborts.aborted`)
    and claims such a row again, but "the only caller is careful" is not a
    precondition, and this is the statement that runs inside the transaction
    the row is actually written in. The fourth is the stage: a cause `release`
    recorded is an attempt failure, whatever its name, and one recorded before
    the stage was is not known to be a verdict.

    `diagnosed_deterministic` over a locally spelled name test: the set is
    declared once, as types, and a copy of its names here would be the thing
    that goes stale when a cause is added to it.
    """

    attempts, failure_type, failure_message, diagnosed = _ready_row_in_txn(
        conn,
        intent,
        run_id=run_id,
        columns=(
            "attempts, last_failure_type, last_failure_message,"
            " last_failure_attempt"
        ),
    )
    if failure_type is None:
        raise InvalidWorkAppend(
            run_id,
            f"work row {intent.item.value} has no recorded diagnosis, so "
            "nothing says a re-run cannot clear it",
        )
    if diagnosed != attempts:
        raise InvalidWorkAppend(
            run_id,
            f"work row {intent.item.value} is on attempt {attempts} and its "
            f"diagnosis is from attempt {diagnosed}; an abort reads the current "
            "attempt's cause",
        )
    failure_type, stage = read_cause_type(intent.item.value, failure_type)
    if stage is not FailureStage.COMPLETION:
        raise InvalidWorkAppend(
            run_id,
            f"work row {intent.item.value}'s diagnosis was recorded at the "
            f"{'unknown' if stage is None else stage.value} stage, and only a "
            "completion failure's cause is a verdict on the attempt",
        )
    if not diagnosed_deterministic((failure_type, failure_message)):
        raise InvalidWorkAppend(
            run_id,
            f"work row {intent.item.value} was diagnosed {failure_type}, which "
            "is transient: it re-runs until the retry bound ends it",
        )
    cancel_row_in_txn(conn, intent.item, run_id=run_id)


__all__ = ["abort_work_in_txn", "cancel_row_in_txn", "terminate_work_in_txn"]
