"""Read-only SQLite event streams."""

from __future__ import annotations

from collections.abc import Iterable

from meta_evolve.domain import EventEnvelope, RunId
from meta_evolve.errors import CapabilityError

from .event_store import SqliteEventStore


class ReadOnlySqliteEventStore(SqliteEventStore):
    """SQLite reads with an explicit refusal at the public write boundary."""

    def append(
        self,
        run_id: RunId,
        expected_version: int,
        events: Iterable[EventEnvelope],
    ) -> int:
        raise CapabilityError("read-only event storage cannot append")


__all__ = ["ReadOnlySqliteEventStore"]
