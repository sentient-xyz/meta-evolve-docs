"""Shared component and failure normalization for local callable adapters."""

from __future__ import annotations

from collections.abc import Callable, Mapping

from meta_evolve.domain.components import ComponentRef
from meta_evolve.domain.evaluation import EvaluatorFailure, Failure, ProposerFailure
from meta_evolve.domain.task import Usage
from meta_evolve.domain.values import FrozenMap
from meta_evolve.ports.escapes import (
    ESCAPING_EXCEPTIONS,
    INFRASTRUCTURE_ESCAPES,
    escapes_normalization,
)

# Defined at the port level, where the scheduler can also read it: the
# application layer imports no concrete adapter, so the one list both sides
# must agree on cannot live here. Re-exported under the established private
# name so every existing `except _INFRASTRUCTURE_ESCAPE_EXCEPTIONS` still
# reads the same tuple.
_INFRASTRUCTURE_ESCAPE_EXCEPTIONS = INFRASTRUCTURE_ESCAPES


def _local_component(
    value: ComponentRef | Callable[..., object], role: str
) -> ComponentRef:
    if isinstance(value, ComponentRef):
        if value.role != role:
            raise TypeError(f"callable {role} requires a {role} component reference")
        if value.origin != "local":
            raise ValueError(f"callable {role} requires a local component reference")
        if value.adapter is None:
            raise ValueError(f"local {role} component reference has no adapter")
        return value
    if not callable(value):
        raise TypeError(f"callable {role} requires a callable or ComponentRef")
    return ComponentRef.local(role, value)


def _registered_component(
    ref: ComponentRef, fn: Callable[..., object], role: str
) -> ComponentRef:
    """Bind a resolved callable to a *registered* ref, kept separate from it.

    Registered ``ComponentRef``s never retain ``_adapter`` (identity stays
    ref-derived: ``name@version``, never the callable's ``__module__``, so
    this sidesteps the ``ComponentRef.local()`` identity trap for durable
    runs). ``fn`` is the live callable the caller resolved from a
    ``Registry``, held only by the adapter instance, never by the ref.
    """

    if not isinstance(ref, ComponentRef) or ref.role != role:
        raise TypeError(f"registered {role} requires a {role} component reference")
    if ref.origin != "registered":
        raise ValueError(f"registered {role} requires a registered component reference")
    if ref.adapter is not None:
        raise ValueError(
            f"registered {role} component reference must not retain an adapter"
        )
    if not callable(fn):
        raise TypeError(f"registered {role} requires a callable implementation")
    return ref


def _reported_usage(usage: Usage) -> tuple[Usage, bool]:
    # A component-reported count is invalid, so it is dropped and flagged
    # rather than trusted.
    return usage.without_counts, bool(usage.trials or usage.evaluations)


def _role_failure(failure: Failure, role: str) -> Failure | None:
    if role == "proposer" and type(failure) is EvaluatorFailure:
        return None
    if role == "evaluator" and type(failure) is ProposerFailure:
        return None
    return failure


def _dropped_failure_details(
    failure: Failure, extra: Mapping[str, object] = FrozenMap()
) -> FrozenMap:
    """Keep a converted failure's diagnostics instead of discarding them."""

    return FrozenMap(
        {
            **dict(extra),
            "failure_kind": failure.kind,
            "failure_message": failure.message,
            "failure_details": failure.details,
        }
    )


__all__ = [
    "ESCAPING_EXCEPTIONS",
    "_INFRASTRUCTURE_ESCAPE_EXCEPTIONS",
    "_dropped_failure_details",
    "escapes_normalization",
    "_local_component",
    "_registered_component",
    "_reported_usage",
    "_role_failure",
]
