"""Bounded local subprocess execution for trusted development artifacts."""

from __future__ import annotations

import os
import posixpath
import re
import sys
import time
from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Protocol

from meta_evolve.domain import (
    InfrastructureFailure,
    PolicyViolation,
    ResourceExhausted,
    TimeoutFailure,
    Usage,
)
from meta_evolve.errors import CapabilityError
from meta_evolve.ports import ProcessResult, ProcessSpec, Workspace
from meta_evolve.ports.sandboxes import ProcessFailure

from ._posix_process import PosixProcessOperations

_ENVIRONMENT_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")


class _RunningProcess(Protocol):
    @property
    def streams_open(self) -> bool: ...

    def read_ready(self, timeout: float) -> tuple[tuple[str, bytes], ...]: ...

    def poll(self) -> int | None: ...

    def terminate_group(self) -> None: ...

    def reap(self) -> int: ...

    def close(self) -> None: ...


class _ProcessOperations(Protocol):
    def spawn(
        self,
        argv: tuple[str, ...],
        cwd: Path,
        environment: Mapping[str, str],
    ) -> _RunningProcess: ...


class DevelopmentSubprocessSandbox:
    """Control cwd, environment, wall time, and output for local development.

    This adapter does not isolate network, CPU, memory, syscalls, or hostile
    code. Its boundary is replaceable so stronger providers can enforce those
    policies without changing callers.
    """

    def __init__(
        self,
        *,
        _clock: Callable[[], float] = time.monotonic,
        _operations: _ProcessOperations | None = None,
        _platform: str | None = None,
    ) -> None:
        self._clock = _clock
        self._operations = _operations or PosixProcessOperations()
        self._platform = sys.platform if _platform is None else _platform

    def run(self, spec: ProcessSpec, workspace: Workspace) -> ProcessResult:
        if self._platform not in {"linux", "darwin"} or os.name != "posix":
            raise CapabilityError(
                "DevelopmentSubprocessSandbox requires POSIX process groups "
                "on Linux or macOS"
            )
        if not isinstance(spec, ProcessSpec):
            raise TypeError("spec must be a ProcessSpec")
        if not isinstance(workspace, Workspace):
            raise TypeError("workspace must be a Workspace")

        started = self._clock()
        policy = self._validate_policy(spec, workspace)
        if isinstance(policy, (PolicyViolation, InfrastructureFailure)):
            return self._result(started, b"", b"", policy)
        cwd, environment = policy

        try:
            process = self._operations.spawn(spec.argv, cwd, environment)
        except BaseException as error:
            return self._result(
                started,
                b"",
                b"",
                self._infrastructure("failed to spawn process", error),
            )
        return self._capture(process, spec, started)

    def _capture(
        self,
        process: _RunningProcess,
        spec: ProcessSpec,
        started: float,
    ) -> ProcessResult:
        output = {"stdout": bytearray(), "stderr": bytearray()}
        limits = {"stdout": spec.stdout_limit, "stderr": spec.stderr_limit}
        deadline = started + spec.timeout_seconds
        failure = None
        exit_code: int | None = None

        try:
            while True:
                observed = self._clock()
                if observed >= deadline:
                    failure = TimeoutFailure(message="process timed out")
                    break
                wait_seconds = deadline - observed
                if not process.streams_open:
                    # With no pipes left, selector waits cannot be awakened by
                    # process exit. Poll at a small bounded cadence instead.
                    wait_seconds = min(wait_seconds, 0.01)
                chunks = process.read_ready(wait_seconds)
                observed = self._clock()
                if chunks and observed >= deadline:
                    failure = TimeoutFailure(message="process timed out")
                    break
                for stream, chunk in chunks:
                    retained = output[stream]
                    limit = limits[stream]
                    remaining = max(0, limit - len(retained))
                    retained.extend(chunk[:remaining])
                    if len(chunk) > remaining:
                        failure = ResourceExhausted(
                            message=f"process {stream} limit exceeded"
                        )
                        break
                if failure is not None:
                    break
                polled = process.poll()
                if polled is not None and not process.streams_open:
                    exit_code = polled
                    break
        except BaseException as error:
            failure = self._infrastructure("process capture failed", error)

        cleanup_error = self._cleanup(process)
        if cleanup_error is not None:
            failure = cleanup_error
            exit_code = None
        elif failure is not None:
            exit_code = None

        return self._result(
            started,
            bytes(output["stdout"]),
            bytes(output["stderr"]),
            failure,
            exit_code,
        )

    def _cleanup(self, process: _RunningProcess) -> InfrastructureFailure | None:
        errors: list[tuple[str, BaseException]] = []
        try:
            # The session is owned as a unit: whatever remains of the process
            # group is terminated even after its leader exits. A descendant
            # that starts its own session leaves this development boundary.
            process.terminate_group()
        except BaseException as error:
            errors.append(("failed to terminate process group", error))
        try:
            process.reap()
        except BaseException as error:
            errors.append(("failed to reap process", error))
        try:
            process.close()
        except BaseException as error:
            errors.append(("failed to clean up process", error))
        if not errors:
            return None
        message, error = errors[0]
        return self._infrastructure(message, error)

    def _validate_policy(
        self, spec: ProcessSpec, workspace: Workspace
    ) -> tuple[Path, dict[str, str]] | PolicyViolation | InfrastructureFailure:
        executable = spec.argv[0]
        if "\x00" in executable or not Path(executable).is_absolute():
            return PolicyViolation(
                message="development subprocess executable must be an absolute path"
            )
        if any("\x00" in argument for argument in spec.argv):
            return PolicyViolation(message="process arguments cannot contain NUL")
        if (
            not spec.cwd
            or "\x00" in spec.cwd
            or posixpath.isabs(spec.cwd)
            or posixpath.normpath(spec.cwd) != spec.cwd
            or (spec.cwd != "." and "." in spec.cwd.split("/"))
            or ".." in spec.cwd.split("/")
        ):
            return PolicyViolation(
                message="process cwd must be normalized and workspace-relative"
            )
        environment = dict(spec.environment)
        for name, value in environment.items():
            if _ENVIRONMENT_NAME.fullmatch(name) is None:
                return PolicyViolation(
                    message=f"invalid process environment name: {name!r}"
                )
            if "\x00" in value:
                return PolicyViolation(
                    message=f"process environment value {name!r} cannot contain NUL"
                )
        # A workspace root that is gone or not a directory is a broken
        # workspace, not a caller policy violation.
        try:
            root = workspace.root.resolve(strict=True)
        except OSError as error:
            return self._infrastructure("workspace root is not available", error)
        if not root.is_dir():
            return InfrastructureFailure(message="workspace root is not a directory")
        try:
            cwd = root.joinpath(*spec.cwd.split("/")).resolve(strict=True)
            cwd.relative_to(root)
        except (OSError, ValueError):
            return PolicyViolation(
                message="process cwd must resolve to a directory inside the workspace"
            )
        if not cwd.is_dir():
            return PolicyViolation(
                message="process cwd must resolve to a directory inside the workspace"
            )
        return cwd, environment

    def _result(
        self,
        started: float,
        stdout: bytes,
        stderr: bytes,
        failure: ProcessFailure | None,
        exit_code: int | None = None,
    ) -> ProcessResult:
        elapsed = max(0.0, self._clock() - started)
        return ProcessResult(
            exit_code=exit_code,
            stdout=stdout.decode("utf-8", errors="replace"),
            stderr=stderr.decode("utf-8", errors="replace"),
            usage=Usage(wall_seconds=elapsed),
            failure=failure,
        )

    @staticmethod
    def _infrastructure(
        message: str, error: BaseException
    ) -> InfrastructureFailure:
        detail = str(error).strip() or type(error).__name__
        return InfrastructureFailure(message=message, details={"error": detail})


__all__ = ["DevelopmentSubprocessSandbox"]
