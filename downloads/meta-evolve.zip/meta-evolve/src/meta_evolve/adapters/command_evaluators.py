"""External command evaluation for immutable source trees."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from hashlib import sha256
from numbers import Real

from meta_evolve.domain.components import ComponentRef
from meta_evolve.domain.evaluation import (
    EvaluatorFailure,
    InfrastructureFailure,
    InvalidOutput,
)
from meta_evolve.domain.source_tree import SourceTree
from meta_evolve.domain.task import Maximize, Minimize, Task
from meta_evolve.domain.resources import Resources
from meta_evolve.domain.values import _require_text, canonical_payload_bytes
from meta_evolve.ports.callables import EvaluationResult, EvidenceDraft
from meta_evolve.ports.sandboxes import ProcessResult, ProcessSpec, SandboxProvider
from meta_evolve.ports.workspaces import Workspace, WorkspaceProvider

from .development_subprocess import DevelopmentSubprocessSandbox
from .directory_workspaces import DirectoryWorkspaces


_ADAPTER_VERSION = "1"
_EXIT_PROTOCOL_VERSION = "0-pass-1-fail-other-error-v1"


@dataclass(frozen=True, slots=True, kw_only=True)
class EvaluationEnvironment:
    """Versioned identity for the environment in which a grader runs."""

    name: str
    version: str

    def __post_init__(self) -> None:
        _require_text(self.name, "evaluation environment name")
        _require_text(self.version, "evaluation environment version")


def _score(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite non-boolean number")
    score = float(value)
    if not math.isfinite(score):
        raise ValueError(f"{name} must be a finite non-boolean number")
    return score


def _require_methods(value: object, name: str, methods: tuple[str, ...]) -> None:
    missing = tuple(
        method for method in methods if not callable(getattr(value, method, None))
    )
    if missing:
        raise TypeError(f"{name} must provide callable {', '.join(missing)}")


def _bounded_text(value: str, limit: int) -> str:
    bounded = value.encode("utf-8")[:limit].decode("utf-8", errors="replace")
    while len(bounded.encode("utf-8")) > limit:
        bounded = bounded[:-1]
    return bounded


@dataclass(frozen=True, slots=True, init=False)
class CommandEvaluator:
    """Measure source in a fresh workspace using a fixed command.

    Exit 0 reports ``passing_score``; exit 1 reports ``failing_score``. Other
    exits and process failures remain typed failures without rankable scores.
    Process results and environment identity are retained as evidence. The
    default development subprocess provider is not hostile-code isolation.
    """

    command: ProcessSpec
    environment: EvaluationEnvironment
    metric: str
    passing_score: float
    failing_score: float
    workspaces: WorkspaceProvider = field(repr=False, compare=False)
    sandbox: SandboxProvider = field(repr=False, compare=False)
    component: ComponentRef

    def __init__(
        self,
        *,
        command: ProcessSpec,
        environment: EvaluationEnvironment,
        metric: str = "score",
        passing_score: Real = 1.0,
        failing_score: Real = 0.0,
        workspaces: WorkspaceProvider | None = None,
        sandbox: SandboxProvider | None = None,
    ) -> None:
        if not isinstance(command, ProcessSpec):
            raise TypeError("command must be a ProcessSpec")
        if not isinstance(environment, EvaluationEnvironment):
            raise TypeError("environment must be an EvaluationEnvironment")
        _require_text(metric, "command evaluator metric")
        passing = _score(passing_score, "passing_score")
        failing = _score(failing_score, "failing_score")
        if workspaces is None:
            workspaces = DirectoryWorkspaces()
        if sandbox is None:
            sandbox = DevelopmentSubprocessSandbox()
        _require_methods(
            workspaces,
            "workspaces",
            ("materialize", "capture", "dispose"),
        )
        _require_methods(sandbox, "sandbox", ("run",))

        object.__setattr__(self, "command", command)
        object.__setattr__(self, "environment", environment)
        object.__setattr__(self, "metric", metric)
        object.__setattr__(self, "passing_score", passing)
        object.__setattr__(self, "failing_score", failing)
        object.__setattr__(self, "workspaces", workspaces)
        object.__setattr__(self, "sandbox", sandbox)
        digest = sha256(canonical_payload_bytes(self._identity_payload())).hexdigest()
        object.__setattr__(
            self,
            "component",
            ComponentRef.configured_local(
                "evaluator",
                self,
                name="meta_evolve:command-evaluator",
                version=f"1+{digest}",
            ),
        )

    def _identity_payload(self) -> dict[str, object]:
        return {
            "adapter_version": _ADAPTER_VERSION,
            "exit_protocol_version": _EXIT_PROTOCOL_VERSION,
            "argv": self.command.argv,
            "cwd": self.command.cwd,
            "process_environment": self.command.environment,
            "timeout_seconds": self.command.timeout_seconds,
            "stdout_limit": self.command.stdout_limit,
            "stderr_limit": self.command.stderr_limit,
            "evaluation_environment_name": self.environment.name,
            "evaluation_environment_version": self.environment.version,
            "metric": self.metric,
            "passing_score": self.passing_score,
            "failing_score": self.failing_score,
        }

    def validate_task(self, task: Task) -> None:
        if (
            task.artifact_kind != SourceTree.KIND
            or task.artifact_representation != SourceTree.REPRESENTATION
        ):
            raise ValueError("CommandEvaluator requires Task(artifact=SourceTree)")
        if len(task.objectives) != 1:
            raise ValueError("CommandEvaluator requires exactly one task objective")
        objective = task.objectives[0]
        if objective.metric != self.metric:
            raise ValueError(
                "CommandEvaluator metric must match the task objective metric"
            )
        if isinstance(objective, Maximize) and self.passing_score <= self.failing_score:
            raise ValueError("passing_score must exceed failing_score for Maximize")
        if isinstance(objective, Minimize) and (
            self.passing_score >= self.failing_score
        ):
            raise ValueError("passing_score must be below failing_score for Minimize")

    def __call__(self, candidate: object) -> EvaluationResult:
        evidence = [self._environment_evidence()]
        if not isinstance(candidate, SourceTree):
            return EvaluationResult(
                failure=InvalidOutput(
                    message="CommandEvaluator requires a SourceTree candidate",
                    details={"candidate_type": type(candidate).__name__},
                ),
                evidence=tuple(evidence),
            )

        try:
            workspace = self.workspaces.materialize(candidate)
        except Exception as error:
            return self._infrastructure("materialize", error, evidence=tuple(evidence))

        result: EvaluationResult | None = None
        try:
            if not isinstance(workspace, Workspace):
                result = self._infrastructure(
                    "materialize",
                    TypeError("workspace provider returned a non-Workspace"),
                    evidence=tuple(evidence),
                )
            else:
                result = self._execute(workspace, evidence)
        finally:
            try:
                self.workspaces.dispose(workspace)  # type: ignore[arg-type]
            except Exception as error:
                # result is None only when _execute raised; propagate that.
                if result is not None:
                    result = self._cleanup_failure(error, result)
        assert result is not None
        return result

    def _execute(
        self, workspace: Workspace, evidence: list[EvidenceDraft]
    ) -> EvaluationResult:
        try:
            process = self.sandbox.run(self.command, workspace)
        except Exception as error:
            return self._infrastructure("sandbox", error, evidence=tuple(evidence))
        if not isinstance(process, ProcessResult):
            return self._infrastructure(
                "sandbox",
                TypeError("sandbox provider returned a non-ProcessResult"),
                evidence=tuple(evidence),
            )

        evidence.append(self._process_evidence(process))
        usage = Resources(wall_seconds=process.usage.wall_seconds)
        if process.failure is not None:
            return EvaluationResult(
                failure=process.failure,
                evidence=tuple(evidence),
                usage=usage,
            )
        assert process.exit_code is not None
        if process.exit_code == 0:
            return EvaluationResult(
                metrics={self.metric: self.passing_score},
                evidence=tuple(evidence),
                usage=usage,
            )
        if process.exit_code == 1:
            return EvaluationResult(
                metrics={self.metric: self.failing_score},
                evidence=tuple(evidence),
                usage=usage,
            )
        return EvaluationResult(
            failure=EvaluatorFailure(
                message=f"grader exited outside the 0/1 protocol: {process.exit_code}",
                details={"exit_code": process.exit_code},
            ),
            evidence=tuple(evidence),
            usage=usage,
        )

    def _environment_evidence(self) -> EvidenceDraft:
        return EvidenceDraft(
            kind="evaluation-environment",
            data={"name": self.environment.name, "version": self.environment.version},
        )

    def _process_evidence(self, result: ProcessResult) -> EvidenceDraft:
        # Re-bound defensively: a replacement sandbox provider may not honor
        # the spec's retention limits.
        return EvidenceDraft(
            kind="process-result",
            data={
                "exit_code": result.exit_code,
                "stdout": _bounded_text(result.stdout, self.command.stdout_limit),
                "stderr": _bounded_text(result.stderr, self.command.stderr_limit),
            },
        )

    def _infrastructure(
        self,
        stage: str,
        error: Exception,
        *,
        evidence: tuple[EvidenceDraft, ...],
    ) -> EvaluationResult:
        return EvaluationResult(
            failure=InfrastructureFailure(
                message=str(error) or f"command evaluator {stage} failed",
                details={"stage": stage, "exception_type": type(error).__name__},
            ),
            evidence=evidence,
        )

    def _cleanup_failure(
        self, error: Exception, prior: EvaluationResult
    ) -> EvaluationResult:
        prior_kind = prior.failure.kind if prior.failure is not None else "completed"
        details: dict[str, object] = {
            "stage": "cleanup",
            "exception_type": type(error).__name__,
            "prior_classification": prior_kind,
        }
        if prior.failure is not None:
            details["prior_failure_message"] = prior.failure.message
            details["prior_failure_details"] = prior.failure.details
        return EvaluationResult(
            failure=InfrastructureFailure(
                message=str(error) or "command evaluator cleanup failed",
                details=details,
            ),
            evidence=prior.evidence,
            usage=prior.usage,
        )


__all__ = ["CommandEvaluator", "EvaluationEnvironment"]
