"""Disposable Git projection for an authorized source-history manifest."""

from __future__ import annotations

import json
import os
import shutil
import stat
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

from meta_evolve.application.source_history import PreparedSourceHistory
from meta_evolve.domain.source_tree import SourceTree
from meta_evolve.domain.values import FrozenMap
from meta_evolve.ports.workspaces import Workspace, WorkspaceSession


_IDENTITY = {
    "GIT_AUTHOR_NAME": "Meta-Evolve",
    "GIT_AUTHOR_EMAIL": "history@meta-evolve.invalid",
    "GIT_COMMITTER_NAME": "Meta-Evolve",
    "GIT_COMMITTER_EMAIL": "history@meta-evolve.invalid",
}


@dataclass(frozen=True, slots=True)
class GitHistoryMount:
    session: WorkspaceSession
    sidecar: Path


def project_git_history(
    workspace: Workspace,
    prepared: PreparedSourceHistory,
    *,
    git: Path,
) -> GitHistoryMount:
    sidecar = Path(tempfile.mkdtemp(prefix="meta-evolve-git-")).resolve()
    root = workspace.root.resolve()
    if _contains(root, sidecar) or _contains(sidecar, root):
        shutil.rmtree(sidecar, ignore_errors=True)
        raise OSError("Git history sidecar must be external to the workspace")
    git_dir = sidecar / "repository.git"
    home = sidecar / "home"
    hooks = sidecar / "hooks"
    index = sidecar / "index"
    home.mkdir()
    hooks.mkdir()
    try:
        bootstrap = _base_environment(git, home)
        _run(git, ("init", "--bare", str(git_dir)), bootstrap)
        environment = _repository_environment(
            git, root=root, git_dir=git_dir, index=index, home=home, hooks=hooks
        )
        _configure(git, environment, root, hooks)
        _write_attributes(git_dir)
        commits = _write_commits(git, environment, prepared)
        head = commits[prepared.manifest.head_ref]
        _run(git, ("update-ref", "refs/heads/main", head), environment)
        _run(git, ("symbolic-ref", "HEAD", "refs/heads/main"), environment)
        for position, artifact_ref in prepared.archive_refs:
            _run(
                git,
                (
                    "update-ref",
                    f"refs/meta-evolve/archive/{position:04d}",
                    commits[artifact_ref],
                ),
                environment,
            )
        _run(git, ("read-tree", "--reset", "HEAD"), environment)
        _freeze(sidecar)
        session = WorkspaceSession(
            root=root,
            environment=FrozenMap(environment),
            history=prepared.manifest,
        )
        return GitHistoryMount(session=session, sidecar=sidecar)
    except Exception:
        _remove_sidecar(sidecar)
        raise


def dispose_git_history(mount: GitHistoryMount) -> None:
    if not isinstance(mount, GitHistoryMount):
        raise TypeError("Git history mount is invalid")
    _remove_sidecar(mount.sidecar)


def _contains(parent: Path, child: Path) -> bool:
    try:
        child.relative_to(parent)
    except ValueError:
        return False
    return True


def _base_environment(git: Path, home: Path) -> dict[str, str]:
    false = next(
        (path for path in (Path("/usr/bin/false"), Path("/bin/false")) if path.exists()),
        git,
    )
    return {
        "PATH": str(git.parent),
        "HOME": str(home),
        "XDG_CONFIG_HOME": str(home / "xdg"),
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": os.devnull,
        "GIT_CONFIG_SYSTEM": os.devnull,
        "GIT_ATTR_NOSYSTEM": "1",
        "GIT_TERMINAL_PROMPT": "0",
        "GCM_INTERACTIVE": "never",
        "GIT_ASKPASS": str(false),
        "SSH_ASKPASS": str(false),
        "GIT_SSH_COMMAND": str(false),
        "GIT_ALLOW_PROTOCOL": "",
        "GIT_PROTOCOL_FROM_USER": "0",
        "GIT_NO_REPLACE_OBJECTS": "1",
        "GIT_OPTIONAL_LOCKS": "0",
        "GIT_PAGER": "",
        "GIT_EDITOR": str(false),
        **_IDENTITY,
    }


def _repository_environment(
    git: Path,
    *,
    root: Path,
    git_dir: Path,
    index: Path,
    home: Path,
    hooks: Path,
) -> dict[str, str]:
    environment = _base_environment(git, home)
    environment.update(
        {
            "GIT_DIR": str(git_dir),
            "GIT_WORK_TREE": str(root),
            "GIT_INDEX_FILE": str(index),
            "GIT_CEILING_DIRECTORIES": str(root.parent),
            "GIT_CONFIG_COUNT": "5",
            "GIT_CONFIG_KEY_0": "core.hooksPath",
            "GIT_CONFIG_VALUE_0": str(hooks),
            "GIT_CONFIG_KEY_1": "core.logAllRefUpdates",
            "GIT_CONFIG_VALUE_1": "false",
            "GIT_CONFIG_KEY_2": "credential.helper",
            "GIT_CONFIG_VALUE_2": "",
            "GIT_CONFIG_KEY_3": "core.attributesFile",
            "GIT_CONFIG_VALUE_3": os.devnull,
            "GIT_CONFIG_KEY_4": "protocol.allow",
            "GIT_CONFIG_VALUE_4": "never",
        }
    )
    return environment


def _configure(git: Path, environment, root: Path, hooks: Path) -> None:
    for key, value in (
        ("core.bare", "false"),
        ("core.worktree", str(root)),
        ("core.logAllRefUpdates", "false"),
        ("core.hooksPath", str(hooks)),
    ):
        _run(git, ("config", "--local", key, value), environment)


def _write_attributes(git_dir: Path) -> None:
    info = git_dir / "info"
    info.mkdir(exist_ok=True)
    (info / "attributes").write_text(
        "* -text -filter diff -merge -working-tree-encoding\n"
        "** -text -filter diff -merge -working-tree-encoding\n",
        encoding="utf-8",
    )


def _write_commits(git: Path, environment, prepared: PreparedSourceHistory):
    trees = dict(prepared.trees)
    messages = {
        ref: (hypothesis, evaluation)
        for ref, hypothesis, evaluation in prepared.messages
    }
    entries = {item.artifact_ref: item for item in prepared.manifest.entries}
    commits = {}
    pending = list(prepared.manifest.entries)
    while pending:
        progressed = False
        for entry in tuple(pending):
            if any(parent not in commits for parent in entry.parent_refs):
                continue
            tree_oid = _write_tree(git, environment, trees[entry.artifact_ref])
            arguments = ["commit-tree", tree_oid]
            for parent in entry.parent_refs:
                arguments.extend(("-p", commits[parent]))
            timestamp = 946684800 + entry.logical_step
            commit_environment = dict(environment)
            commit_environment.update(
                {
                    "GIT_AUTHOR_DATE": f"@{timestamp} +0000",
                    "GIT_COMMITTER_DATE": f"@{timestamp} +0000",
                }
            )
            body = {
                "artifact_ref": entry.artifact_ref.occurrence_id,
                "evaluation": messages[entry.artifact_ref][1],
                "evaluation_ref": entry.evaluation_ref.occurrence_id,
                "hypothesis": messages[entry.artifact_ref][0],
                "proposal_ref": entry.proposal_ref.occurrence_id,
                "rationale": entry.selection_rationale,
            }
            message = (
                f"meta-evolve {entry.artifact_ref.occurrence_id}\n\n"
                + json.dumps(body, ensure_ascii=False, separators=(",", ":"))
                + "\n"
            ).encode("utf-8")
            commits[entry.artifact_ref] = _run(
                git, tuple(arguments), commit_environment, input=message
            ).decode().strip()
            pending.remove(entry)
            progressed = True
        if not progressed:
            raise ValueError("source history manifest contains a causal cycle")
    assert set(commits) == set(entries)
    return commits


def _write_tree(git: Path, environment, tree: SourceTree) -> str:
    nested: dict[str, object] = {}
    for path, source in tree.items():
        current = nested
        parts = path.split("/")
        for part in parts[:-1]:
            current = current.setdefault(part, {})  # type: ignore[assignment]
        current[parts[-1]] = source

    def write(node: dict[str, object]) -> str:
        records = []
        for name in sorted(node):
            value = node[name]
            if isinstance(value, dict):
                oid = write(value)
                mode, kind = "040000", "tree"
            else:
                oid = _run(
                    git,
                    ("hash-object", "-w", "--stdin"),
                    environment,
                    input=value.encode("utf-8"),  # type: ignore[union-attr]
                ).decode().strip()
                mode, kind = "100644", "blob"
            records.append(f"{mode} {kind} {oid}\t{name}".encode("utf-8") + b"\0")
        return _run(
            git, ("mktree", "-z"), environment, input=b"".join(records)
        ).decode().strip()

    return write(nested)


def _run(git: Path, arguments, environment, *, input: bytes | None = None) -> bytes:
    completed = subprocess.run(
        (str(git), *arguments),
        env=environment,
        input=input,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if completed.returncode != 0:
        message = completed.stderr.decode("utf-8", errors="replace").strip()
        raise OSError(message or f"Git command failed: {arguments[0]}")
    return completed.stdout


def _freeze(root: Path) -> None:
    for path in sorted(root.rglob("*"), key=lambda item: len(item.parts), reverse=True):
        path.chmod(stat.S_IRUSR | (stat.S_IXUSR if path.is_dir() else 0))
    root.chmod(stat.S_IRUSR | stat.S_IXUSR)


def _remove_sidecar(root: Path) -> None:
    if not root.exists():
        return
    for path in (root, *root.rglob("*")):
        try:
            path.chmod(stat.S_IRUSR | stat.S_IWUSR | (stat.S_IXUSR if path.is_dir() else 0))
        except FileNotFoundError:
            pass
    shutil.rmtree(root)


__all__ = ["GitHistoryMount", "dispose_git_history", "project_git_history"]
