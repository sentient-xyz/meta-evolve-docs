"""Content-addressed payload blobs on the filesystem.

Stored bytes are exactly ``canonical_payload_bytes(payload)`` — the same
bytes ``ContentDigest.for_payload`` hashes — keyed by digest under
``sha256/<aa>/<rest>``. Publishing uses a no-replace primitive: a
same-directory, randomly-named temp file created with ``O_EXCL`` (retried on
collision), then linked into place; a losing writer verifies the winner's
on-disk bytes against the digest before returning, rather than trusting an
unverified ``FileExistsError``. Every parent directory this store creates is
fsynced, not just the final shard directory, so the publish survives a
crash.
"""

from __future__ import annotations

import os
import secrets
from hashlib import sha256
from pathlib import Path

from meta_evolve.domain.identity import ContentDigest
from meta_evolve.errors import DurableCorruption

_MAX_TEMP_ATTEMPTS = 8


class FilesystemBlobStore:
    def __init__(self, root: Path) -> None:
        self._root = Path(root)
        _mkdir_and_fsync(self._root)

    def _path(self, digest: ContentDigest) -> Path:
        return self._root / "sha256" / digest.value[:2] / digest.value[2:]

    def exists(self, digest: ContentDigest) -> bool:
        return self._path(digest).exists()

    def put(self, digest: ContentDigest, payload_bytes: bytes) -> None:
        if sha256(payload_bytes).hexdigest() != digest.value:
            raise DurableCorruption("blob bytes do not match the supplied digest")
        target = self._path(digest)
        if target.exists():
            self.get(digest)  # dedupe hit; verify the existing content first
            return
        _mkdir_and_fsync(target.parent)
        tmp = _create_temp_file(target.parent, payload_bytes)
        try:
            try:
                os.link(tmp, target)
            except FileExistsError:
                # Another writer published first; verify its bytes before
                # accepting the race outcome (never trust an unverified win).
                self.get(digest)
        finally:
            os.unlink(tmp)
        _fsync_dir(target.parent)

    def get(self, digest: ContentDigest) -> bytes:
        target = self._path(digest)
        if not target.exists():
            raise DurableCorruption(f"missing payload blob {digest.value}")
        data = target.read_bytes()
        if sha256(data).hexdigest() != digest.value:
            raise DurableCorruption(f"payload blob {digest.value} failed digest check")
        return data


def _create_temp_file(directory: Path, payload_bytes: bytes) -> Path:
    for _ in range(_MAX_TEMP_ATTEMPTS):
        candidate = directory / f".tmp-{secrets.token_hex(16)}"
        try:
            fd = os.open(candidate, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o444)
        except FileExistsError:
            continue
        try:
            _write_all(fd, payload_bytes)
            os.fsync(fd)
        except BaseException:
            # A mid-write failure (e.g. ENOSPC) must not strand the temp file:
            # the caller only unlinks once this returns, so clean up here.
            os.close(fd)
            os.unlink(candidate)
            raise
        os.close(fd)
        return candidate
    raise DurableCorruption("could not allocate a unique temporary blob file")


def _write_all(fd: int, data: bytes) -> None:
    view = memoryview(data)
    while view:
        written = os.write(fd, view)
        view = view[written:]


def _mkdir_and_fsync(path: Path) -> None:
    """Create ``path`` and any missing parents, fsyncing every directory this
    call actually creates (not only ``path`` itself)."""

    missing = []
    probe = path
    while not probe.exists():
        missing.append(probe)
        probe = probe.parent
    path.mkdir(parents=True, exist_ok=True)
    for directory in reversed(missing):
        _fsync_dir(directory)


def _fsync_dir(directory: Path) -> None:
    fd = os.open(directory, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
