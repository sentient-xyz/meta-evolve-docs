"""Composite durable ArtifactStore: filesystem payload blobs joined to
SQLite artifact occurrence rows.

The filesystem blob store alone is not an ``ArtifactStore`` — it only knows
digests, not artifact identities or provenance. ``put`` writes the blob
(content-addressed, deduped by digest) and then the occurrence row (identity
+ provenance, one per ``ArtifactId``) in its own SQLite transaction; ``get``
joins the occurrence row to its blob and reconstructs the ``Artifact``,
letting ``Artifact.__post_init__`` re-validate the digest against the
decoded payload.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from meta_evolve.domain import Artifact, ArtifactId
from meta_evolve.domain.values import canonical_payload_bytes, decode_payload_bytes

from ..sqlite.connection import transaction
from ..sqlite.occurrences import _put_occurrence_in_txn, read_occurrence_row
from .blob_store import FilesystemBlobStore


class DurableArtifactStore:
    def __init__(self, connection: sqlite3.Connection, artifacts_root: Path) -> None:
        self._conn = connection
        self.blob_store = FilesystemBlobStore(Path(artifacts_root))

    def put(self, artifact: Artifact) -> None:
        if not isinstance(artifact, Artifact):
            raise TypeError("artifact must be an Artifact")
        # Blobs are written and fsynced before the occurrence transaction
        # opens; a blob for a batch whose occurrence row never commits is an
        # allowed orphan, never migrated in place.
        self.blob_store.put(artifact.digest, canonical_payload_bytes(artifact.payload))
        with transaction(self._conn):
            _put_occurrence_in_txn(self._conn, artifact)

    def get(self, artifact_id: ArtifactId) -> Artifact:
        if not isinstance(artifact_id, ArtifactId):
            raise TypeError("artifact id must be an ArtifactId")
        digest, kind, representation, parent_ids, provenance, schema_version = (
            read_occurrence_row(self._conn, artifact_id)
        )
        payload = decode_payload_bytes(self.blob_store.get(digest))
        return Artifact(
            id=artifact_id,
            payload=payload,
            digest=digest,
            kind=kind,
            representation=representation,
            parent_ids=parent_ids,
            provenance=provenance,
            schema_version=schema_version,
        )
