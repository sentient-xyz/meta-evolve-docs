"""Narrow POSIX process operations used by the development sandbox."""

from __future__ import annotations

import os
import selectors
import signal
import subprocess
from collections.abc import Mapping
from pathlib import Path


class PosixProcess:
    """One process session with independently selectable byte streams."""

    def __init__(self, process: subprocess.Popen[bytes]) -> None:
        self._process = process
        self._selector = selectors.DefaultSelector()
        if process.stdout is None or process.stderr is None:
            raise RuntimeError("spawned process has no capture pipes")
        self._selector.register(process.stdout, selectors.EVENT_READ, "stdout")
        self._selector.register(process.stderr, selectors.EVENT_READ, "stderr")

    @property
    def pid(self) -> int:
        return self._process.pid

    @property
    def streams_open(self) -> bool:
        return bool(self._selector.get_map())

    def read_ready(self, timeout: float) -> tuple[tuple[str, bytes], ...]:
        chunks: list[tuple[str, bytes]] = []
        for key, _ in self._selector.select(timeout):
            data = os.read(key.fd, 65_536)
            if data:
                chunks.append((key.data, data))
            else:
                self._selector.unregister(key.fileobj)
        return tuple(chunks)

    def poll(self) -> int | None:
        return self._process.poll()

    def terminate_group(self) -> None:
        try:
            os.killpg(self.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass

    def reap(self) -> int:
        return self._process.wait(timeout=5.0)

    def close(self) -> None:
        errors: list[BaseException] = []
        try:
            self._selector.close()
        except BaseException as error:
            errors.append(error)
        for stream in (self._process.stdout, self._process.stderr):
            if stream is not None:
                try:
                    stream.close()
                except BaseException as error:
                    errors.append(error)
        if errors:
            raise RuntimeError("failed to close process capture resources") from errors[0]


class PosixProcessOperations:
    """Spawn process sessions without ambient authority."""

    def spawn(
        self,
        argv: tuple[str, ...],
        cwd: Path,
        environment: Mapping[str, str],
    ) -> PosixProcess:
        process = subprocess.Popen(
            argv,
            cwd=cwd,
            env=dict(environment),
            shell=False,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            close_fds=True,
            start_new_session=True,
            bufsize=0,
        )
        try:
            return PosixProcess(process)
        except BaseException:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait(timeout=5.0)
            raise


__all__ = ["PosixProcessOperations"]
