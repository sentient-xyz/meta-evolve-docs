"""The in-memory work ledger: its rows, its clock, and the sweep over them.

Split out of `work_broker.py`, which had grown past the length guideline. This
module is the DATA plus the rules that change it without anybody asking -- a
lease's deadline, and an operator withdrawing the worker holding it -- and the
broker beside it is the operations a caller invokes. Every write advances the
clock and sweeps through here, so each of those two rules has one
implementation.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import dataclass, field, replace

from meta_evolve.domain import RunId
from meta_evolve.domain.work import (
    FailureStage,
    Lease,
    LeaseToken,
    StaleReason,
    WorkItemId,
    WorkRow,
    WorkState,
)
from meta_evolve.domain.work import require_broker_time, require_lease
from meta_evolve.domain.work_staleness import stale_reason_for
from meta_evolve.domain.workers import WorkerId, revoked_attempt_cause
from meta_evolve.ports.work_store import (
    Acknowledgment,
    InvalidWorkAppend,
    refuse_inadmissible_enqueue,
)

from .work_diagnosis import record_cause, undiagnosed_attempt

#: Re-exported from the domain, where the rule now lives. Kept as a name here
#: because this module's callers read it; what is gone is the second copy of
#: the fact.
TERMINAL = WorkState.terminal()


_Accepted = tuple[int, str, Acknowledgment]


@dataclass(slots=True)
class _RunLedger:
    rows: dict[WorkItemId, WorkRow] = field(default_factory=dict)
    leases: dict[WorkItemId, Lease] = field(default_factory=dict)
    #: The token digest each item's latest attempt was issued, kept after expiry.
    issued: dict[WorkItemId, str] = field(default_factory=dict)
    #: A COMPLETED item's accepted attempt, token digest and acknowledgment.
    accepted: dict[WorkItemId, _Accepted] = field(default_factory=dict)
    epoch: int = 1
    clock_floor: int = 0


def released(row: WorkRow) -> WorkRow:
    """What an unfinished lease leaves behind: READY, always.

    One statement, because expiry, rollover and `release` all make this
    transition and copies are how the two sides of one rule come to disagree --
    the argument this module exists to hold, and #217 is what it looks like
    when it is not held.

    No branch on exhaustion (D3's refinement of `expire at retry limit ->
    CANCELLED`): exhaustion must append a terminal LOGICAL fact, and none of
    these callers commits a batch that could carry one. Left READY, the row is
    unclaimable but reclaimable, and the dispatcher's reclaim step ends it.
    """

    return replace(row, state=WorkState.READY)


def insert_absent(
    ledger: _RunLedger, run_id: RunId, rows: Iterable[WorkRow]
) -> None:
    """Insert rows that are absent, leaving any that already exist.

    Absent-only, exactly as the durable writer is: enqueue has no authority to
    change a committed row, and a retried commit of the same cohort must not
    fail on its own rows.

    ATOMIC across the batch. A cohort is enqueued as a generation, and a
    half-enqueued generation is the torn state the same-transaction rule exists
    to prevent. SQLite gets this from its transaction; here it has to be
    written, so every row is validated before any row is written. An earlier
    version mutated as it walked and left the valid prefix behind.

    Validated SEQUENTIALLY, though, against what the batch has already
    admitted. Evaluating every row against the PRE-BATCH ledger and then
    applying them made a batch that declares one item twice with different
    bounds succeed, with the second row silently overwriting the first --
    while SQLite, which inserts as it goes inside its transaction, refused the
    same batch. That is a divergence in the one rule this function was rewritten
    to make atomic, and it is the differential oracle that found it, not a law.
    """

    pending: dict[WorkItemId, WorkRow] = {}
    for row in rows:
        admitted = _admissible(ledger, run_id, row, pending)
        if admitted is not None:
            pending[admitted.item] = admitted
    ledger.rows.update(pending)


def _admissible(
    ledger: _RunLedger,
    run_id: RunId,
    row: WorkRow,
    pending: dict[WorkItemId, WorkRow],
) -> WorkRow | None:
    """The row to insert, or None when an identical one already exists.

    ``pending`` is what this batch has admitted so far, which a row must be
    checked against as well as the ledger: two rows for one item inside one
    batch are a conflicting declaration, not a resubmission.
    """

    refuse_inadmissible_enqueue(run_id, row)
    existing = ledger.rows.get(row.item) or pending.get(row.item)
    if existing is None:
        return row
    # Only the columns ENQUEUE AUTHORS. State and attempts belong to the broker,
    # so an item that has moved on is the same item further along.
    if (existing.trial_id, existing.kind, existing.max_attempts) != (
        row.trial_id,
        row.kind,
        row.max_attempts,
    ):
        raise InvalidWorkAppend(
            run_id,
            f"work row {row.item.value} already exists and differs; "
            "enqueue cannot change a committed row",
        )
    return None


def tick(
    ledger: _RunLedger, now: int, honoured: Callable[[WorkerId], int | None]
) -> int:
    """Read the clock and settle the sweep, which every write does together.

    Paired on purpose: reading the clock without settling expiry would let an
    operation act on a lease the clock has already ended, and that pair is what
    the record means by a precondition read "inside the same transaction".

    `honoured` answers which generation the store's operator honours for a
    worker right now. It is a QUESTION rather than the allow-list itself: the
    broker beside this module owns the registry, and handing a ledger one would
    give the double an authority the real thing keeps in its store.
    """

    clock = advance(ledger, now)
    expire_in_place(ledger, clock, honoured)
    return clock


def release_all_leased(
    ledger: _RunLedger, honoured: Callable[[WorkerId], int | None]
) -> None:
    """Rollover's walk: return every leased row, whatever the clock says.

    A revoked holder's row takes the revocation arm, so a restarted drive's
    first write still records why it was freed.
    """

    for key, lease in list(ledger.leases.items()):
        row = ledger.rows[key]
        if row.state is WorkState.LEASED and not withdraw_if_revoked(
            ledger, key, lease, honoured
        ):
            del ledger.leases[key]
            ledger.issued.pop(key, None)
            ledger.rows[key] = released(row)


def advance(ledger: _RunLedger, now: int) -> int:
    """Read the clock once per operation, clamped non-decreasing.

    The clamp is why the broker owns an absolute wall-clock-derived timestamp
    rather than `time.monotonic()`: monotonic's origin is process-relative, so a
    restart rebases it and a persisted deadline becomes meaningless -- the exact
    failure this floor exists to prevent.
    """

    ledger.clock_floor = max(ledger.clock_floor, require_broker_time(now))
    return ledger.clock_floor


def expire_in_place(
    ledger: _RunLedger, clock: int, honoured: Callable[[WorkerId], int | None]
) -> None:
    """Return every lease this run should no longer be holding to READY.

    Two reasons, in this order, exactly as `sqlite/work_leases.expire_in_txn`:
    the operator withdrew the worker's authority, or the half-open deadline
    passed. Revocation is weighed FIRST, so a lease that is both reports the
    operator's command; it withdraws the credential and records `WorkerRevoked`
    under the first-writer rule (PD3). A lease the clock collected keeps its
    verifier, so the worker that ran it can still say why it failed. Read per
    lease and never cached: one `revoke` frees that worker in every run.

    Always to READY, even with no attempts left, and the attempt is never handed
    back: this commits no batch, so it cannot carry the terminal fact retry
    exhaustion requires ("never a ledger-only edit"). The acquire guard keeps an
    exhausted row unclaimable until the reclaim step ends it with that fact.
    """

    for key, lease in list(ledger.leases.items()):
        row = ledger.rows[key]
        if row.state is not WorkState.LEASED:
            continue
        if withdraw_if_revoked(ledger, key, lease, honoured):
            continue
        if not lease.expired_at(clock):
            continue
        del ledger.leases[key]
        ledger.rows[key] = released(ledger.rows[key])


def withdraw_if_revoked(
    ledger: _RunLedger, key: WorkItemId, lease: Lease,
    honoured: Callable[[WorkerId], int | None],
) -> bool:
    """The revocation arm alone, as `sqlite/work_leases.withdraw_if_revoked_in_txn`."""

    if honoured(WorkerId(lease.worker_id)) == lease.generation:
        return False
    if undiagnosed_attempt(ledger, lease):
        record_cause(
            ledger, lease,
            revoked_attempt_cause(lease.worker_id), FailureStage.ATTEMPT,
        )
    ledger.issued.pop(key, None)
    del ledger.leases[key]
    ledger.rows[key] = released(ledger.rows[key])
    return True


def item_key(item: WorkItemId) -> str:
    return item.value


def classify_submission(
    ledger: _RunLedger,
    run_id: RunId,
    lease: Lease,
    *,
    clock: int,
    current_generation: int | None,
) -> tuple[StaleReason | None, WorkState]:
    """The ledger's half of `work_leases.classify_submission_in_txn`: the
    same fields for the same rule, including a `COMPLETED` row's accepted
    attempt and token, which `work_acceptance.accept` stores.

    The honoured generation is handed IN rather than looked up, which is the one
    place the two halves differ: the durable classifier holds the connection its
    caller's transaction is open on, and a ledger holds no allow-list at all.
    The broker beside it owns the registry and reads it in the same critical
    section as this call, which is what the durable transaction buys for free.
    """

    require_lease(lease)
    recorded = ledger.rows.get(lease.item)
    if recorded is None:
        raise InvalidWorkAppend(
            run_id,
            f"work item {lease.item.value} is not held by this run, so no lease "
            "was ever issued for it here",
        )
    digest = ledger.issued.get(lease.item)
    accepted = ledger.accepted.get(lease.item)
    reason = stale_reason_for(
        lease,
        state=recorded.state,
        held=ledger.leases.get(lease.item) if recorded.state is WorkState.LEASED else None,
        attempts=recorded.attempts,
        verifier=None if digest is None else LeaseToken(digest),
        accepted_attempt=None if accepted is None else accepted[0],
        accepted_token=None if accepted is None else LeaseToken(accepted[1]),
        current_epoch=ledger.epoch,
        current_generation=current_generation,
        clock=clock,
    )
    return reason, recorded.state


__all__ = [
    "TERMINAL",
    "_RunLedger",
    "advance",
    "expire_in_place",
    "release_all_leased",
    "tick",
    "insert_absent",
    "item_key",
    "released",
    "withdraw_if_revoked",
]
