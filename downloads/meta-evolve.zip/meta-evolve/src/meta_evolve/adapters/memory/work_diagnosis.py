"""The diagnosis rule on the ledger, and the write it authorises.

`work_ledger.py` answers whether a lease is ALIVE; this answers the weaker
question of whether an ATTEMPT may still be described, so the two disagree
about an expired lease. A SUBMISSION must present its credential; the
revocation sweep holds the lease it describes and asks only
`undiagnosed_attempt`. `_RunLedger` is a typing-only import, to avoid a cycle.
"""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from meta_evolve.domain.work import (
    FailureStage,
    Lease,
    LeaseToken,
    WorkState,
    require_lease,
)

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .work_ledger import _RunLedger

__all__ = [
    "authorised_to_diagnose",
    "record_cause",
    "record_diagnosis",
    "undiagnosed_attempt",
]


def undiagnosed_attempt(ledger: _RunLedger, lease: Lease) -> bool:
    """Whether this row is still open and nothing has described this attempt.

    The in-memory half of `sqlite/work_diagnosis.undiagnosed_attempt_in_txn`.
    First writer wins per attempt, on every path.
    """

    require_lease(lease)
    recorded = ledger.rows.get(lease.item)
    if recorded is None or recorded.state in WorkState.terminal():
        return False
    return (recorded.last_failure_attempt or 0) < lease.attempt.ordinal


def authorised_to_diagnose(ledger: _RunLedger, lease: Lease) -> bool:
    """Whether this SUBMISSION may write a diagnosis onto the row.

    The in-memory half of the rule
    `sqlite/work_diagnosis.authorised_to_diagnose_in_txn` states for SQLite;
    the shared contract law `check_a_forged_token_cannot_write_a_diagnosis`
    keeps the two from drifting.

    Weaker than `_live_lease` deliberately -- the diagnosis describes the
    ATTEMPT and must survive the lease expiring -- but it still needs the
    credential, or any caller could overwrite why a run's work died.
    """

    if not undiagnosed_attempt(ledger, lease):
        return False
    held = ledger.leases.get(lease.item)
    if held is not None:
        return lease.credential_mismatch(held) is None
    # Expiry collected the lease. Only the latest attempt may still diagnose,
    # proving the token it was issued.
    digest = ledger.issued.get(lease.item)
    return lease.proves_latest_attempt(
        ledger.rows[lease.item].attempts, None if digest is None else LeaseToken(digest)
    )


def record_cause(
    ledger: _RunLedger, lease: Lease, cause: tuple[str, str], stage: FailureStage
) -> None:
    """Write `cause` for `lease`'s attempt. The rule is the caller's to weigh."""

    ledger.rows[lease.item] = replace(
        ledger.rows[lease.item], last_failure=cause,
        last_failure_attempt=lease.attempt.ordinal, last_failure_stage=stage,
    )


def record_diagnosis(
    ledger: _RunLedger, lease: Lease, cause: tuple[str, str], stage: FailureStage
) -> bool:
    """Write `cause` for `lease`'s attempt if the diagnosis rule allows it."""

    if not authorised_to_diagnose(ledger, lease):
        return False
    record_cause(ledger, lease, cause, stage)
    return True
