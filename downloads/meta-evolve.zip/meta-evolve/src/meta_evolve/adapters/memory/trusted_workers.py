"""The in-memory trusted-worker registry.

The allow-list the dispatcher tests drive, obeying the same laws the SQLite one
does -- a double that did not would certify nothing about the real thing.

Rows live on the instance and nowhere else: one dict per registry, keyed by the
id text an operator typed. An operator's allow-list held in a module global
would be ambient authority over every store a process opens.
"""

from __future__ import annotations

from collections.abc import Mapping

from meta_evolve.domain.workers import TrustedWorker, WorkerId
from meta_evolve.ports.worker_registry import (
    TrustedWorkerReader,
    decide_revocation,
    decide_trust,
)


class InMemoryTrustedWorkers:
    """One allow-list, held in memory for the life of the dispatcher."""

    def __init__(self) -> None:
        self._rows: dict[str, TrustedWorker] = {}

    # -- reads ------------------------------------------------------------

    def get(self, worker: WorkerId) -> TrustedWorker | None:
        return self._rows.get(worker.value)

    def all(self) -> tuple[TrustedWorker, ...]:
        # By id text rather than in the order an operator happened to enrol in:
        # the other adapter answers from a table with no inherent order, and two
        # registries answering in two orders is exactly the divergence a shared
        # law exists to catch.
        return tuple(self._rows[key] for key in sorted(self._rows))

    def reader(self) -> TrustedWorkerReader:
        """The read side of this registry, and nothing else (AD1).

        A separate object rather than this one: what makes a read-only store's
        registry read-only is that there is no `trust` to call, not a flag it
        consults. The view reads THROUGH this registry, so it shows every row
        written after it was handed out, and in one order rather than two.
        """

        return _ReadOnlyTrustedWorkers(self)

    # -- writes -----------------------------------------------------------

    def trust(
        self, worker: WorkerId, capabilities: Mapping[str, object]
    ) -> TrustedWorker:
        row = decide_trust(self.get(worker), worker, capabilities)
        self._rows[worker.value] = row
        return row

    def revoke(self, worker: WorkerId) -> TrustedWorker:
        row = decide_revocation(self.get(worker), worker)
        self._rows[worker.value] = row
        return row


class _ReadOnlyTrustedWorkers:
    """One registry's rows, with no authority to write them."""

    def __init__(self, registry: InMemoryTrustedWorkers) -> None:
        self._registry = registry

    def get(self, worker: WorkerId) -> TrustedWorker | None:
        return self._registry.get(worker)

    def all(self) -> tuple[TrustedWorker, ...]:
        return self._registry.all()


__all__ = ["InMemoryTrustedWorkers"]
