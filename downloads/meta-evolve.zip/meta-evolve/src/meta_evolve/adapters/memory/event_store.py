"""In-memory optimistic event streams."""

from __future__ import annotations

from collections.abc import Iterable, Mapping

from meta_evolve.domain import EventEnvelope, RunId
from meta_evolve.ports.event_store import EventStreamConflict, InvalidEventAppend


class InMemoryEventStore:
    def __init__(self) -> None:
        self._streams: dict[RunId, tuple[EventEnvelope, ...]] = {}

    def append(
        self,
        run_id: RunId,
        expected_version: int,
        events: Iterable[EventEnvelope],
    ) -> int:
        if not isinstance(run_id, RunId):
            raise TypeError("event stream run id must be a RunId")
        self._require_position(expected_version, "expected version")
        new_stream = self._validate(self._streams, run_id, expected_version, events)
        self._streams = {**self._streams, run_id: new_stream}
        return len(new_stream)

    def read(
        self,
        run_id: RunId,
        after: int = 0,
    ) -> tuple[EventEnvelope, ...]:
        if not isinstance(run_id, RunId):
            raise TypeError("event stream run id must be a RunId")
        self._require_position(after, "event read position")
        return tuple(
            event
            for event in self._streams.get(run_id, ())
            if event.sequence > after
        )

    def runs(self) -> tuple[RunId, ...]:
        """The ``RunIndex`` capability: every run holding events, by id.

        Sorted rather than in insertion order, so this store and the SQLite
        one — which has no insertion column — answer identically. Needs no
        lock: appends rebind ``_streams`` to a new dict rather than mutating
        it, so this reads one consistent snapshot.
        """

        return tuple(sorted(self._streams, key=lambda run_id: run_id.value))

    def run_version(self, run_id: RunId) -> int:
        """Maximum committed sequence for ``run_id``, or zero if unseen."""

        if not isinstance(run_id, RunId):
            raise TypeError("event stream run id must be a RunId")
        return len(self._streams.get(run_id, ()))

    def _snapshot(self) -> dict[RunId, tuple[EventEnvelope, ...]]:
        """Shallow copy of stream state, for a copy-on-write unit of work.

        Internal contract with ``Storage``'s in-memory ``commit``; not part
        of the ``EventStore`` port.
        """

        return dict(self._streams)

    def _validate(
        self,
        streams: Mapping[RunId, tuple[EventEnvelope, ...]],
        run_id: RunId,
        expected_version: int,
        events: Iterable[EventEnvelope],
    ) -> tuple[EventEnvelope, ...]:
        """Validate a prospective append against ``streams`` without
        mutating ``self``. Returns the resulting stream for ``run_id`` if
        this append were applied; raises without any side effect otherwise.
        """

        current = streams.get(run_id, ())
        actual_version = len(current)
        if expected_version != actual_version:
            raise EventStreamConflict(run_id, expected_version, actual_version)
        pending = tuple(events)
        if not pending:
            raise InvalidEventAppend(run_id, "append must contain at least one event")

        for offset, envelope in enumerate(pending, start=1):
            if not isinstance(envelope, EventEnvelope):
                raise InvalidEventAppend(run_id, "all appended items must be events")
            if envelope.run_id != run_id:
                raise InvalidEventAppend(
                    run_id,
                    f"event at batch position {offset} belongs to another run",
                )
            required_sequence = expected_version + offset
            if envelope.sequence != required_sequence:
                raise InvalidEventAppend(
                    run_id,
                    f"event at batch position {offset} must have sequence "
                    f"{required_sequence}",
                )

        return current + pending

    def _install(self, streams: dict[RunId, tuple[EventEnvelope, ...]]) -> None:
        """Swap in new stream state. Internal to the atomic commit UoW."""
        self._streams = streams

    @staticmethod
    def _require_position(value: int, name: str) -> None:
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{name} must be a non-negative integer")
