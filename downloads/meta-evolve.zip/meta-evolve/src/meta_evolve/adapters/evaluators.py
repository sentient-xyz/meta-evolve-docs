"""Adapter from ordinary local callables to the decoded-value evaluator port."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field
from numbers import Real

from meta_evolve.domain.components import ComponentRef
from meta_evolve.domain.evaluation import EvaluatorFailure, Failure, InvalidOutput
from meta_evolve.domain.task import Objective, _validate_objectives
from meta_evolve.domain.resources import Resources
from meta_evolve.domain.values import FrozenMap
from meta_evolve.ports.callables import EvaluationResult, EvidenceDraft

from .normalization import (
    ESCAPING_EXCEPTIONS,
    _dropped_failure_details,
    _local_component,
    _registered_component,
    _role_failure,
)

# What must never be converted at the evaluator boundary. DERIVED, not rebuilt:
# this is exactly `ESCAPING_EXCEPTIONS` -- the infrastructure set plus
# ``CapabilityError``, reserved abort control flow saying the whole run cannot
# proceed (see docs/programming-model.md). Re-deriving the union by hand gave
# it three independent spellings, and the predicate the scheduler asks
# (`escapes_normalization`) reads only one of them.
_EVALUATOR_ESCAPE_EXCEPTIONS: tuple[type[BaseException], ...] = ESCAPING_EXCEPTIONS


def _invalid_evaluation(
    message: str,
    *,
    details: Mapping[str, object] | FrozenMap = FrozenMap(),
    uncertainty: Mapping[str, object] | FrozenMap = FrozenMap(),
    evidence: tuple[EvidenceDraft, ...] = (),
    usage: Resources = Resources(),
) -> EvaluationResult:
    return EvaluationResult(
        failure=InvalidOutput(message=message, details=details),
        uncertainty=uncertainty,
        evidence=evidence,
        usage=usage,
    )


@dataclass(frozen=True, slots=True, init=False)
class CallableEvaluator:
    component: ComponentRef
    objectives: tuple[Objective, ...]
    _fn: Callable[..., object] | None = field(default=None, repr=False, compare=False)

    def __init__(
        self,
        evaluator: ComponentRef | Callable[..., object],
        objectives: Iterable[Objective],
    ) -> None:
        normalized_objectives = _validate_objectives(objectives, "callable evaluator")
        component = _local_component(evaluator, "evaluator")
        object.__setattr__(self, "component", component)
        object.__setattr__(self, "objectives", normalized_objectives)
        object.__setattr__(self, "_fn", None)

    @classmethod
    def registered(
        cls,
        ref: ComponentRef,
        fn: Callable[..., object],
        objectives: Iterable[Objective],
    ) -> "CallableEvaluator":
        """Bind ``fn`` (resolved from a ``Registry``) to a registered ref.

        ``fn`` is held only by this adapter instance -- ``ref`` (and the
        durable records built from it) never carries an adapter.
        """

        normalized_objectives = _validate_objectives(objectives, "callable evaluator")
        component = _registered_component(ref, fn, "evaluator")
        instance = object.__new__(cls)
        object.__setattr__(instance, "component", component)
        object.__setattr__(instance, "objectives", normalized_objectives)
        object.__setattr__(instance, "_fn", fn)
        return instance

    def evaluate(self, candidate: object) -> EvaluationResult:
        adapter = self._fn if self._fn is not None else self.component.adapter
        assert adapter is not None
        try:
            returned = adapter(candidate)
        except _EVALUATOR_ESCAPE_EXCEPTIONS:
            # Ordered before the broad conversion on purpose: ``CapabilityError``
            # is a ``RunError`` is a ``RuntimeError``, so a bare ``except
            # Exception`` reached first would swallow it. An evaluator commonly
            # drives an inner run or a provider session, where a missing extra
            # or an unhonored profile is the same fact for every candidate:
            # converting one would re-run an impossible preflight against the
            # whole budget and report the search as ``NoSuccessfulEvaluation``
            # rather than the real cause. An inner run's own
            # ``NoSuccessfulEvaluation`` is deliberately NOT here -- an inner
            # run with nothing to rank is this candidate's honest outcome and
            # stays a recoverable ``EvaluatorFailure``.
            raise
        except Exception as error:
            return EvaluationResult(
                failure=EvaluatorFailure(
                    message=str(error) or type(error).__name__,
                    details={"exception_type": type(error).__name__},
                )
            )
        return self._normalize(returned)

    def _normalize(self, returned: object) -> EvaluationResult:
        if isinstance(returned, Failure):
            if _role_failure(returned, "evaluator") is None:
                return _invalid_evaluation(
                    "evaluator returned a proposer-specific failure",
                    details=_dropped_failure_details(returned),
                )
            try:
                return EvaluationResult(failure=returned)
            except (TypeError, ValueError) as error:
                return _invalid_evaluation(
                    "evaluator returned an unsupported failure",
                    details=_dropped_failure_details(
                        returned, {"error": str(error)}
                    ),
                )

        if isinstance(returned, EvaluationResult):
            usage = returned.usage
            if returned.failure is not None:
                if _role_failure(returned.failure, "evaluator") is None:
                    return _invalid_evaluation(
                        "evaluator returned a proposer-specific failure",
                        details=_dropped_failure_details(returned.failure),
                        uncertainty=returned.uncertainty,
                        evidence=returned.evidence,
                        usage=usage,
                    )
                return EvaluationResult(
                    failure=returned.failure,
                    uncertainty=returned.uncertainty,
                    evidence=returned.evidence,
                    usage=usage,
                )
            result = EvaluationResult(
                metrics=returned.metrics,
                uncertainty=returned.uncertainty,
                evidence=returned.evidence,
                usage=usage,
            )
            return self._require_objectives(result)

        if isinstance(returned, Real) and not isinstance(returned, bool):
            if len(self.objectives) != 1:
                return _invalid_evaluation(
                    "a scalar evaluation requires exactly one task objective",
                    details={"objective_count": len(self.objectives)},
                )
            metrics: object = {self.objectives[0].metric: returned}
        elif isinstance(returned, Mapping):
            metrics = returned
        else:
            return _invalid_evaluation(
                "evaluator returned invalid output",
                details={"output_type": type(returned).__name__},
            )

        try:
            result = EvaluationResult(metrics=metrics)  # type: ignore[arg-type]
        except (TypeError, ValueError) as error:
            return _invalid_evaluation(
                "evaluator returned invalid metrics",
                details={"error": str(error)},
            )
        return self._require_objectives(result)

    def _require_objectives(self, result: EvaluationResult) -> EvaluationResult:
        missing = tuple(
            objective.metric
            for objective in self.objectives
            if objective.metric not in result.metrics
        )
        if missing:
            return _invalid_evaluation(
                "evaluation is missing required task objectives",
                details={"missing_objectives": missing},
                uncertainty=result.uncertainty,
                evidence=result.evidence,
                usage=result.usage,
            )
        return result


__all__ = ["CallableEvaluator"]
